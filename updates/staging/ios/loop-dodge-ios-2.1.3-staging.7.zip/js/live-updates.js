/* Native download, checksum verification and rollback are owned by Capgo.
 * UpdateVerifier authenticates manifests with a key pinned in the native app.
 * This module controls acknowledgement, safe-menu queuing and activation
 * before the game boots in a NEW native process. No mid-session reloads. */
var LiveUpdates = (function () {
  var plugin = null, ready = false, failed = false, frames = 0, pending = null;
  var initialized = false, busy = false, status = 'disabled', scheduled = '';
  var checking = null, lastCheck = 0, app = null, nativeInfo = null, current = null;
  var signedPending = null;
  var signedEnvelope = null, launchId = '', preparation = null;
  function config() { return (window.SERVICES_CONFIG && SERVICES_CONFIG.updates) || {}; }
  function read(key) { try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; } }
  function save(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) {} }
  function os() { try { return Capacitor.getPlatform(); } catch (e) { return 'web'; } }
  function storageKey(kind) { return 'ld_update_' + kind + '_' + os() + '_' + config().channel; }
  var safe = function () { return false; };
  function report(name, data) { if (window.Analytics) Analytics.track(name, data); }
  function call(name, value) { try { return Promise.resolve(plugin[name](value)); } catch (e) { return Promise.reject(e); } }
  function nativePlugin(name) {
    return Capacitor.Plugins && Capacitor.Plugins[name] || Capacitor.registerPlugin(name);
  }
  function prepareLaunch() {
    if (preparation) return preparation;
    try {
      if (!window.Capacitor || !Capacitor.isNativePlatform()) return Promise.resolve(true);
      plugin = nativePlugin('CapacitorUpdater'); app = nativePlugin('App');
      var verifier = nativePlugin('UpdateVerifier');
      preparation = Promise.all([verifier.getLaunchId(), call('getNextBundle'), call('current'), app.getInfo()])
        .then(function (results) {
          launchId = results[0].id;
          if (typeof launchId !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(launchId)) throw new Error('invalid_launch');
          var next = results[1], active = results[2].bundle, info = results[3], cfg = config();
          if (!next || next.id === active.id) return true;
          // Capgo clears a kill delay at launch but only installs `next` on
          // background. Re-arm it before boot, then explicitly activate here.
          return call('setMultiDelay', { delayConditions: [{ kind: 'kill' }] }).then(function () {
            var attempt = read(storageKey('attempt'));
            function discard() { return call('next', { id: active.id }).then(function () { return true; }); }
            if (!cfg.enabled || !attempt || attempt.id !== next.id || !attempt.envelope ||
                next.status === 'error') return discard();
            return UpdateManifest.verify(attempt.envelope, cfg.publicKey, {
              platform: os(), environment: cfg.channel, nativeVersion: info.version, nativeBuild: info.build,
              runtimeFingerprint: cfg.runtimeFingerprint, manifestUrl: cfg.manifestUrls[os()]
            }).then(function (manifest) {
              var blocked = read(storageKey('blocked')) || [];
              if (!manifest || manifest.version !== next.version || manifest.sha256 !== next.checksum ||
                  (Array.isArray(blocked) && blocked.indexOf(manifest.version) >= 0)) return discard();
              // Local page navigation or a WebView reload is not a process restart.
              if (attempt.launchId === launchId) return true;
              if (typeof attempt.launchId !== 'string' || !attempt.launchId) return discard();
              status = 'activating';
              return call('set', { id: next.id }).then(function () { return false; });
            });
          });
        }).catch(function () { status = 'launch_check_failed'; return true; });
      return preparation;
    } catch (e) { status = 'launch_check_failed'; return Promise.resolve(true); }
  }
  function queue() {
    if (!plugin || !launchId || !ready || failed || busy || !pending || !safe() || scheduled === pending.id) return Promise.resolve(false);
    var bundle = pending; busy = true;
    // Install only on a real process restart, including when an ad backgrounds
    // the app or when the player pauses a run after visiting the menu.
    return call('setMultiDelay', { delayConditions: [{ kind: 'kill' }] }).then(function () {
      if (!safe() || failed) return false;
      return call('next', { id: bundle.id }).then(function () {
        scheduled = bundle.id; status = 'queued_for_restart';
        if (signedPending) {
          save(storageKey('attempt'), { id: bundle.id, version: signedPending.version, sequence: signedPending.sequence,
            launchId: launchId, envelope: signedEnvelope });
          save(storageKey('sequence'), signedPending.sequence);
        }
        report('update_queued', { source: bundle.version }); return true;
      });
    }).catch(function () { status = 'queue_failed'; return false; }).then(function (ok) { busy = false; return ok; });
  }
  function init(isSafe) {
    if (initialized) return;
    initialized = true; safe = isSafe || safe;
    try {
      var cap = window.Capacitor;
      if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) { status = 'browser'; return; }
      plugin = cap.Plugins && cap.Plugins.CapacitorUpdater;
      if (!plugin && cap.registerPlugin) plugin = cap.registerPlugin('CapacitorUpdater');
      if (!plugin) { status = 'plugin_missing'; return; }
      status = 'booting';
      var listeners = {
        downloadFailed: function () { status = 'download_failed'; report('update_failed', { reason: 'download' }); },
        updateFailed: function (event) {
          status = 'rolled_back';
          if (event && event.bundle) block(event.bundle.version);
          report('update_failed', { reason: 'boot_rollback' });
        }
      };
      Object.keys(listeners).forEach(function (name) {
        try { Promise.resolve(plugin.addListener(name, listeners[name])).catch(function () {}); } catch (e) {}
      });
      app = cap.Plugins && cap.Plugins.App;
      if (!app && cap.registerPlugin) app = cap.registerPlugin('App');
    } catch (e) { status = 'plugin_error'; }
  }
  function healthyFrame() {
    if (!plugin || ready || failed || ++frames < 3) return;
    ready = true;
    call('notifyAppReady').then(function () {
      status = 'ready'; report('update_booted', {}); check();
    }).catch(function () { ready = false; failed = true; status = 'ready_failed'; });
  }
  function block(version) {
    var blocked = read(storageKey('blocked'));
    if (!Array.isArray(blocked)) blocked = [];
    if (typeof version === 'string' && blocked.indexOf(version) < 0) blocked.push(version);
    save(storageKey('blocked'), blocked.slice(-20));
  }
  function fetchManifest(url) {
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    var timer;
    return Promise.race([
      fetch(url, { credentials: 'omit', cache: 'no-store', signal: controller ? controller.signal : undefined })
        .then(function (r) { if (!r.ok) throw new Error('manifest_http'); return r.text(); })
        .then(function (body) { if (body.length > 16384) throw new Error('manifest_size'); return JSON.parse(body); }),
      new Promise(function (_, reject) { timer = setTimeout(function () {
        if (controller) controller.abort(); reject(new Error('manifest_timeout'));
      }, 8000); })
    ]).then(function (result) { clearTimeout(timer); return result; }, function (err) { clearTimeout(timer); throw err; });
  }
  function check() {
    var cfg = config(), url = cfg.manifestUrls && cfg.manifestUrls[os()];
    if (!plugin || !app || !ready || failed || !cfg.enabled || !url || !cfg.publicKey || typeof fetch !== 'function') return Promise.resolve(false);
    if (checking) return checking;
    if (lastCheck && Date.now() - lastCheck < Math.max(60, Number(cfg.checkIntervalSeconds) || 900) * 1000) return Promise.resolve(false);
    if (!/^https:\/\//.test(url)) { status = 'invalid_host'; return Promise.resolve(false); }
    lastCheck = Date.now(); status = 'checking';
    checking = Promise.all([app.getInfo(), call('current'), call('getNextBundle')]).then(function (results) {
      nativeInfo = results[0]; current = results[1].bundle;
      if (nativeInfo.id !== 'com.loopdodge.game') throw new Error('unsupported_app');
      var attempt = read(storageKey('attempt'));
      if (attempt && current && attempt.version !== current.version &&
          !(results[2] && results[2].version === attempt.version)) block(attempt.version);
      return fetchManifest(url);
    }).then(function (envelope) {
      signedEnvelope = envelope;
      return UpdateManifest.verify(envelope, cfg.publicKey, {
        platform: os(), environment: cfg.channel, nativeVersion: nativeInfo.version,
        nativeBuild: nativeInfo.build, runtimeFingerprint: cfg.runtimeFingerprint, manifestUrl: url
      });
    }).then(function (manifest) {
      if (!manifest) { status = 'manifest_rejected'; return false; }
      var blocked = read(storageKey('blocked')) || [];
      if (Array.isArray(blocked) && blocked.indexOf(manifest.version) >= 0) { status = 'failed_version_blocked'; return false; }
      if (manifest.sequence < (Number(read(storageKey('sequence'))) || 0)) { status = 'stale_manifest'; return false; }
      if (current && current.version === manifest.version) { status = 'up_to_date'; return false; }
      if (pending && pending.version === manifest.version) return queue();
      status = 'downloading'; signedPending = manifest;
      // The native plugin verifies the ZIP's SHA-256 on BOTH platforms before
      // reporting success. This hash was authenticated by our signed manifest.
      return call('download', { url: manifest.url, version: manifest.version, checksum: manifest.sha256 }).then(function (bundle) {
        if (!bundle || !bundle.id || bundle.status === 'error') throw new Error('download_invalid');
        pending = bundle; status = 'downloaded'; report('update_downloaded', { source: manifest.version });
        return queue();
      });
    }).catch(function () { status = 'check_failed'; return false; }).then(function (ok) { checking = null; return ok; });
    return checking;
  }
  return { prepareLaunch: prepareLaunch, init: init, healthyFrame: healthyFrame,
    bootFailed: function () { if (!ready) { failed = true; status = 'boot_failed'; } },
    atMenu: queue,
    check: check,
    diagnostics: function () { return { status: status, healthy: ready && !failed, pendingVersion: pending ? pending.version : null }; }
  };
})();
