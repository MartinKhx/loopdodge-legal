/* Boot + glue: input, frame loop, auto-pause, and the game-flow
 * policy decisions (when ads show, when haptics fire). */
(function () {
 function bootGame() {
  var canvas = document.getElementById('game');

  /* ---------- haptics (Capacitor native, browser fallback) ---------- */

  function hapticDeath() {
    var mode = Store.getHaptics(); // 'off' | 'light' | 'full'
    if (mode === 'off') return;
    var style = mode === 'light' ? 'LIGHT' : 'HEAVY';
    var ms = mode === 'light' ? 20 : 60;
    try {
      if (window.Capacitor && window.Capacitor.isNativePlatform &&
          window.Capacitor.isNativePlatform() &&
          window.Capacitor.Plugins && window.Capacitor.Plugins.Haptics) {
        window.Capacitor.Plugins.Haptics.impact({ style: style });
      } else if (navigator.vibrate) {
        navigator.vibrate(ms);
      }
    } catch (e) { /* haptics are optional */ }
  }

  /* Soft tick for power-up pickups and combo chains — throttled, so a
   * rapid near-miss chain can't turn the phone into a buzzer. */
  var lastLightHaptic = 0;
  function hapticLight() {
    if (Store.getHaptics() === 'off') return;
    var now = Date.now();
    if (now - lastLightHaptic < 250) return;
    lastLightHaptic = now;
    try {
      if (window.Capacitor && window.Capacitor.isNativePlatform &&
          window.Capacitor.isNativePlatform() &&
          window.Capacitor.Plugins && window.Capacitor.Plugins.Haptics) {
        window.Capacitor.Plugins.Haptics.impact({ style: 'LIGHT' });
      } else if (navigator.vibrate) {
        navigator.vibrate(15);
      }
    } catch (e) { /* haptics are optional */ }
  }

  /* ---------- interstitial cadence ----------
   * Counted when the player LEAVES the game-over panel (Play Again
   * or Menu) so an ad can never collide with the revive decision
   * and never interrupts a run. New players get a grace period: no
   * interstitials at all for their first runs (early interstitials
   * are the #1 churn driver in hypercasual). */
  function maybeInterstitial() {
    var deaths = Store.getDeaths() + 1;
    Store.setDeaths(deaths); // keep the run counter advancing (stats)
    if (AD_CONFIG.rewardedOnly) return Promise.resolve(); // reward-only: never interstitial
    if (deaths <= (AD_CONFIG.graceRuns || 0)) return Promise.resolve();
    if (deaths % AD_CONFIG.interstitialEvery === 0) {
      return Ads.showInterstitial(); // resolves on dismiss/failed/no-ad
    }
    return Promise.resolve();
  }

  /* ---------- resume countdown ----------
   * Resuming a paused run instantly (with spikes already in flight)
   * causes unfair deaths, so the resume tap starts a short 3-2-1
   * countdown and only then unfreezes the game. Re-backgrounding or
   * leaving via the back button cancels it. */
  var counting = false;
  var countTimer = null;

  function cancelCountdown() {
    counting = false;
    if (countTimer) { clearInterval(countTimer); countTimer = null; }
  }

  function resumeRun() {
    if (counting || Game.state() !== 'paused') return;
    counting = true;
    var n = 3;
    UI.showCountdown(n);
    Sound.count(false);
    countTimer = setInterval(function () {
      n--;
      if (n > 0) {
        UI.showCountdown(n);
        Sound.count(false);
      } else {
        cancelCountdown();
        Sound.count(true);
        Game.resume();
        UI.showPause(false);
      }
    }, 700);
  }

  /* ---------- wire UI <-> game ---------- */

  // ×2 GEMS rewarded offer: once per successful double per run. The
  // declined flags remember a failed/skipped ad on the current panel
  // so a late-loading ad doesn't resurrect an offer the player passed
  // on (see Ads.onRewardedReady below).
  var doubledThisRun = false;
  var reviveDeclined = false;
  var doubleDeclined = false;
  var lastOver = null;   // the game-over summary currently on screen
  var dailyMode = false; // current run is today's seeded challenge
  var dailyPractice = false; // current daily run is an UNRANKED practice replay
  var seedRunSeed = null; // current run is an Oracle SEED run (a shared seed code), else null

  function resetRunFlags() {
    doubledThisRun = false;
    reviveDeclined = false;
    doubleDeclined = false;
    seedRunSeed = null; // a fresh non-seed run unless onSeedRun re-sets it
    // Frame-loop recovery (Phase 2): if the render-loop circuit-breaker halted
    // the engine, starting a fresh run clears the trip so it ticks again. The
    // rAF chain is still alive (idling), so no re-arm is needed here.
    frameHalted = false;
    frameThrows = 0;
  }

  /* Options for a PERSONAL (non-daily) run. Carries the Forge Seed: an attuned
   * relic biased into the opening Pact. The daily NEVER uses these — it passes
   * its own seeded streams and no seed, so the shared challenge stays identical. */
  function personalOpts() {
    var seed = Store.getRelicSeed();
    // only honor a seed that's still discovered AND attuned (a reset clears both)
    if (seed && Store.isRelicAttuned(seed) && Relics.byId(seed)) return { seedRelic: seed };
    return {};
  }

  UI.init({
    onPlay: function () {
      resetRunFlags();
      dailyMode = false;
      UI.setMult(Levels.current().mult);
      Game.startRun(personalOpts());
      UI.showHUD();
    },
    onDaily: function () {
      resetRunFlags();
      dailyMode = true;
      // First tap of the day = the OFFICIAL ranked attempt; persist that it
      // was used NOW (startChallenge) so a force-close can't dodge it. After
      // that, taps replay the same seed UNRANKED (practice, no reward).
      dailyPractice = !Daily.startChallenge();
      UI.setMult(1); // the challenge always runs on the plain loop
      // Ghost: race your best tape for TODAY's seed (shows from the 2nd run on).
      var gd = Store.getGhostDaily();
      var ghost = (gd && gd.date === Daily.todayStr()) ? gd : null;
      Game.startRun({ rng: Daily.challengeRng(), relicRng: Daily.challengeRelicRng(), levelId: 'loop', ghost: ghost,
        analyticsMode: dailyPractice ? 'daily_practice' : 'daily_ranked' });
      UI.showHUD();
    },
    onRestart: function () {
      maybeInterstitial().then(function () {
        resetRunFlags();
        dailyMode = false;
        UI.setMult(Levels.current().mult);
        Game.startRun(personalOpts());
        UI.showHUD();
      });
    },
    onZen: function () {
      resetRunFlags();
      dailyMode = false;
      UI.setMult(Levels.current().mult);
      Game.startRun({ zen: true }); // no-fail; no seed, no ghost, no economy
      UI.showHUD();
      UI.setZenHud(true);
    },
    onZenExit: function () {
      Game.toMenu();
      UI.showMenu();
    },
    onSeedRun: function (seed) {
      resetRunFlags();
      dailyMode = false;
      seedRunSeed = seed; // a shared-seed personal run, racing your best ghost for it
      UI.setMult(1);      // seed runs use the plain loop (the shared geometry)
      var sg = Store.getGhostSeed();
      var ghost = (sg && sg.seed === seed) ? sg : null;
      Game.startRun({ rng: Daily.seededRng(seed), relicRng: Daily.seededRng(seed + 1), levelId: 'loop', ghost: ghost });
      UI.showHUD();
    },
    onMenu: function () {
      maybeInterstitial().then(function () {
        Game.toMenu();
        UI.showMenu();
      });
    },
    onRevive: function () {
      Ads.showRewarded('revive').then(function (earned) {
        // the ad resolves async: the player may have left the panel
        // (back button / MENU / PLAY AGAIN) while it was pending —
        // only resume if the dead run is still on screen
        if (earned && Game.state() === 'over') {
          reviveDeclined = false;
          doubleDeclined = false; // fresh panel after the next death
          UI.hideGameOver();
          UI.showHUD();
          Game.revive();
        } else if (!earned) {
          reviveDeclined = true;
          UI.hideRevive(); // ad failed/skipped: offer is gone, panel stays
        }
      });
    },
    onDouble: function () {
      Ads.showRewarded('double_gems').then(function (earned) {
        if (earned && lastOver && !doubledThisRun) {
          doubledThisRun = true;
          Store.addGems(lastOver.runGems); // grant the second helping
          UI.markDoubled(lastOver.runGems * 2);
          UI.refreshMenuGems(); // in case the player already left to the menu
          Sound.unlockSkin();
        } else {
          doubleDeclined = true;
          UI.hideDouble(); // failed/skipped: offer is gone, panel stays
        }
      });
    },
    onResume: resumeRun
  });

  Game.init(canvas, {
    onScore: UI.setScore,
    onGems: UI.setRunGems,
    onRate: UI.setMult,   // live gems-per-pickup, incl. relics drafted mid-run
    onNearMiss: function (n) {
      UI.showCombo(n);
      if (n >= 2) hapticLight(); // only chained near misses buzz
    },
    onPower: function () { hapticLight(); },
    onBestPass: function () {
      UI.showMilestone(I18n.t('BEST!'), true);
      Sound.bestFlash();
      hapticLight();
    },
    onStorm: UI.showStorm,
    onPot: UI.showPot,
    onSphere: function (sphere) { UI.setSphere(sphere); if (window.Analytics) Analytics.track('sphere_reached', { sphere: sphere }); },
    onRelic: function (relic) { UI.showRelic(relic); hapticLight(); if (window.Analytics) Analytics.track('relic_chosen', { relic_id: relic.id }); },
    onRelicRail: UI.setRelicRail,
    onGhostPassed: function () { UI.showMilestone(I18n.t('PASSED YOUR GHOST'), false); Sound.bestFlash(); hapticLight(); },
    onWarden: function (w) { UI.showWarden(w); hapticDeath(); if (window.Analytics) Analytics.track('warden_started', {}); },
    onWardenTick: function (pct) { UI.wardenTick(pct); },
    onWardenEnd: function (survived) { UI.endWarden(survived); if (survived) hapticLight(); if (window.Analytics) Analytics.track('warden_ended', { success: survived }); },
    onTutorial: function (shown) { UI.showTutorial(shown); if (!shown && window.GameServices) GameServices.tutorialCompleted(); },
    onDeath: hapticDeath,
    onGameOver: function (d) {
      lastOver = d;
      // no revive on the daily challenge: an ad-bought clear screen
      // would buy the 30s goal and distort the shared seeded run
      d.showRevive = d.canRevive && !dailyMode && Ads.isRewardedReady();
      // also suppressed on the daily: a free ad-funded x2 on top of the
      // seeded contest is the same asymmetry the revive guard avoids
      d.showDouble = !doubledThisRun && !dailyMode && d.runGems > 0 && Ads.isRewardedReady();
      if (window.Analytics) {
        if (d.showRevive) Analytics.track('revive_offered', {});
        if (d.showDouble) Analytics.track('double_offered', {});
      }
      // XP first, so a "reach player level N" mission sees the new level
      var xpRes = XP.addRun(d.secondsDelta);
      d.missionsDone = Missions.onRunEnd(d); // grants rewards, returns toasts
      if (dailyMode) {
        d.practice = dailyPractice; // practice replays never update the ranked best/reward
        var dcReward = Daily.recordChallenge(d);
        if (dcReward && window.Analytics) Analytics.track('daily_challenge_completed', { amount: dcReward });
        if (dcReward) d.missionsDone.push({ text: I18n.t('Daily challenge beaten'), reward: dcReward });
        // Ghost: keep the best tape for today's seed, so the next run races it.
        // The daily can't be revived, so d.ghostTape is a single, complete run.
        if (d.ghostTape && d.ghostTape.end > 0) {
          var today = Daily.todayStr();
          var prevG = Store.getGhostDaily();
          if (!prevG || prevG.date !== today || d.ghostTape.score > prevG.score) {
            Store.setGhostDaily({
              date: today, start: d.ghostTape.start, sw: d.ghostTape.sw,
              end: d.ghostTape.end, score: d.ghostTape.score
            });
          }
        }
      }
      // Ghost: a Seed run keeps the best tape for that seed code, so the next
      // race against it shows your best. (Seed runs can revive; the deeper
      // finalize wins on score.)
      if (seedRunSeed !== null && d.ghostTape && d.ghostTape.end > 0) {
        var prevS = Store.getGhostSeed();
        if (!prevS || prevS.seed !== seedRunSeed || d.ghostTape.score > prevS.score) {
          Store.setGhostSeed({
            seed: seedRunSeed, start: d.ghostTape.start, sw: d.ghostTape.sw,
            end: d.ghostTape.end, score: d.ghostTape.score
          });
        }
      }
      // lifetime stats: always the delta fields — a revived run
      // finalizes twice, naive totals would double-count. (Gems-
      // collected lives in the engine's bankGems, NOT here, so it
      // also counts runs the player backs out of.)
      Store.setNearTotal(Store.getNearTotal() + d.nmDelta);
      Store.setTimeTotal(Store.getTimeTotal() + d.secondsDelta);
      Store.setStormsSurvived(Store.getStormsSurvived() + d.stormsDelta);
      if (d.bestCombo > Store.getComboBest()) Store.setComboBest(d.bestCombo);
      PlayGames.onRunEnd(d); // leaderboard + achievements (no-op without plugin)
      // Play review only when no revive decision shares the panel —
      // the once-per-install ask must never sit on top of that choice
      // (a revived run re-finalizes with showRevive false, so a
      // new-best run still gets its prompt at the true end)
      if (!d.showRevive) Review.maybePrompt(d);
      UI.showGameOver(d);
      if (xpRes.ups.length) UI.showLevelUp(xpRes.ups);
      if (d.isNewBest) {
        Sound.newBest();
        Game.celebrate();
      }
    }
  });

  /* ---------- input ---------- */

  canvas.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    Sound.unlock();
    Game.onTap();
  });

  // unlock audio on the very first interaction anywhere (incl. buttons)
  document.addEventListener('pointerdown', function () { Sound.unlock(); }, { capture: true });

  // desktop convenience: Space / ArrowUp switch lanes
  document.addEventListener('keydown', function (e) {
    if (e.code === 'Space' || e.code === 'ArrowUp') {
      e.preventDefault();
      Sound.unlock();
      if (Game.state() === 'paused') {
        resumeRun();
      } else {
        Game.onTap();
      }
    }
  });

  /* ---------- auto-pause when backgrounded mid-run ---------- */

  var appActive = true;
  function onAppActivity(isActive) {
    if (appActive === isActive) return;
    appActive = isActive;
    if (!isActive) {
      // a resume countdown in flight is void; back to the PAUSED face
      if (counting) {
        cancelCountdown();
        UI.showPause(true);
      }
      if (Game.pause()) UI.showPause(true);
      Notify.scheduleStreakReminder(); // streak nudge ~20h out (native only)
    } else {
      Sound.unlock(); // resume a suspended AudioContext
      Notify.cancel(); // player is back — no reminder needed
    }
  }
  document.addEventListener('visibilitychange', function () { onAppActivity(!document.hidden); });
  // Android WebViews may remain "visible" while the native activity is in
  // the background. Both signals use one handler so they cannot double-pause
  // a run or restart the resume countdown.
  try {
    var lifecycleApp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (lifecycleApp) Promise.resolve(lifecycleApp.addListener('appStateChange', function (event) {
      onAppActivity(event.isActive);
    })).catch(function () {});
  } catch (e) { /* browser or unavailable native bridge */ }

  /* ---------- Android hardware back button (native only) ----------
   * Priority: close an open modal/shop first (back with the shop open
   * used to EXIT the app, because Game.state() is 'menu' under it),
   * then pause a live run, then leave pause/game-over to the menu,
   * and only exit from the bare menu. */
  try {
    if (window.Capacitor && window.Capacitor.isNativePlatform &&
        window.Capacitor.isNativePlatform() &&
        window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
      window.Capacitor.Plugins.App.addListener('backButton', function () {
        if (window.GameServices && GameServices.dismissConsent()) return;
        if (UI.closeTopModal()) return;
        var s = Game.state();
        if (s === 'menu') {
          window.Capacitor.Plugins.App.exitApp();
        } else if (s === 'playing') {
          if (Game.pause()) UI.showPause(true);
        } else if (s === 'dying') {
          // let the death animation finish; the panel is a moment away
        } else {
          // paused or game over: to the menu (no ad, but a finished run
          // must still advance the interstitial/stats run counter)
          if (s === 'over') Store.setDeaths(Store.getDeaths() + 1);
          // The official daily attempt is already persisted at START
          // (Daily.startChallenge), so abandoning mid-run can't dodge it.
          // Just clear the daily flags on the way out.
          if (dailyMode) { dailyMode = false; dailyPractice = false; }
          cancelCountdown();
          Game.toMenu();
          UI.showMenu();
        }
      });
    }
  } catch (e) { /* plugin optional */ }

  /* ---------- resize & frame loop ---------- */

  window.addEventListener('resize', function () { Game.resize(); });

  /* Frame-loop guard (Phase 2, STAB-03/04). A throw from Game.update/render
   * must NOT kill the rAF chain and silently freeze the game (App Review reads
   * a hang as a crash — Guideline 2.1). We wrap the two engine calls, re-arm in
   * `finally` so a transient one-frame throw recovers next frame, and trip a
   * consecutive-throw circuit-breaker so a hard-wedged loop bails to the menu
   * instead of storming telemetry 60x/s. Module-level state = no per-frame
   * allocation; the happy path is byte-identical (determinism/perf invariants). */
  var last = performance.now();
  var frameThrows = 0;         // consecutive throwing frames
  var frameHalted = false;     // true once the breaker trips: idle (don't tick) the loop
  var FRAME_THROW_LIMIT = 5;   // give a transient glitch room, halt a wedge fast
  function frame(now) {
    var dt = Math.min((now - last) / 1000, 0.05); // clamp huge tab-switch deltas
    last = now;
    if (!frameHalted) {
      try {
        Game.update(dt);
        Game.render();
        if (window.LiveUpdates) LiveUpdates.healthyFrame();
        frameThrows = 0;       // a clean frame resets the breaker
      } catch (e) {
        if (window.LiveUpdates) LiveUpdates.bootFailed();
        frameThrows++;
        // Report the first throw of an incident, never 60x/s.
        if (frameThrows === 1 && window.Telemetry) Telemetry.report(e);
        if (frameThrows >= FRAME_THROW_LIMIT) {
          // Sustained failure: idle the loop (stop ticking the engine) and bail
          // to the menu. resetRunFlags() clears frameHalted when the player
          // starts a new run, so a wedge that clears can recover.
          frameHalted = true;
          // Distinct halt event so crash data separates a self-healed transient
          // throw from an abandoned run (one extra report — still no storm).
          if (window.Telemetry) Telemetry.report(new Error('frame loop halted after ' + frameThrows + ' consecutive throws'));
          try { Game.toMenu(); } catch (e2) {}
          try { UI.showMenu(); } catch (e3) {}
        }
      }
    }
    // ALWAYS re-arm: the loop idles when halted but is never dead, so it can be
    // resumed (and the attract canvas stays live) without an app relaunch.
    requestAnimationFrame(frame);
  }

  /* ---------- go ---------- */

  if (Game.setGhost) Game.setGhost(!Store.getGhostOff()); // honor the saved ghost preference
  UI.showMenu();
  if (window.GameServices) GameServices.init();
  requestAnimationFrame(frame);

  /* A rewarded ad finished loading: let already-open panels show
   * their ad buttons. Offers the player declined on this panel stay
   * hidden. Registered before Ads.init() so the first load counts. */
  Ads.onRewardedReady(function () {
    UI.adsReady(); // shop / custom-skin modal
    if (Game.state() === 'over' && lastOver) {
      UI.refreshOffers(
        lastOver.canRevive && !dailyMode && !reviveDeclined && Ads.isRewardedReady(),
        !doubledThisRun && !dailyMode && !doubleDeclined && lastOver.runGems > 0 && Ads.isRewardedReady()
      );
    }
  });

  Ads.init(); // fire-and-forget; the game never waits on ads
  PlayGames.init(); // fire-and-forget; silently absent without the plugin
  // billing plugin announces itself via deviceready (Cordova-compat event)
  if (window.CdvPurchase) { Iap.init(); }
  else { document.addEventListener('deviceready', function () { Iap.init(); }); Iap.init(); }

  // Ultra Pass perk: a flat 500-gem daily gift, granted once per local day on
  // launch. Uses addGemsRaw so the pass's own x3 never compounds the gift.
  if (Store.getUltraPass() && Store.getUltraGiftDay() !== Daily.todayStr()) {
    Store.setUltraGiftDay(Daily.todayStr());
    Store.addGemsRaw(500);
    if (UI.refreshMenuGems) UI.refreshMenuGems();
  }

  // console handle for debugging / automated tests
  window.LoopDodge = { Game: Game, Ads: Ads, Store: Store, Skins: Skins, Levels: Levels,
                       Daily: Daily, Missions: Missions, PlayGames: PlayGames, Relics: Relics,
                       Ghost: Ghost, XP: XP, Trails: Trails, Themes: Themes, Review: Review, Notify: Notify, Telemetry: Telemetry,
                       Analytics: window.Analytics, RemoteConfig: window.RemoteConfig, LiveUpdates: window.LiveUpdates };
 }
 // Finish a previously queued update before binding PLAY or starting frames.
 // A successful native `set` reloads into the new bundle, whose boot clears inert.
 if (window.LiveUpdates && LiveUpdates.prepareLaunch) {
   document.body.inert = true;
   LiveUpdates.prepareLaunch().then(function (start) {
     if (start !== false) { document.body.inert = false; bootGame(); }
   }, function () { document.body.inert = false; bootGame(); });
 } else bootGame();
})();
