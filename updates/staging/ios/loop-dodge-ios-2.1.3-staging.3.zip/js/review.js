/* Play in-app review prompt (@capacitor-community/in-app-review),
 * wrapped fail-safe like ads.js: in a browser, without the plugin, or
 * on any error it silently does nothing and the game is unaffected.
 *
 * Policy: ask ONCE per install, and only at the peak-goodwill moment —
 * a NEW BEST on the player's 3rd or later finished run. The Play API
 * itself quota-manages whether anything is actually shown, so this
 * can never turn into spam. Never gates gameplay. */
var Review = (function () {

  function plugin() {
    try {
      if (window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' &&
          window.Capacitor.isNativePlatform() &&
          window.Capacitor.Plugins && window.Capacitor.Plugins.InAppReview) {
        return window.Capacitor.Plugins.InAppReview;
      }
    } catch (e) { /* optional */ }
    return null;
  }

  /* Feed the game-over summary; prompts at most once per install. */
  function maybePrompt(d) {
    try {
      if (!d || !d.isNewBest) return;
      if (Store.getReviewAsked()) return;
      // deaths counts runs whose panel was already LEFT, so it is one
      // behind the run that just finalized: >= 2 means "3rd+ run"
      if (Store.getDeaths() < 2) return;
      var p = plugin();
      if (!p || !p.requestReview) return;
      // mark BEFORE the call: one attempt per install, even if it fails
      Store.setReviewAsked(true);
      p.requestReview().catch(function () { /* quota/failure: stay silent */ });
    } catch (e) { /* review is optional */ }
  }

  return { maybePrompt: maybePrompt };
})();
