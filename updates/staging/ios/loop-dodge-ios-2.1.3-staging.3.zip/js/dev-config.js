/* DEV / testing build flag.
 *
 * true  -> unlimited gems (balance pinned at 999999) + DEV badge.
 * false -> normal game.
 *
 * DO NOT edit this by hand for release builds. `npm run apk:dev`
 * flips it to true, builds "Loop Dodge DEV" (separate app id, so it
 * installs next to the real game), then restores it to false and
 * re-syncs — the production build can never accidentally ship it. */
var DEV_MODE = false;

/* UMP consent debug (developer-only; see ads.js consentOpts()).
 *
 * Google's User Messaging Platform only shows the consent form to users it
 * believes are in a regulated geography, so the EEA flow is untestable from
 * anywhere else unless you fake the geography for a REGISTERED test device.
 *
 * To exercise it locally, set BOTH of these AND DEV_MODE = true:
 *   CONSENT_DEBUG_GEOGRAPHY = 'EEA';       // or 'NOT_EEA'
 *   CONSENT_TEST_DEVICES    = ['<hash>'];  // Logcat (Android) / Xcode console (iOS)
 * Any other value (or an empty device list) leaves the consent request
 * completely unchanged.
 *
 * RELEASE SAFETY: `npm run preflight` FAILS a release while either value is
 * set, so these can never ship. Revert both before building. */
var CONSENT_DEBUG_GEOGRAPHY = '';   // '' | 'EEA' | 'NOT_EEA'
var CONSENT_TEST_DEVICES = [];      // hashed device ids, e.g. ['33BE22...E231']
