/* DOM layer: menu, HUD, game-over panel, pause overlay, skin shop.
 * Game-flow decisions live in main.js; this file only shows things
 * and forwards button presses through the callbacks given to init(). */
var UI = (function () {
  var el = {};
  var cb = {};

  function $(id) { return document.getElementById(id); }

  function init(callbacks) {
    cb = callbacks;
    el.menu = $('menu');
    el.hud = $('hud');
    el.gameover = $('gameover');
    el.pause = $('pauseOverlay');
    el.pausedBox = $('pausedBox');
    el.countNum = $('countNum');
    el.score = $('score');
    el.depthTag = $('depthTag');
    el.relicRail = $('relicRail');
    el.relicToast = $('relicToast');
    el.wardenBanner = $('wardenBanner');
    el.wardenName = $('wardenName');
    el.wardenBarFill = $('wardenBarFill');
    el.combo = $('combo');
    el.milestone = $('milestone');
    el.runRecap = $('runRecap');
    el.descentRecap = $('descentRecap');
    el.descentSphere = $('descentSphere');
    el.descentSouls = $('descentSouls');
    el.descentRelics = $('descentRelics');
    el.recapNm = $('recapNm');
    el.recapCombo = $('recapCombo');
    el.nextUnlock = $('nextUnlock');
    el.nextUnlockText = $('nextUnlockText');
    el.nextFill = $('nextFill');
    el.runGemsVal = $('runGemsVal');
    el.menuBest = $('menuBest');
    el.menuGemsVal = $('menuGemsVal');
    el.menuSouls = $('menuSouls');
    el.skinRow = $('skinRow');
    el.levelRow = $('levelRow');
    el.trailRow = $('trailRow');
    el.themeRow = $('themeRow');
    el.storm = $('storm');
    el.levelUpModal = $('levelUpModal');
    el.levelUpModal.addEventListener('pointerdown', function () {
      el.levelUpModal.classList.add('hidden');
    });
    el.missionList = $('missionList');
    el.toasts = $('toasts');
    el.multBadge = $('multBadge');
    el.multUltra = $('multUltra');
    el.newBest = $('newBest');
    el.finalScore = $('finalScore');
    el.overBest = $('overBest');
    el.overGems = $('overGems');
    el.overUltra = $('overUltra');
    el.ultraChip = $('ultraChip');
    el.reviveBtn = $('reviveBtn');
    el.x2Btn = $('x2Btn');
    el.bestFill = $('bestFill');
    el.muteOn = $('muteIconOn');
    el.muteOff = $('muteIconOff');

    $('playBtn').addEventListener('click', function () { Sound.click(); cb.onPlay(); });

    el.dailyBtn = $('dailyBtn');
    el.dailyBtn.addEventListener('click', function () { Sound.click(); cb.onDaily(); });
    // Zen Drift: a no-fail endless mode (a calm alternative to the run)
    el.zenExit = $('zenExit');
    $('zenBtn').addEventListener('click', function () { Sound.click(); cb.onZen(); });
    el.zenExit.addEventListener('click', function () { Sound.click(); cb.onZenExit(); });
    $('restartBtn').addEventListener('click', function () { Sound.click(); cb.onRestart(); });
    $('menuBtn').addEventListener('click', function () { Sound.click(); cb.onMenu(); });
    el.reviveBtn.addEventListener('click', function () { Sound.click(); cb.onRevive(); });
    el.x2Btn.addEventListener('click', function () { Sound.click(); cb.onDouble(); });
    el.pause.addEventListener('pointerdown', function () { cb.onResume(); });

    $('muteBtn').addEventListener('click', function () {
      Sound.setMuted(!Sound.isMuted());
      syncMute();
      Sound.click();
    });
    el.musicOn = $('musicIconOn');
    el.musicOff = $('musicIconOff');
    $('musicBtn').addEventListener('click', function () {
      Sound.setMusicOff(!Sound.isMusicOff());
      syncMute();
      Sound.click();
    });

    // accessibility: reduce motion (shake / hit-stop / death zoom off)
    el.motionBtn = $('motionBtn');
    el.motionBtn.addEventListener('click', function () {
      var on = !Store.getReduceMotion();
      Store.setReduceMotion(on);
      Game.setReduceMotion(on);
      syncMotion();
      Sound.click();
    });
    syncMotion();

    // shop (a hub tab, not an overlay)
    el.shop = $('tabShop');
    el.shopList = $('shopList');
    el.shopFeatured = $('shopFeatured');
    el.shopGemsVal = $('shopGemsVal');
    el.shopNote = $('shopNote');
    el.freeGemsBtn = $('freeGemsBtn');
    el.freeGemsBtn.addEventListener('click', function () {
      Sound.click();
      el.freeGemsBtn.disabled = true;
      Ads.showRewarded().then(function (earned) {
        el.freeGemsBtn.disabled = false;
        if (earned && Daily.claimShopGems()) Sound.unlockSkin();
        buildShop(); // hides the button once claimed (or the ad is gone)
        el.menuGemsVal.textContent = Store.getGems();
      });
    });
    // Inline free-gems claim (no separate shop screen): the menu button IS the
    // rewarded-ad claim, and showMenu only shows it when an ad is ready + the
    // daily bonus is unclaimed.
    el.shopBtn = $('shopBtn');
    el.shopBtn.addEventListener('click', function () {
      Sound.click();
      el.shopBtn.disabled = true;
      Ads.showRewarded().then(function (earned) {
        el.shopBtn.disabled = false;
        if (earned && Daily.claimShopGems()) Sound.unlockSkin();
        el.menuGemsVal.textContent = Store.getGems();
        showMenu(); // re-evaluate visibility (hidden once claimed / no ad)
      });
    });

    // Forge (relic Codex + Soul-funded Seed attunement) — lives in the
    // GEAR tab's RELICS section now, no modal
    el.forgeSouls = $('forgeSouls');
    el.forgeSeedName = $('forgeSeedName');
    el.forgeCodex = $('forgeCodex');
    el.forgeHint = $('forgeHint');

    // Oracle (Descent records + shareable seed codes / Ghost Race)
    el.oracleModal = $('oracleModal');
    el.oracleInput = $('oracleInput');
    $('oracleBtn').addEventListener('click', function () { Sound.click(); openOracle(); });
    $('oracleClose').addEventListener('click', function () { Sound.click(); closeOracle(); });
    $('oracleRace').addEventListener('click', function () { onOracleRace(); });

    // lifetime stats
    el.statsModal = $('statsModal');
    el.statsList = $('statsList');
    $('statsBtn').addEventListener('click', function () { Sound.click(); openStats(); });
    $('statsClose').addEventListener('click', function () {
      Sound.click();
      el.statsModal.classList.add('hidden');
      restoreModalFocus();
    });

    // how-to-play guide
    el.guideModal = $('guideModal');
    $('guideBtn').addEventListener('click', function () {
      Sound.click();
      openModalFocus(el.guideModal);
      // focusing CLOSE (the only button, at the end) scrolls the panel to the
      // bottom — snap back so the guide always opens on THE RUN
      el.guideModal.scrollTop = 0;
    });
    $('guideClose').addEventListener('click', function () {
      Sound.click();
      el.guideModal.classList.add('hidden');
      restoreModalFocus();
    });

    // first-visit GEAR orientation tip (dismissed once, forever)
    el.gearTip = $('gearTip');
    $('gearTipOk').addEventListener('click', function () {
      Sound.click();
      Store.markTipSeen('gear');
      el.gearTip.classList.add('hidden');
    });

    // settings (accessibility + ad privacy + reset)
    el.settingsModal = $('settingsModal');
    $('settingsBtn').addEventListener('click', function () { Sound.click(); openSettings(); });
    $('settingsClose').addEventListener('click', function () { Sound.click(); closeSettings(); });
    // language: cycles AUTO (follow the device) -> each supported locale
    $('setLangBtn').addEventListener('click', function () {
      var order = [''].concat(I18n.SUPPORTED);
      var next = order[(order.indexOf(I18n.getLang()) + 1) % order.length];
      I18n.setLang(next);   // persists, re-resolves, re-translates static DOM
      Sound.click();
      relocalize();
    });
    // sound rows mirror the floating in-run toggles (icons hide on the menu)
    $('setSoundBtn').addEventListener('click', function () {
      Sound.setMuted(!Sound.isMuted());
      syncMute(); syncSettings(); Sound.click();
    });
    $('setMusicBtn').addEventListener('click', function () {
      Sound.setMusicOff(!Sound.isMusicOff());
      syncMute(); syncSettings(); Sound.click();
    });
    $('setFlashBtn').addEventListener('click', function () {
      var on = !Store.getReduceFlash();
      Store.setReduceFlash(on);
      if (Game.setReduceFlash) Game.setReduceFlash(on);
      Sound.click(); syncSettings();
    });
    $('setMotionBtn2').addEventListener('click', function () {
      var on = !Store.getReduceMotion();
      Store.setReduceMotion(on); Game.setReduceMotion(on); syncMotion(); Sound.click(); syncSettings();
    });
    $('setHapticsBtn').addEventListener('click', function () {
      var order = ['full', 'light', 'off'];
      Store.setHaptics(order[(order.indexOf(Store.getHaptics()) + 1) % order.length]);
      Sound.click(); syncSettings();
    });
    $('setGhostBtn').addEventListener('click', function () {
      var wasOff = Store.getGhostOff();
      Store.setGhostOff(!wasOff);            // flip the disabled flag
      if (Game.setGhost) Game.setGhost(wasOff); // new enabled state == old off state
      Sound.click(); syncSettings();
    });
    /* Privacy options: re-sync AFTER the form settles, not before. The consent
     * state (and therefore the row's own visibility and every rewarded-ad
     * affordance) can flip inside showPrivacyOptions(), which only resolves
     * once it has re-queried UMP. */
    $('setPrivacyBtn').addEventListener('click', function () {
      Sound.click();
      if (!Ads.showPrivacyOptions) { syncSettings(); return; }
      var p = Ads.showPrivacyOptions();
      if (p && p.then) {
        p.then(function () { syncSettings(); adsReady(); });
      } else {
        syncSettings();
      }
    });
    $('setDeletePhotoBtn').addEventListener('click', function () {
      Sound.click(); Store.clearCustomSkin();
      if (Store.getSkin() === 'custom') { Store.setSkin('neon'); applyAccent(); Game.refreshSkin(); buildSkinRow(); }
      syncSettings();
    });
    $('setResetBtn').addEventListener('click', function () {
      // destructive: require a second confirming tap
      if (!resetArmed) { resetArmed = true; $('setResetLabel').textContent = I18n.t('Tap again to ERASE everything'); el.setResetBtn.classList.add('armed'); Sound.deny(); return; }
      Store.resetAll(); Sound.click();
      resetArmed = false;
      closeSettings();
      if (Themes.select) Themes.select('classic');
      Game.refreshSkin(); Game.refreshLevel(); Game.refreshTrail();
      if (Game.refreshTheme) Game.refreshTheme();
      syncMute(); syncMotion();
      showMenu();
    });

    // keyboard: Escape closes the top modal, Tab is trapped inside it
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { if (closeTopModal()) e.preventDefault(); return; }
      if (e.key === 'Tab') { var top = topModal(); if (top) trapTab(e, top); }
    });

    el.ranksBtn = $('ranksBtn');
    el.ranksBtn.addEventListener('click', function () { Sound.click(); PlayGames.showLeaderboard(); });
    $('storeBtn').addEventListener('click', function () { Sound.click(); openShop(); });

    // menu hub: bottom tab bar + top-bar chips (storeBtn above IS the shop tab)
    el.tabHome = $('tabHome');
    el.tabStyle = $('tabStyle');
    el.tabMore = $('tabMore');
    el.tabBtnHome = $('tabBtnHome');
    el.tabBtnStyle = $('tabBtnStyle');
    el.tabBtnMore = $('tabBtnMore');
    el.storeBtn = $('storeBtn');
    el.soulChip = $('soulChip');
    el.trackChip = $('trackChip');
    el.tabBtnHome.addEventListener('click', function () { Sound.click(); setMenuTab('home'); });
    el.tabBtnStyle.addEventListener('click', function () { Sound.click(); setMenuTab('style'); });
    el.tabBtnMore.addEventListener('click', function () { Sound.click(); setMenuTab('more'); });
    $('gemChip').addEventListener('click', function () { Sound.click(); openShop(); });
    // the home track chip is a shortcut to CHANGING the track: always land on
    // the TRACKS section, never on whatever gear section was last open
    el.trackChip.addEventListener('click', function () {
      Sound.click();
      setGearSection('tracks');
      setMenuTab('style');
    });

    // GEAR tab: segmented sections (tracks / themes / skins / trails / relics)
    $('gcTracks').addEventListener('click', function () { Sound.click(); setGearSection('tracks'); });
    $('gcThemes').addEventListener('click', function () { Sound.click(); setGearSection('themes'); });
    $('gcSkins').addEventListener('click', function () { Sound.click(); setGearSection('skins'); });
    $('gcTrails').addEventListener('click', function () { Sound.click(); setGearSection('trails'); });
    $('gcRelics').addEventListener('click', function () { Sound.click(); setGearSection('relics'); });
    $('restoreBtn').addEventListener('click', function () {
      Sound.click();
      var btn = this;
      btn.disabled = true;
      var hadAdsRemoved = Store.getAdsRemoved(); // entitlement snapshot for feedback
      el.shopNote.textContent = I18n.t('restoring…');
      Iap.restore().then(function (res) {
        buildShop();                 // repaints rows + shopNote, then we override the note
        btn.disabled = false;
        if (res && res.ok === false) {
          el.shopNote.textContent = I18n.t('restore failed — check your connection and try again');
        } else if (Store.getAdsRemoved() && !hadAdsRemoved) {
          el.shopNote.textContent = I18n.t('purchases restored — thank you!');
        } else {
          el.shopNote.textContent = I18n.t('nothing to restore on this account');
        }
      });
    });
    Iap.onUpdate(function () {
      // fires the moment a grant lands — this is what flips the Ultra Pass
      // to ACTIVE ×3 and re-enables a consumed gem pack, without a reload
      if (shopVisible()) buildShop();
      el.menuGemsVal.textContent = Store.getGems();
      syncUltraChip();
    });

    // daily reward streak
    el.dailyModal = $('dailyModal');
    el.dailyDays = $('dailyDays');
    el.dailyAmount = $('dailyAmount');
    // streak repair: a rewarded ad bridges one missed day (same fail-safe
    // rule as every rewarded placement — only offered with an ad loaded)
    el.streakRepairBtn = $('streakRepairBtn');
    el.streakRepairBtn.addEventListener('click', function () {
      Sound.click();
      el.streakRepairBtn.disabled = true;
      Ads.showRewarded().then(function (earned) {
        el.streakRepairBtn.disabled = false;
        if (earned && Daily.repairStreak()) {
          Sound.unlockSkin();
          Notify.requestPermissionOnce(); // saving a streak shows its value
        }
        // re-render the strip (continued day, button gone) — but only if
        // the modal is still up: a back-press during a stuck/never-shown
        // ad may have dismissed it, and we must not force it back open
        // (mirrors the main.js revive panel-state re-check)
        if (!el.dailyModal.classList.contains('hidden')) maybeShowDaily();
      });
    });
    $('dailyClaim').addEventListener('click', function () {
      var claimed = Daily.claimStreak();
      if (claimed) {
        Sound.unlockSkin();
        el.menuGemsVal.textContent = Store.getGems();
        // day 2+ is the moment the streak has shown its value — the
        // one acceptable time to ask for notification permission
        if (claimed.day >= 2) Notify.requestPermissionOnce();
        Notify.cancel(); // just claimed: today's reminder is moot
      }
      el.dailyModal.classList.add('hidden');
      restoreModalFocus();
    });

    // custom photo skin
    el.customModal = $('customModal');
    el.cuAd = $('cuAd');
    el.skinFile = $('skinFile');
    $('cuBuy').addEventListener('click', onCustomBuy);
    el.cuAd.addEventListener('click', onCustomAd);
    $('cuClose').addEventListener('click', function () {
      Sound.click();
      el.customModal.classList.add('hidden');
      restoreModalFocus();
    });
    el.skinFile.addEventListener('change', function () {
      if (el.skinFile.files && el.skinFile.files[0]) {
        importSkinImage(el.skinFile.files[0]);
        el.skinFile.value = '';
      }
    });

    if (typeof DEV_MODE !== 'undefined' && DEV_MODE) {
      $('devTag').classList.remove('hidden');
    }

    syncMute();
    applyAccent();
    I18n.applyDom(); // translate the static markup once the DOM is wired
  }

  function syncMute() {
    var m = Sound.isMuted();
    el.muteOn.classList.toggle('hidden', m);
    el.muteOff.classList.toggle('hidden', !m);
    var mo = Sound.isMusicOff();
    el.musicOn.classList.toggle('hidden', mo);
    el.musicOff.classList.toggle('hidden', !mo);
    // a11y: icon-only toggles announce state + intent to screen readers
    var mb = $('muteBtn'), mub = $('musicBtn');
    if (mb) { mb.setAttribute('aria-pressed', m ? 'true' : 'false'); mb.setAttribute('aria-label', m ? 'Unmute sound effects' : 'Mute sound effects'); }
    if (mub) { mub.setAttribute('aria-pressed', mo ? 'true' : 'false'); mub.setAttribute('aria-label', mo ? 'Turn music on' : 'Turn music off'); }
  }

  /* The reduce-motion button dims when motion is reduced. */
  function syncMotion() {
    var on = Store.getReduceMotion();
    el.motionBtn.classList.toggle('dimmed', on);
    el.motionBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  /* ---------- IAP shop (a hub tab) ---------- */

  /* The shop is visible when the menu is up with the SHOP tab active. */
  function shopVisible() {
    return el.shop && el.menu &&
      !el.shop.classList.contains('hidden') &&
      !el.menu.classList.contains('hidden');
  }

  function openShop() {
    buildShop();
    setMenuTab('shop');
  }

  /* ---------- Forge (relic Codex + Soul-funded Seed attunement) ----------
   * Souls (earned from Descent depth) buy one thing: ATTUNING a discovered
   * relic, which then SEEDS into your opening Pact for free on personal runs.
   * Lives in the GEAR tab's RELICS section (setGearSection drives it).
   * The Forge never touches gems, the IAP shop, or the daily challenge. */

  var forgeInspect = null; // relic id being read (tap once to inspect, again to act)

  // A one-line explanation of a relic + what tapping again will do — shown in the
  // forge hint so players can read each relic and explore without overspending.
  function forgeDetail(r, seen, att, sel) {
    if (!seen) return I18n.t('Undiscovered relic (tier {n}) — draft it during a run to unlock it.', { n: r.tier });
    var cost = Relics.seedCost(r.id), have = Store.getSouls();
    var d = r.name + (r.cursed ? ' (cursed)' : '') + ' — ' + r.desc + '. ';
    if (sel) return d + I18n.t('Seeded into your opening Pact — tap again to remove.');
    if (att) return d + I18n.t('Attuned — tap again to seed it into your Pact.');
    if (have >= cost) return d + I18n.t('Tap again to attune for {n} Souls.', { n: cost });
    return d + I18n.t('Costs {n} Souls to attune (you have {x}).', { n: cost, x: have });
  }

  function buildForge() {
    el.forgeSouls.textContent = Store.getSouls();
    var seedId = Store.getRelicSeed();
    var seedRel = seedId ? Relics.byId(seedId) : null;
    el.forgeSeedName.innerHTML = seedRel
      ? '<span style="color:' + seedRel.color + '">' + seedRel.name + '</span>'
      : '&mdash;';

    var codex = Store.getRelicCodex();
    el.forgeCodex.innerHTML = '';
    Relics.LIST.forEach(function (r) {
      var seen = codex.indexOf(r.id) !== -1;
      var att = Store.isRelicAttuned(r.id);
      var sel = seedId === r.id;
      var btn = document.createElement('button');
      btn.className = 'relic-tile t' + r.tier +
        (sel ? ' selected' : '') + (seen ? '' : ' locked') + (r.cursed ? ' cursed' : '');
      if (r.id === forgeInspect) btn.style.boxShadow = '0 0 0 2px rgba(160,200,255,0.75)';

      // discovered relics render their procedural icon; undiscovered show a "?"
      var cv = document.createElement('canvas');
      cv.className = 'dot';
      cv.width = 64; cv.height = 64;
      var cc = cv.getContext('2d');
      cc.scale(2, 2);
      if (seen) {
        Relics.drawIcon(cc, 16, 16, 12, r);
      } else {
        cc.fillStyle = 'rgba(140,160,200,0.16)';
        cc.beginPath(); cc.arc(16, 16, 12, 0, Math.PI * 2); cc.fill();
        cc.fillStyle = '#8fa3c8';
        cc.font = '700 16px system-ui, sans-serif';
        cc.textAlign = 'center'; cc.textBaseline = 'middle';
        cc.fillText('?', 16, 17);
      }
      btn.appendChild(cv);

      var tag = document.createElement('span');
      tag.className = 'tag';
      if (!seen) tag.textContent = '???';
      else if (sel) tag.textContent = I18n.t('SEEDED');
      else if (att) tag.textContent = r.name;
      else tag.innerHTML = '&#9671;' + Relics.seedCost(r.id);
      btn.appendChild(tag);

      var label = seen
        ? r.name + (r.cursed ? ' (cursed) — ' : ' — ') + r.desc +
            (att ? (sel ? ' · seeded' : ' · tap to seed') : ' · attune for ' + Relics.seedCost(r.id) + ' souls')
        : 'Undiscovered relic · tier ' + r.tier;
      btn.setAttribute('aria-label', label);
      btn.title = label;

      btn.addEventListener('click', function () { onForgeTap(r, seen, att, sel, btn); });
      el.forgeCodex.appendChild(btn);
    });

    // the section header carries the discovered count now; the hint slot is
    // for reading relics (fixed-height in CSS so inspecting never reflows)
    var gh = $('ghRelics');
    if (gh) gh.textContent = codex.length + '/' + Relics.LIST.length + ' found';
    var ins = forgeInspect ? Relics.byId(forgeInspect) : null;
    el.forgeHint.textContent = ins
      ? forgeDetail(ins, codex.indexOf(ins.id) !== -1, Store.isRelicAttuned(ins.id), seedId === ins.id)
      : (codex.length === 0
        ? I18n.t('Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.')
        : I18n.t('Tap a relic to read what it does — tap again to attune it into your opening Pact.'));
  }

  function denyTile(btn) {
    Sound.deny();
    btn.classList.remove('denied');
    void btn.offsetWidth; // restart the CSS shake
    btn.classList.add('denied');
  }

  function onForgeTap(r, seen, att, sel, btn) {
    // First tap READS the relic (its effect shows in the hint); a second tap on
    // the SAME relic performs the action. Lets players explore without spending.
    if (forgeInspect !== r.id) {
      forgeInspect = r.id;
      if (seen) Sound.click(); else Sound.deny();
      buildForge();
      return;
    }
    if (!seen) { denyTile(btn); return; }                 // never drafted: nothing to do
    if (sel) { Store.setRelicSeed(''); Sound.click(); buildForge(); return; }       // unseat
    if (att) { Store.setRelicSeed(r.id); Sound.unlockSkin(); buildForge(); return; } // free re-seed
    var cost = Relics.seedCost(r.id);                      // first time: attune (pay), then seed
    if (Store.getSouls() >= cost) {
      Store.addSouls(-cost);
      Store.addRelicAttuned(r.id);
      if (window.Analytics) Analytics.track('relic_attuned', { relic_id: r.id, currency: 'Souls', amount: cost });
      Store.setRelicSeed(r.id);
      Sound.unlockSkin();
      buildForge();
    } else {
      denyTile(btn);
    }
  }

  /* ---------- Oracle (Descent records + shareable seed-code Ghost Race) ---------- */

  function openOracle() {
    buildOracle();
    el.menu.classList.add('hidden');
    openModalFocus(el.oracleModal);
  }

  function closeOracle() {
    el.oracleModal.classList.add('hidden');
    showMenu();
    restoreModalFocus(); // a11y: return focus to the opener
  }

  function buildOracle() {
    var deepest = Store.getDeepestSphere();
    $('oracleDeepest').textContent = ROMAN[deepest] || deepest;
    $('oracleSouls').textContent = Store.getSoulsTotal();
    var dc = Daily.challengeState();
    $('oracleDaily').textContent = dc.played ? (dc.best + 's') : '—';
    $('oracleCode').textContent = Ghost.encodeSeed(Daily.challengeSeed()); // today's shareable seed
    el.oracleInput.value = '';
    el.oracleInput.classList.remove('denied');
  }

  /* Enter a 6-char seed code -> start a personal Seed Run on that obstacle
   * field, racing your best ghost for it. (The actual run is the glue's job.) */
  function onOracleRace() {
    var seed = Ghost.decodeSeed(el.oracleInput.value);
    if (seed === null) {
      Sound.deny();
      el.oracleInput.classList.remove('denied');
      void el.oracleInput.offsetWidth;
      el.oracleInput.classList.add('denied');
      return;
    }
    Sound.click();
    el.oracleModal.classList.add('hidden');
    cb.onSeedRun(seed);
  }

  // IAP live: the shop sells gem packs + the Ultra Pass. Products must exist in
  // the store (App Store Connect on iOS, Play Console on Android) or the catalog
  // shows them as unavailable. Set false to hide the purchase catalog again.
  var IAP_ENABLED = true;

  /* One purchase at a time. The store's approval arrives asynchronously, well
   * after order() resolves, so this lock — not the plugin's canPurchase flag —
   * is what prevents a double-tap mid-transaction. */
  var buyInFlight = false;

  /* Wire one BUY button: owned state, price, order flow, re-render. */
  function wireBuy(btn, p) {
    if (p.owned) {
      btn.textContent = I18n.t((p.id === 'ultra_pass') ? 'ACTIVE ×3' : 'OWNED');
      btn.disabled = true;
      return;
    }
    btn.textContent = p.price || '—';
    btn.disabled = !p.canBuy || buyInFlight;
    btn.addEventListener('click', function () {
      if (buyInFlight) return;
      Sound.click();
      buyInFlight = true;
      // a visible working state: the payment sheet and the grant can take
      // several seconds, and a silently-dead button reads as a broken shop
      btn.disabled = true;
      btn.textContent = '···';
      Iap.buy(p.id).then(function (ok) {
        buyInFlight = false;
        if (ok) Sound.unlockSkin();
        // repaint for the order result; Iap.onUpdate repaints again the
        // moment the grant lands, which is when ACTIVE ×3 appears
        buildShop();
        el.menuGemsVal.textContent = Store.getGems();
      });
    });
  }

  /* Featured Ultra Pass card — the pass IS the pitch, so spell its perks out. */
  function ultraCard(p) {
    var card = document.createElement('div');
    card.className = 'ultra-card' + (p.owned ? ' owned' : '');
    card.innerHTML =
      '<div class="ultra-title">ULTRA PASS<span class="ultra-star">&#9733;</span></div>' +
      '<div class="ultra-perk"><span class="ok">&#10003;</span>' + I18n.t('×3 gems from every run — forever') + '</div>' +
      '<div class="ultra-perk"><span class="ok">&#10003;</span>' + I18n.t('+500 {gem} gift every day') + '</div>';
    var btn = document.createElement('button');
    btn.className = 'shop-buy ultra';
    wireBuy(btn, p);
    card.appendChild(btn);
    return card;
  }

  /* Gem packs as a card row; the biggest pack is flagged best value. */
  function packsGrid(packs) {
    packs.sort(function (a, b) { return a.gems - b.gems; });
    var grid = document.createElement('div');
    grid.className = 'packs-grid';
    packs.forEach(function (p, i) {
      var cardEl = document.createElement('div');
      cardEl.className = 'pack-card';
      if (packs.length >= 3 && i === packs.length - 1) {
        cardEl.innerHTML = '<span class="pack-badge gold">' + I18n.t('BEST VALUE') + '</span>';
      } else if (packs.length >= 3 && i === packs.length - 2) {
        cardEl.innerHTML = '<span class="pack-badge">' + I18n.t('POPULAR') + '</span>';
      }
      var amount = document.createElement('div');
      amount.className = 'pack-gems';
      amount.innerHTML = '<span class="gem">&#9670;</span> ' + p.gems;
      cardEl.appendChild(amount);
      var btn = document.createElement('button');
      btn.className = 'shop-buy';
      wireBuy(btn, p);
      cardEl.appendChild(btn);
      grid.appendChild(cardEl);
    });
    return grid;
  }

  /* Plain label/price row (remove_ads on Android). */
  function shopRowEl(p) {
    var row = document.createElement('div');
    row.className = 'shop-row';
    var label = document.createElement('span');
    label.className = 'shop-label';
    label.textContent = p.title.toUpperCase();
    row.appendChild(label);
    var btn = document.createElement('button');
    btn.className = 'shop-buy';
    wireBuy(btn, p);
    row.appendChild(btn);
    return row;
  }

  function buildShop() {
    // free daily gems: same fail-safe rule as every rewarded placement —
    // only visible when an ad is actually loaded and today's is unclaimed
    el.freeGemsBtn.classList.toggle('hidden',
      !(Ads.isRewardedReady() && Daily.canClaimShopGems()));
    if (el.shopGemsVal) el.shopGemsVal.textContent = Store.getGems();
    el.shopFeatured.innerHTML = '';
    el.shopList.innerHTML = '';
    if (!IAP_ENABLED) {
      // launch build: free daily gems only, nothing to purchase
      el.shopNote.textContent = I18n.t('gems are earned every run — plus a free bonus daily');
      $('restoreBtn').classList.add('hidden');
      return;
    }
    var rows = Iap.getCatalog();
    var ultra = null, packs = [], others = [];
    rows.forEach(function (p) {
      if (p.id === 'ultra_pass') ultra = p;
      else if (p.gems) packs.push(p);
      else others.push(p);
    });
    if (ultra) el.shopFeatured.appendChild(ultraCard(ultra));
    if (packs.length) el.shopList.appendChild(packsGrid(packs));
    others.forEach(function (p) {
      // A row with no store offer and no owned entitlement would render as a
      // dead "—" button (e.g. remove_ads when the product isn't in the store
      // catalog). Skip it — an unbuyable, unowned row helps no one.
      if (!p.price && !p.owned) return;
      el.shopList.appendChild(shopRowEl(p));
    });
    el.shopNote.textContent = Iap.isAvailable()
      ? I18n.t(Store.getUltraPass() ? 'Ultra Pass active — ×3 on all earned gems'
                                    : 'purchases support development')
      : I18n.t('store unavailable — try again later');
    // Restore Purchases must be visible wherever the store is live (Apple
    // Guideline 3.1.1 for the non-consumable). Hidden only in the plain browser.
    $('restoreBtn').classList.toggle('hidden', !Iap.isAvailable());
  }

  /* ---------- custom photo skin ---------- */

  function onCustomTap(s) {
    if (!Skins.isOwned('custom')) {
      el.cuAd.classList.toggle('hidden', !Ads.isRewardedReady());
      openModalFocus(el.customModal);
      return;
    }
    var data = Store.getCustomSkin();
    if (!data || !data.img) { el.skinFile.click(); return; }
    if (Store.getSkin() === 'custom') {
      el.skinFile.click(); // already selected: tap again to change photo
      return;
    }
    Store.setSkin('custom');
    Sound.click();
    applyAccent();
    Game.refreshSkin();
    buildSkinRow();
  }

  function onCustomBuy() {
    if (Skins.buy('custom')) {
      Sound.unlockSkin();
      el.customModal.classList.add('hidden');
      el.menuGemsVal.textContent = Store.getGems();
      buildSkinRow();
      el.skinFile.click();
    } else {
      Sound.deny();
    }
  }

  function onCustomAd() {
    el.customModal.classList.add('hidden');
    Ads.showRewarded().then(function (earned) {
      if (earned) {
        Skins.grant('custom');
        Sound.unlockSkin();
        buildSkinRow();
        el.skinFile.click();
      }
    });
  }

  /* Custom-photo import limits. The photo is decoded, center-cropped to a
   * small square, re-encoded as a tiny JPEG and stored APP-LOCALLY (it never
   * leaves the device). We cap the INPUT so a malicious/huge file can't OOM a
   * weak phone, validate the type, correct EXIF orientation, and confirm the
   * write succeeded before committing the skin. */
  var MAX_PHOTO_BYTES = 25 * 1024 * 1024; // 25 MB input cap
  var MAX_PHOTO_DIM = 8192;               // reject absurd decoded dimensions
  var PHOTO_SIZE = 128;                    // stored square size (px)

  /* Pure, testable pre-flight: is this File a plausible image we can import? */
  function validatePhotoFile(file) {
    if (!file) return { ok: false, reason: 'no file' };
    if (!/^image\//.test(file.type || '')) return { ok: false, reason: 'not an image' };
    if (typeof file.size === 'number' && file.size > MAX_PHOTO_BYTES) return { ok: false, reason: 'too large' };
    if (typeof file.size === 'number' && file.size === 0) return { ok: false, reason: 'empty' };
    return { ok: true, reason: '' };
  }

  function photoError(msg) {
    if (Sound && Sound.deny) Sound.deny();
    console.warn('[photo] ' + msg);
  }

  function importSkinImage(file) {
    var v = validatePhotoFile(file);
    if (!v.ok) { photoError('rejected: ' + v.reason); return; }

    // Prefer createImageBitmap: a more memory-efficient decode that can also
    // apply the EXIF orientation so portrait photos aren't sideways. Fall
    // back to FileReader + Image where it (or that option) is unavailable.
    if (typeof createImageBitmap === 'function') {
      var opts = { imageOrientation: 'from-image' };
      try {
        createImageBitmap(file, opts).then(function (bmp) {
          if (bmp.width > MAX_PHOTO_DIM || bmp.height > MAX_PHOTO_DIM) {
            if (bmp.close) bmp.close();
            photoError('image dimensions too large');
            return;
          }
          finishPhoto(bmp, bmp.width, bmp.height);
          if (bmp.close) bmp.close();
        }).catch(function () { importViaFileReader(file); });
        return;
      } catch (e) { importViaFileReader(file); return; }
    }
    importViaFileReader(file);
  }

  function importViaFileReader(file) {
    var fr = new FileReader();
    fr.onerror = function () { photoError('could not read file'); };
    fr.onload = function () {
      var img = new Image();
      img.onerror = function () { photoError('could not decode image'); };
      img.onload = function () {
        if (img.width > MAX_PHOTO_DIM || img.height > MAX_PHOTO_DIM) { photoError('image dimensions too large'); return; }
        finishPhoto(img, img.width, img.height);
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  /* Crop + downscale + average-color + persist. Confirms the durable write
   * BEFORE committing the skin so a quota failure can't leave a half-applied
   * "custom" selection pointing at no image. */
  function finishPhoto(src, w, h) {
    try {
      var c = document.createElement('canvas');
      c.width = c.height = PHOTO_SIZE;
      var g = c.getContext('2d');
      var m = Math.min(w, h);
      g.drawImage(src, (w - m) / 2, (h - m) / 2, m, m, 0, 0, PHOTO_SIZE, PHOTO_SIZE);
      // average color, brightened so the neon glow reads on dark bg
      var one = document.createElement('canvas');
      one.width = one.height = 1;
      var og = one.getContext('2d');
      og.drawImage(c, 0, 0, 1, 1);
      var px = og.getImageData(0, 0, 1, 1).data;
      var color = '#' + [px[0], px[1], px[2]].map(function (v) {
        v = Math.min(255, Math.round(90 + v * 0.65));
        return ('0' + v.toString(16)).slice(-2);
      }).join('');
      var saved = Store.setCustomSkin({ img: c.toDataURL('image/jpeg', 0.85), color: color });
      if (!saved) { photoError('could not save photo (storage full?)'); return; }
      Store.setSkin('custom');
      Sound.unlockSkin();
      applyAccent();
      Game.refreshSkin();
      buildSkinRow();
    } catch (e) {
      photoError('import failed: ' + (e && e.message ? e.message : e));
    }
  }

  /* ---------- missions ---------- */

  function buildMissions() {
    el.missionList.innerHTML = '';
    var sum = 0;
    Missions.list().forEach(function (m) {
      sum += m.reward;
      var row = document.createElement('div');
      row.className = 'mission-row';
      var pct = m.n > 1 ? Math.round(m.p / m.n * 100) : 0;
      row.innerHTML =
        '<div class="mrow-top"><span class="mtext">' + m.text + '</span>' +
        '<span class="mreward">&#9670;' + m.reward + '</span></div>' +
        (m.n > 1
          ? '<div class="mrow-sub"><span class="mbar"><i style="width:' + pct + '%"></i></span>' +
            '<span class="mprog">' + m.p + '/' + m.n + '</span></div>'
          : '');
      el.missionList.appendChild(row);
    });
    // completed missions are replaced instantly, so the header sells the
    // standing offer instead of a done-count: the total up for grabs
    var sumEl = $('mcSum');
    if (sumEl) sumEl.innerHTML = I18n.t('WIN {gem}{n}', { n: sum });
  }

  /* "MISSION COMPLETE" toasts on the game-over panel, staggered in. */
  function showToasts(completed) {
    el.toasts.innerHTML = '';
    (completed || []).forEach(function (c, i) {
      var t = document.createElement('div');
      t.className = 'toast';
      t.style.animationDelay = (0.25 + i * 0.18) + 's';
      t.textContent = c.text + '  +' + c.reward + ' ◆';
      el.toasts.appendChild(t);
    });
  }

  /* One-time discovery toast on the game-over panel (staggers after any
   * mission toasts already queued). */
  function tipToast(text, cls) {
    var t = document.createElement('div');
    t.className = 'toast' + (cls ? ' ' + cls : '');
    t.style.animationDelay = (0.25 + el.toasts.children.length * 0.18) + 's';
    t.textContent = text;
    el.toasts.appendChild(t);
  }

  /* ---------- daily reward streak ---------- */

  /* Shown over the menu whenever a new calendar day's reward is
   * waiting. The 7-day strip marks claimed days and pulses today. */
  function maybeShowDaily() {
    var s = Daily.streakState();
    if (!s.claimable) return;
    // Never interrupt a brand-new player's very first session: with zero
    // finished runs, the modal would be the first thing they ever see. It
    // waits for the menu visit after their first run, where it lands as a
    // gift instead of a wall in front of the game.
    if (Store.getDeaths() === 0) return;
    el.dailyDays.innerHTML = '';
    for (var i = 1; i <= 7; i++) {
      var cell = document.createElement('div');
      cell.className = 'daily-day' + (i < s.day ? ' past' : i === s.day ? ' now' : '') +
        (i === 7 ? ' max' : ''); // day 7 is the streak's gold payout
      cell.innerHTML = '<span class="d">' + I18n.t('DAY {n}', { n: i }) + '</span>' +
        '<span class="v">' + (i < s.day ? '&#10003;' : Daily.STREAK_GEMS[i - 1]) + '</span>';
      el.dailyDays.appendChild(cell);
    }
    // streak repair offer: only when a single-day lapse is actually
    // repairable AND a rewarded ad is loaded (fail-safe like every
    // other rewarded placement)
    var rep = Daily.repairState();
    el.streakRepairBtn.classList.toggle('hidden',
      !(rep.repairable && Ads.isRewardedReady()));
    el.dailyAmount.innerHTML = '<span class="gem">&#9670;</span> +' + s.gems;
    openModalFocus(el.dailyModal); // capture a fresh return point + focus the Claim button
  }

  /* Theme the UI (buttons, title glow) to the selected skin. */
  function applyAccent() {
    document.documentElement.style.setProperty('--accent', Skins.current().color);
  }

  /* ---------- lifetime stats ---------- */

  function fmtPlayTime(sec) {
    sec = Math.floor(sec);
    var h = Math.floor(sec / 3600);
    var m = Math.floor((sec % 3600) / 60);
    if (h > 0) return h + 'h ' + m + 'm';
    if (m > 0) return m + 'm ' + (sec % 60) + 's';
    return sec + 's';
  }

  function openStats() {
    var combo = Store.getComboBest();
    var rows = [
      ['BEST SCORE', Math.floor(Store.getBest())],
      ['BEST SURVIVAL', Store.getBestSeconds() + 's'],
      ['PLAYER LEVEL', Store.getPlayerLevel()],
      ['RUNS', Store.getDeaths()],
      ['TIME PLAYED', fmtPlayTime(Store.getTimeTotal())],
      ['GEMS COLLECTED', Store.getGemsTotal()],
      ['NEAR MISSES', Store.getNearTotal()],
      ['BEST COMBO', combo > 0 ? '×' + combo : '—'],
      ['STORMS WEATHERED', Store.getStormsSurvived()],
      ['MISSIONS DONE', Store.getMissionsDone()],
      // v10 Descent progression
      ['DEEPEST SPHERE', ROMAN[Store.getDeepestSphere()] || Store.getDeepestSphere()],
      ['SOULS EARNED', Store.getSoulsTotal()],
      ['RELICS FOUND', Store.getRelicCodex().length + '/' + Relics.LIST.length],
      ['WARDENS FELLED', Store.getWardensFelled()]
    ];
    el.statsList.innerHTML = '';
    rows.forEach(function (r) {
      var row = document.createElement('div');
      row.className = 'stat-row';
      var name = document.createElement('span');
      name.className = 'sname';
      name.textContent = I18n.t(r[0]);
      var val = document.createElement('span');
      val.className = 'sval';
      val.textContent = r[1];
      row.appendChild(name);
      row.appendChild(val);
      el.statsList.appendChild(row);
    });
    openModalFocus(el.statsModal);
  }

  /* ---------- settings (accessibility + privacy + reset) ---------- */

  var resetArmed = false;
  var modalReturnFocus = null;

  /* Repaint every JS-rendered string after a language change. The static DOM
   * is handled by I18n.applyDom(); these are the panels built in code. */
  function relocalize() {
    syncSettings();
    if (!el.menu.classList.contains('hidden')) showMenu();
    if (gearSection === 'relics') buildForge();
    if (shopVisible()) buildShop();
  }

  function syncSettings() {
    $('setLangVal').textContent = I18n.getLang()
      ? I18n.nativeName(I18n.getLang())
      : I18n.t('AUTO');
    // Any other settings interaction cancels a pending Reset confirm, so the
    // two-tap guard requires two CONSECUTIVE taps (every row handler below
    // calls syncSettings; the Reset handler does not, so its arm survives
    // until the next interaction). openSettings already disarms before calling.
    if (resetArmed) {
      resetArmed = false;
      $('setResetLabel').textContent = I18n.t('Reset all progress');
      var rb = $('setResetBtn'); if (rb) rb.classList.remove('armed');
    }
    var sm = Sound.isMuted();
    $('setSoundVal').textContent = I18n.t(sm ? 'OFF' : 'ON');
    $('setSoundBtn').setAttribute('aria-pressed', sm ? 'false' : 'true');
    var mo = Sound.isMusicOff();
    $('setMusicVal').textContent = I18n.t(mo ? 'OFF' : 'ON');
    $('setMusicBtn').setAttribute('aria-pressed', mo ? 'false' : 'true');
    var rf = Store.getReduceFlash();
    $('setFlashVal').textContent = I18n.t(rf ? 'ON' : 'OFF');
    $('setFlashBtn').setAttribute('aria-pressed', rf ? 'true' : 'false');
    var rm = Store.getReduceMotion();
    $('setMotionVal').textContent = I18n.t(rm ? 'ON' : 'OFF');
    $('setMotionBtn2').setAttribute('aria-pressed', rm ? 'true' : 'false');
    $('setHapticsVal').textContent = I18n.t(Store.getHaptics().toUpperCase());
    var ghostOn = !Store.getGhostOff();
    $('setGhostVal').textContent = I18n.t(ghostOn ? 'ON' : 'OFF');
    $('setGhostBtn').setAttribute('aria-pressed', ghostOn ? 'true' : 'false');
    // ad privacy options only where UMP requires them (EEA/UK consent)
    $('setPrivacyBtn').classList.toggle('hidden', !(Ads.isPrivacyOptionsRequired && Ads.isPrivacyOptionsRequired()));
    // delete-photo only when a custom photo exists
    $('setDeletePhotoBtn').classList.toggle('hidden', !Store.getCustomSkin());
  }

  function openSettings() {
    resetArmed = false;
    $('setResetLabel').textContent = 'Reset all progress';
    el.setResetBtn = $('setResetBtn');
    el.setResetBtn.classList.remove('armed');
    syncSettings();
    openModalFocus(el.settingsModal);
  }

  function closeSettings() {
    el.settingsModal.classList.add('hidden');
    resetArmed = false;
    $('setResetLabel').textContent = 'Reset all progress';
    restoreModalFocus();
  }

  /* ---------- modal focus management (a11y) ---------- */

  function openModalFocus(elModal) {
    modalReturnFocus = document.activeElement;
    elModal.classList.remove('hidden');
    var f = elModal.querySelector('button:not([disabled]):not(.hidden), input:not([disabled])');
    if (f && f.focus) { try { f.focus(); } catch (e) {} }
  }

  function restoreModalFocus() {
    if (modalReturnFocus && modalReturnFocus.focus) { try { modalReturnFocus.focus(); } catch (e) {} }
    modalReturnFocus = null;
  }

  /* The topmost open modal, in the same priority order as closeTopModal. */
  function topModal() {
    var order = [el.levelUpModal, el.customModal, el.settingsModal, el.dailyModal, el.statsModal, el.guideModal, el.oracleModal, el.gameover];
    for (var i = 0; i < order.length; i++) {
      if (order[i] && !order[i].classList.contains('hidden')) return order[i];
    }
    return null;
  }

  /* Keep Tab focus inside the open modal (wrap at the ends). */
  function trapTab(e, elModal) {
    var f = elModal.querySelectorAll('button:not([disabled]):not(.hidden), [tabindex]:not([tabindex="-1"]), input:not([disabled])');
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { last.focus(); e.preventDefault(); }
    else if (!e.shiftKey && document.activeElement === last) { first.focus(); e.preventDefault(); }
  }

  /* ---------- "next unlock" teaser (game-over panel) ---------- */

  /* The cheapest skin, track or trail the player doesn't own yet. */
  function cheapestLocked() {
    var best = null;
    Skins.LIST.forEach(function (s) {
      if (s.cost > 0 && !Skins.isOwned(s.id) && (!best || s.cost < best.cost)) {
        best = { name: s.name, cost: s.cost };
      }
    });
    Levels.LIST.forEach(function (l) {
      if (l.cost > 0 && !Levels.isOwned(l.id) && (!best || l.cost < best.cost)) {
        best = { name: l.name, cost: l.cost };
      }
    });
    Trails.LIST.forEach(function (t) {
      if (t.cost > 0 && !Trails.isOwned(t.id) && (!best || t.cost < best.cost)) {
        best = { name: t.name, cost: t.cost };
      }
    });
    return best;
  }

  /* Returns the fill percentage so showGameOver can animate it in
   * with the same double-rAF trick as the best bar. */
  function updateNextUnlock() {
    var n = cheapestLocked();
    if (!n) { el.nextUnlock.classList.add('hidden'); return 0; }
    var gems = Store.getGems();
    el.nextUnlockText.innerHTML = I18n.t('NEXT: {name} {gem} {x}/{y}',
      { name: '<b>' + n.name.toUpperCase() + '</b>', x: Math.min(gems, n.cost), y: n.cost });
    el.nextUnlock.classList.remove('hidden');
    return Math.min(100, Math.round(gems / n.cost * 100));
  }

  /* ---------- modal-aware Android back ---------- */

  /* Close the topmost open overlay. Returns true if one was closed
   * (the back press is consumed), false if nothing was open. */
  function closeTopModal() {
    if (!el.levelUpModal.classList.contains('hidden')) {
      el.levelUpModal.classList.add('hidden');
      return true;
    }
    if (!el.customModal.classList.contains('hidden')) {
      el.customModal.classList.add('hidden');
      restoreModalFocus();
      return true;
    }
    if (el.settingsModal && !el.settingsModal.classList.contains('hidden')) {
      closeSettings();
      return true;
    }
    if (!el.dailyModal.classList.contains('hidden')) {
      el.dailyModal.classList.add('hidden');
      restoreModalFocus();
      return true;
    }
    if (!el.statsModal.classList.contains('hidden')) {
      el.statsModal.classList.add('hidden');
      restoreModalFocus();
      return true;
    }
    if (el.guideModal && !el.guideModal.classList.contains('hidden')) {
      el.guideModal.classList.add('hidden');
      restoreModalFocus();
      return true;
    }
    if (el.oracleModal && !el.oracleModal.classList.contains('hidden')) {
      closeOracle(); // self-restores focus
      return true;
    }
    // menu hub: back from a non-home tab returns to HOME before exiting the app
    if (el.tabHome && el.menu && !el.menu.classList.contains('hidden') && menuTab !== 'home') {
      setMenuTab('home');
      return true;
    }
    return false;
  }

  /* A rewarded ad just loaded: surface buttons that were hidden on
   * already-open panels (main.js handles the game-over offers). The
   * daily modal usually opens before the first ad finishes loading, so
   * its streak-repair offer is re-evaluated here too. */
  function adsReady() {
    if (shopVisible()) buildShop();
    // home free-gems pill appears live when the first rewarded ad arrives
    // (previously it waited for the next showMenu)
    if (el.shopBtn) {
      el.shopBtn.classList.toggle('hidden',
        !(Ads.isRewardedReady() && Daily.canClaimShopGems()));
    }
    if (!el.customModal.classList.contains('hidden')) {
      el.cuAd.classList.toggle('hidden', !Ads.isRewardedReady());
    }
    if (!el.dailyModal.classList.contains('hidden')) {
      var rep = Daily.repairState();
      el.streakRepairBtn.classList.toggle('hidden',
        !(rep.repairable && Ads.isRewardedReady()));
    }
  }

  /* ---------- menu hub tabs ---------- */

  /* Which hub tab is showing. Survives modal round-trips (settings, shop,
   * a run) so the player returns where they were; only app start is 'home'. */
  var menuTab = 'home';

  function setMenuTab(t) {
    if (window.Analytics && menuTab !== t) {
      Analytics.track('screen_view', { screen: t });
      if (t === 'shop') Analytics.track('shop_open', {});
    }
    menuTab = t;
    el.tabHome.classList.toggle('hidden', t !== 'home');
    el.tabStyle.classList.toggle('hidden', t !== 'style');
    el.shop.classList.toggle('hidden', t !== 'shop');
    el.tabMore.classList.toggle('hidden', t !== 'more');
    el.tabBtnHome.classList.toggle('active', t === 'home');
    el.tabBtnStyle.classList.toggle('active', t === 'style');
    el.storeBtn.classList.toggle('active', t === 'shop');
    el.tabBtnMore.classList.toggle('active', t === 'more');
    // first GEAR visit: orientation tip until the player taps GOT IT
    if (t === 'style' && el.gearTip) {
      el.gearTip.classList.toggle('hidden', Store.isTipSeen('gear'));
    }
    var panel = t === 'home' ? el.tabHome : t === 'style' ? el.tabStyle :
                t === 'shop' ? el.shop : el.tabMore;
    panel.scrollTop = 0;
  }

  /* ---------- GEAR tab sections ---------- */

  var gearSection = 'tracks';

  function setGearSection(s) {
    if (window.Analytics && gearSection !== s) Analytics.track('screen_view', { screen: 'gear_' + s });
    gearSection = s;
    var secs = { tracks: 'gsTracks', themes: 'gsThemes', skins: 'gsSkins',
                 trails: 'gsTrails', relics: 'gsRelics' };
    var chips = { tracks: 'gcTracks', themes: 'gcThemes', skins: 'gcSkins',
                  trails: 'gcTrails', relics: 'gcRelics' };
    var k, c;
    for (k in secs) { $(secs[k]).classList.toggle('hidden', k !== s); }
    for (k in chips) {
      c = $(chips[k]);
      c.classList.toggle('active', k === s);
      c.setAttribute('aria-selected', k === s ? 'true' : 'false');
    }
    if (s === 'relics') {
      forgeInspect = null; // start with the generic hint, not a stale relic
      buildForge();
    }
    el.tabStyle.scrollTop = 0;
  }

  /* The current-track chip above PLAY (name + gem multiplier). */
  function syncTrackChip() {
    if (!el.trackChip) return;
    var lv = Levels.current();
    el.trackChip.innerHTML = '<span class="tc-shape">' + shapeSVG(lv, 20) + '</span>' +
      '<span class="tc-name">' + lv.name.toUpperCase() + '</span>' +
      '<span class="tc-mult">&times;' + lv.mult + '</span>' +
      '<span class="tc-go">&rsaquo;</span>'; // reads as "tap to change"
    el.trackChip.setAttribute('aria-label', 'Track: ' + lv.name + ' — change track');
  }

  /* ---------- screens ---------- */

  function showMenu() {
    el.menuBest.textContent = Math.floor(Store.getBest());
    el.menuGemsVal.textContent = Store.getGems();
    refreshMenuSouls();
    // player level badge + progress bar toward the next level
    var xs = XP.state();
    $('xpLevel').textContent = xs.level;
    $('xpFill').style.width = Math.min(100, Math.round(xs.xp / xs.need * 100)) + '%';
    // daily challenge: one RANKED run per day. Once today's run is played, hide
    // the button until tomorrow's challenge (no pointless unranked practice).
    var dc = Daily.challengeState();
    el.dailyBtn.classList.toggle('hidden', dc.played);
    if (!dc.played) {
      el.dailyBtn.disabled = false;
      el.dailyBtn.innerHTML = I18n.t('DAILY RUN') + '<small>' +
        I18n.t('beat {n}s · win 100 {gem}', { n: Daily.CHALLENGE_GOAL }) + '</small>';
    }
    // free gems: a single inline claim, shown only when a rewarded ad is loaded
    // AND today's bonus is unclaimed (otherwise hidden — no empty screen).
    el.shopBtn.classList.toggle('hidden', !(Ads.isRewardedReady() && Daily.canClaimShopGems()));
    buildMissions();
    buildLevelRow();
    buildThemeRow();
    buildSkinRow();
    buildTrailRow();
    // Play Games: leaderboard entry only when actually signed in
    el.ranksBtn.classList.toggle('hidden', !PlayGames.isSignedIn());
    syncTrackChip();
    syncUltraChip();
    // brand-new player: pulse PLAY until the first run is in the books
    $('playBtn').classList.toggle('pulse',
      Store.getDeaths() === 0 && !Store.getReduceMotion());
    // hub panels that show live data get a fresh render when returning here
    if (menuTab === 'shop') buildShop();
    if (gearSection === 'relics') buildForge(); // souls/codex may have changed after a run
    // the floating sound toggles are in-run controls; the menu has Settings
    $('muteBtn').classList.add('hidden');
    $('musicBtn').classList.add('hidden');
    el.menu.classList.remove('hidden');
    el.gameover.classList.add('hidden');
    el.hud.classList.add('hidden');
    el.pause.classList.add('hidden');
    maybeShowDaily();
  }

  function showHUD() {
    $('muteBtn').classList.remove('hidden');
    $('musicBtn').classList.remove('hidden');
    // A run must never start underneath an open overlay. The menu alone was
    // hidden here, so a run begun while a modal was up (desktop Space bar, a
    // late async open) left that modal floating over live gameplay.
    [el.dailyModal, el.customModal, el.statsModal, el.settingsModal,
     el.guideModal, el.oracleModal, el.levelUpModal].forEach(function (m) {
      if (m) m.classList.add('hidden');
    });
    el.menu.classList.add('hidden');
    el.gameover.classList.add('hidden');
    el.pause.classList.add('hidden');
    el.hud.classList.remove('hidden');
    if (el.zenExit) el.zenExit.classList.add('hidden'); // off unless a Zen run turns it on
    if (el.wardenBanner) el.wardenBanner.classList.add('hidden'); // cleared each run
  }

  /* Zen Drift HUD: show the on-screen EXIT (no game-over screen to leave by). */
  function setZenHud(on) {
    if (el.zenExit) el.zenExit.classList.toggle('hidden', !on);
  }

  var countUpRaf = 0;

  /* Count the final score up from 0 — a beat of celebration that
   * makes the number land. Instant under Reduce motion. */
  function countUpScore(target, ms) {
    if (countUpRaf) cancelAnimationFrame(countUpRaf);
    if (Store.getReduceMotion() || target <= 0) {
      el.finalScore.textContent = target;
      return;
    }
    var t0 = performance.now();
    var shown = -1;
    function tick(now) {
      var k = Math.min(1, (now - t0) / ms);
      k = 1 - (1 - k) * (1 - k); // ease-out
      var v = Math.round(target * k);
      if (v !== shown) { shown = v; el.finalScore.textContent = v; }
      if (k < 1) countUpRaf = requestAnimationFrame(tick);
      else countUpRaf = 0;
    }
    countUpRaf = requestAnimationFrame(tick);
  }

  function showGameOver(d) {
    countUpScore(d.score, d.isNewBest ? 900 : 550);
    el.overBest.textContent = d.best;
    // show what was actually BANKED, not the raw pick-up count: bankGems()
    // runs the total through the Ultra Pass multiplier, so a pass holder
    // used to be shown a third of what they were paid
    el.overGems.textContent = d.runGems * Store.gemMult();
    el.overUltra.classList.toggle('hidden', Store.gemMult() <= 1);
    el.newBest.classList.toggle('hidden', !d.isNewBest);
    el.reviveBtn.classList.toggle('hidden', !d.showRevive);
    el.x2Btn.classList.toggle('hidden', !d.showDouble);
    showToasts(d.missionsDone);
    // one-time onboarding: point the very first death at GEAR, and the first
    // Souls earned at the RELICS section (both persist as seen even if missed)
    if (!Store.isTipSeen('firstover')) {
      Store.markTipSeen('firstover');
      tipToast(I18n.t('TIP — spend your ◆ in GEAR: tracks multiply your earnings'));
    }
    if ((d.soulsDelta || 0) > 0 && !Store.isTipSeen('souls')) {
      Store.markTipSeen('souls');
      tipToast(I18n.t('◇ SOULS EARNED — attune Relics in GEAR › RELICS'), 'soul-t');
    }
    // near-miss recap (hidden for runs without any)
    el.runRecap.classList.toggle('hidden', !d.nearMisses);
    el.recapNm.textContent = d.nearMisses;
    el.recapCombo.innerHTML = '&times;' + d.bestCombo;
    // Descent recap: deepest Sphere + the relics drafted this run
    if (el.descentRecap) {
      el.descentSphere.textContent = ROMAN[d.descent] || d.descent || 'I';
      if (el.descentSouls) el.descentSouls.textContent = d.soulsDelta || 0;
      el.descentRelics.innerHTML = '';
      var rel = d.relics || [];
      for (var ri = 0; ri < rel.length; ri++) {
        var rr = Relics.byId(rel[ri]);
        if (!rr) continue;
        var sp = document.createElement('span');
        sp.className = 'relic-chip mini';
        sp.style.color = rr.color; sp.style.borderColor = rr.color;
        sp.textContent = rr.glyph;
        sp.setAttribute('aria-label', rr.name);
        el.descentRelics.appendChild(sp);
      }
      el.descentRecap.classList.toggle('hidden', !d.descent);
    }
    // progress bars (best + next unlock) animate in once the panel shows
    var pct = d.best > 0 ? Math.min(100, Math.round(d.score / d.best * 100)) : 0;
    var nextPct = updateNextUnlock();
    el.bestFill.classList.toggle('gold', d.isNewBest);
    el.bestFill.style.width = '0%';
    el.nextFill.style.width = '0%';
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        el.bestFill.style.width = pct + '%';
        el.nextFill.style.width = nextPct + '%';
      });
    });
    el.gameover.classList.remove('hidden');
    el.hud.classList.add('hidden');
  }

  /* ×2 rewarded ad succeeded: show the doubled total, retire the offer.
   * Takes the RAW doubled pick-up count; the pass factor is applied here,
   * matching showGameOver so the number never jumps on a pass holder. */
  function markDoubled(rawTotal) {
    el.overGems.textContent = rawTotal * Store.gemMult();
    el.x2Btn.classList.add('hidden');
    // the balance just grew: refresh the next-unlock teaser too
    el.nextFill.style.width = updateNextUnlock() + '%';
  }

  /* Re-evaluate the game-over offers when a rewarded ad loads late
   * (main.js decides the flags; this just shows/hides the buttons). */
  function refreshOffers(showRevive, showDouble) {
    el.reviveBtn.classList.toggle('hidden', !showRevive);
    el.x2Btn.classList.toggle('hidden', !showDouble);
  }

  /* Sync the menu's gem counter (e.g. a rewarded grant landed after
   * the player already left the game-over panel). */
  function refreshMenuGems() {
    el.menuGemsVal.textContent = Store.getGems();
    syncUltraChip();
  }

  /* Persistent ×3 marker on the top-bar gem chip, so an Ultra Pass holder
   * can always see the pass is live rather than inferring it from payouts. */
  function syncUltraChip() {
    if (el.ultraChip) el.ultraChip.classList.toggle('hidden', Store.gemMult() <= 1);
  }

  function hideGameOver() { el.gameover.classList.add('hidden'); }
  function hideRevive() { el.reviveBtn.classList.add('hidden'); }
  function hideDouble() { el.x2Btn.classList.add('hidden'); }

  function showPause(on) {
    el.pause.classList.toggle('hidden', !on);
    if (on) {
      // always reset to the PAUSED face (a countdown may have been showing)
      el.pausedBox.classList.remove('hidden');
      el.countNum.classList.add('hidden');
    }
  }

  /* One step of the 3-2-1 resume countdown (main.js drives the timing). */
  function showCountdown(n) {
    el.pausedBox.classList.add('hidden');
    el.countNum.textContent = n;
    el.countNum.classList.remove('hidden');
    el.countNum.classList.remove('pop');
    void el.countNum.offsetWidth;
    el.countNum.classList.add('pop');
  }

  /* ---------- HUD values ---------- */

  function setScore(s) { el.score.textContent = s; }

  /* Descent depth readout (Sphere I..VII), with a brief pop on each change. */
  var ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
  function setSphere(n) {
    if (!el.depthTag) return;
    el.depthTag.textContent = I18n.t('SPHERE {r}', { r: ROMAN[n] || n });
    el.depthTag.classList.remove('pop');
    void el.depthTag.offsetWidth; // restart the CSS pop
    el.depthTag.classList.add('pop');
  }

  /* Relic rail: the held-relic icons down the left edge (rebuilt on each
   * draft from the engine's held list). */
  function setRelicRail(ids) {
    if (!el.relicRail) return;
    el.relicRail.innerHTML = '';
    for (var i = 0; i < ids.length; i++) {
      var rel = Relics.byId(ids[i]);
      if (!rel) continue;
      var chip = document.createElement('div');
      chip.className = 'relic-chip';
      chip.style.color = rel.color;
      chip.style.borderColor = rel.color;
      chip.textContent = rel.glyph;
      chip.setAttribute('aria-label', rel.name + ': ' + rel.desc);
      el.relicRail.appendChild(chip);
    }
  }

  /* Warden duel banner: the boss name + a timer bar that depletes over the
   * encounter. Driven by two engine events (start / end) — no per-frame DOM. */
  var wardenHideTimer = null;
  function showWarden(w) {
    if (!el.wardenBanner) return;
    if (wardenHideTimer) { clearTimeout(wardenHideTimer); wardenHideTimer = null; }
    el.wardenName.textContent = '⚠ ' + w.name;
    el.wardenName.style.color = w.color;
    el.wardenBanner.style.borderColor = w.color;
    el.wardenBarFill.style.background = w.color;
    el.wardenBanner.classList.remove('hidden', 'felled');
    // The bar is driven by the ENGINE clock via wardenTick() (so it freezes on
    // pause). A short transition just smooths the steps between ticks.
    el.wardenBarFill.style.transition = 'width 0.16s linear';
    el.wardenBarFill.style.width = '100%';
  }
  function wardenTick(pct) {
    if (el.wardenBarFill) el.wardenBarFill.style.width = pct + '%';
  }
  function endWarden(survived) {
    if (!el.wardenBanner) return;
    if (survived) {
      el.wardenName.textContent = I18n.t('✔ WARDEN FELLED');
      el.wardenBanner.classList.add('felled');
      el.wardenBarFill.style.transition = 'none';
      el.wardenBarFill.style.width = '100%';
      wardenHideTimer = setTimeout(function () { el.wardenBanner.classList.add('hidden'); }, 1500);
    } else {
      el.wardenBanner.classList.add('hidden');
    }
  }

  /* Brief "pact sealed" toast naming the drafted relic. */
  var relicToastTimer = null;
  function showRelic(relic) {
    if (!el.relicToast) return;
    el.relicToast.innerHTML = '<b style="color:' + relic.color + '">' + relic.name + '</b>' +
      '<span>' + relic.desc + '</span>';
    el.relicToast.classList.remove('hidden', 'pop');
    void el.relicToast.offsetWidth;
    el.relicToast.classList.add('pop');
    if (relicToastTimer) clearTimeout(relicToastTimer);
    relicToastTimer = setTimeout(function () { el.relicToast.classList.add('hidden'); }, 2200);
  }
  /* The run counter shows what the wallet will actually receive: the engine
   * counts gems collected, and the Ultra Pass multiplies the total when it
   * banks. Applying the pass here means a holder watches +60 per gem on a
   * ×20 track instead of +20 followed by an unexplained ×3 on the results
   * screen — they paid for it, so it pays visibly, in real time.
   *
   * Deliberately a DISPLAY multiplier: runGems stays raw inside the engine,
   * so mission progress ("collect 30 ◆ in one run"), the lifetime collected
   * stat and the daily-run economy are untouched — a paid pass must never
   * advance a mission three times faster. */
  function setRunGems(n) { el.runGemsVal.textContent = n * Store.gemMult(); }

  /* First-run tutorial hint (lives inside the HUD, so it disappears
   * with it on game over automatically). */
  function showTutorial(on) {
    if (!el.tutHint) el.tutHint = $('tutHint');
    el.tutHint.classList.toggle('hidden', !on);
  }

  /* Gold mid-run "BEST!" flash (the moment the live score passes the
   * previous best). */
  function showMilestone(text, gold) {
    el.milestone.textContent = text;
    el.milestone.classList.toggle('gold', !!gold);
    el.milestone.classList.remove('pop');
    void el.milestone.offsetWidth;
    el.milestone.classList.add('pop');
  }

  /* Storm banner: flashing "STORM" through the warning, a steady
   * ×2-gems marker during the burst, hidden otherwise. */
  function showStorm(phase) {
    var s = el.storm;
    s.classList.remove('warn', 'burst');
    if (phase === 'warn') {
      s.textContent = I18n.t('STORM');
      s.classList.remove('hidden');
      s.classList.add('warn');
    } else if (phase === 'burst') {
      s.innerHTML = I18n.t('STORM') + ' &middot; <span class="gem">&#9670;</span>&times;2';
      s.classList.add('burst');
      s.classList.remove('hidden');
    } else {
      s.classList.add('hidden');
    }
  }

  /* Storm Bank pot indicator (HUD): shown only while a pot is live and
   * riding; hidden the moment it's banked or a new run starts. */
  function showPot(amount, riding) {
    if (!el.stormPot) el.stormPot = $('stormPot');
    if (riding && amount > 0) {
      // the pot banks straight into the run total, so show its real worth —
      // otherwise a pass holder banks a "40" pot and the counter jumps 120
      el.stormPot.innerHTML = I18n.t('POT') + ' <span class="gem">&#9670;</span>' + (amount * Store.gemMult()) +
        ' <span class="riding">' + I18n.t('RIDING') + '</span>';
      el.stormPot.classList.remove('hidden');
    } else {
      el.stormPot.classList.add('hidden');
    }
  }

  /* Bank/ride decision flash, reusing the centered milestone pop: gold
   * for a banked pot, accent for a pot left riding. */

  var levelUpTimer = null;

  /* Level-up celebration: highest new level + total gems, auto-
   * dismissing so it never blocks the game-over flow under it. */
  function showLevelUp(ups) {
    if (!ups || !ups.length) return;
    var total = 0;
    for (var i = 0; i < ups.length; i++) total += ups[i].reward;
    $('luLevel').textContent = ups[ups.length - 1].level;
    $('luReward').textContent = total;
    el.levelUpModal.classList.remove('hidden');
    Sound.levelUp();
    if (levelUpTimer) clearTimeout(levelUpTimer);
    levelUpTimer = setTimeout(function () {
      el.levelUpModal.classList.add('hidden');
    }, 2400);
  }

  /* Near-miss flash: "NEAR MISS" first, then the combo multiplier.
   * Restarting the CSS animation makes rapid chains pop each time. */
  function showCombo(n) {
    el.combo.textContent = n >= 2 ? I18n.t('NEAR MISS ×{n}', { n: n }) : I18n.t('NEAR MISS');
    el.combo.classList.remove('pop');
    void el.combo.offsetWidth;
    el.combo.classList.add('pop');
  }

  /* Gem-multiplier badges next to the run counter. The TRACK multiplier and
   * the Ultra Pass ×3 are SEPARATE factors and are shown as separate chips:
   * pickups pay the track rate (the number the run counter visibly climbs
   * by), and the pass triples the run TOTAL when it is banked. Folding them
   * into one "×60" made the badge disagree with every +21 the player watched
   * during the run. Now Prism + Ultra reads "×20 ×3": per-pickup rate, then
   * what happens to the total. */
  function setMult(m) {
    el.multBadge.textContent = '×' + m;
    el.multBadge.classList.toggle('hidden', m <= 1);
    if (el.multUltra) {
      el.multUltra.textContent = '×' + Store.gemMult();
      el.multUltra.classList.toggle('hidden', Store.gemMult() <= 1);
    }
  }

  /* ---------- level select ---------- */

  /* Mini outline preview of a level's track shape. */
  function shapeSVG(level, size) {
    var pts = [];
    var rMax = size / 2 - 3;
    for (var i = 0; i < 60; i++) {
      var t = (i / 60) * Math.PI * 2;
      var r = level.r(t) * rMax;
      pts.push((size / 2 + Math.cos(t) * r).toFixed(1) + ',' +
               (size / 2 + Math.sin(t) * r).toFixed(1));
    }
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">' +
      '<polygon points="' + pts.join(' ') + '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/></svg>';
  }

  function buildLevelRow() {
    el.levelRow.innerHTML = '';
    var selected = Store.getLevel();
    var ownedCount = 0;
    Levels.LIST.forEach(function (l) {
      var owned = Levels.isOwned(l.id);
      if (owned) ownedCount++;
      var btn = document.createElement('button');
      btn.className = 'level' + (l.id === selected ? ' selected' : '') + (owned ? '' : ' locked');
      tileAria(btn, l.name + ' track, ' + l.mult + 'x gems', l.id === selected, !owned, l.cost);
      // always show the gem multiplier — it's the reason to unlock
      btn.innerHTML = shapeSVG(l, 34) +
        '<span class="lname">' + l.name + ' <b class="lmult">×' + l.mult + '</b></span>' +
        '<span class="ldesc">' + (l.desc ? I18n.t(l.desc) : '') + '</span>' +
        (owned ? '' : '<span class="tag">&#9670;' + l.cost + '</span>');
      btn.addEventListener('click', function () { onLevelTap(l, btn); });
      el.levelRow.appendChild(btn);
    });
    var gh = $('ghTracks');
    if (gh) gh.textContent = ownedCount + '/' + Levels.LIST.length;
  }

  function onLevelTap(l, btn) {
    if (Levels.isOwned(l.id)) {
      Store.setLevel(l.id);
      Sound.click();
    } else if (Levels.buy(l.id)) {
      Store.setLevel(l.id);
      Sound.unlockSkin();
    } else {
      Sound.deny();
      btn.classList.remove('denied');
      void btn.offsetWidth;
      btn.classList.add('denied');
      return;
    }
    Game.refreshLevel(); // redraw the track shape behind the menu
    el.menuGemsVal.textContent = Store.getGems();
    buildLevelRow();
    syncTrackChip(); // the home tab's current-track chip mirrors the pick
  }

  /* ---------- skin shop ---------- */

  /* a11y: give a selectable tile an accessible name + pressed state, so a
   * screen reader announces e.g. "Gold, selected" or "Void, locked, 600 gems"
   * instead of an unlabelled canvas. Set inside the build loop because rows
   * are fully rebuilt on every change. */
  function tileAria(btn, name, selected, locked, cost, currency) {
    var label = name;
    if (locked) label += ', locked, costs ' + cost + ' ' + (currency || 'gems');
    else if (selected) label += ', selected';
    else label += ', owned';
    btn.setAttribute('aria-label', label);
    btn.setAttribute('aria-pressed', selected ? 'true' : 'false');
  }

  function buildSkinRow() {
    el.skinRow.innerHTML = '';
    var selected = Store.getSkin();
    var ownedCount = 0;
    Skins.LIST.forEach(function (s) {
      var owned = Skins.isOwned(s.id);
      if (owned) ownedCount++;
      var btn = document.createElement('button');
      btn.className = 'skin' + (s.id === selected ? ' selected' : '') + (owned ? '' : ' locked');
      tileAria(btn, s.name, s.id === selected, !owned, s.soul || s.cost, s.soul ? 'souls' : 'gems');

      // each tile renders its skin on a tiny canvas (flat or character)
      var cv = document.createElement('canvas');
      cv.className = 'dot';
      cv.width = 64; cv.height = 64; // 32 CSS px at 2x for crispness
      var cc = cv.getContext('2d');
      cc.scale(2, 2);
      cc.translate(16, 16);
      Skins.renderIcon(cc, 11, s);
      btn.appendChild(cv);

      var tag = document.createElement('span');
      tag.className = 'tag';
      // Soul skins price in Souls (◇), every other skin in gems (◆)
      tag.innerHTML = owned ? s.name : (s.soul ? '<span class="soul">&#9671;</span>' + s.soul : '&#9670;' + s.cost);
      if (!owned && s.soul) tag.classList.add('soul');
      btn.appendChild(tag);

      btn.addEventListener('click', function () { onSkinTap(s, btn); });
      el.skinRow.appendChild(btn);
    });
    var gh = $('ghSkins');
    if (gh) gh.textContent = ownedCount + '/' + Skins.LIST.length;
  }

  /* ---------- trail shop ---------- */

  /* Tile preview: a falling drip of the trail's colors. */
  function buildTrailRow() {
    el.trailRow.innerHTML = '';
    var selected = Store.getTrail();
    var ownedCount = 0;
    Trails.LIST.forEach(function (t) {
      var owned = Trails.isOwned(t.id);
      if (owned) ownedCount++;
      var btn = document.createElement('button');
      btn.className = 'skin' + (t.id === selected ? ' selected' : '') + (owned ? '' : ' locked');
      tileAria(btn, t.name + ' trail', t.id === selected, !owned, t.cost);

      var cv = document.createElement('canvas');
      cv.className = 'dot';
      cv.width = 64; cv.height = 64;
      var cc = cv.getContext('2d');
      cc.scale(2, 2);
      if (t.emit) {
        // a diagonal sprinkle of the trail's palette
        for (var i = 0; i < 7; i++) {
          var fx = 6 + i * 3.2, fy = 24 - i * 2.6;
          cc.globalAlpha = 0.35 + (i / 7) * 0.65;
          cc.fillStyle = t.emit.colors[i % t.emit.colors.length];
          var s = 1.6 + (i / 7) * 2.4;
          cc.fillRect(fx - s / 2, fy - s / 2, s, s);
        }
        cc.globalAlpha = 1;
      } else {
        // 'none': a slash through an empty dot
        cc.strokeStyle = '#8fa3c8';
        cc.lineWidth = 2;
        cc.beginPath(); cc.arc(16, 16, 9, 0, Math.PI * 2); cc.stroke();
        cc.beginPath(); cc.moveTo(10, 22); cc.lineTo(22, 10); cc.stroke();
      }
      btn.appendChild(cv);

      var tag = document.createElement('span');
      tag.className = 'tag';
      tag.innerHTML = owned ? t.name : '&#9670;' + t.cost;
      btn.appendChild(tag);

      btn.addEventListener('click', function () { onTrailTap(t, btn); });
      el.trailRow.appendChild(btn);
    });
    var gh = $('ghTrails');
    if (gh) gh.textContent = ownedCount + '/' + Trails.LIST.length;
  }

  function onTrailTap(t, btn) {
    if (Trails.isOwned(t.id)) {
      Store.setTrail(t.id);
      Sound.click();
    } else if (Trails.buy(t.id)) {
      Store.setTrail(t.id);
      Sound.unlockSkin();
    } else {
      Sound.deny();
      btn.classList.remove('denied');
      void btn.offsetWidth;
      btn.classList.add('denied');
      return;
    }
    Game.refreshTrail(); // the menu attract loop previews it immediately
    el.menuGemsVal.textContent = Store.getGems();
    buildTrailRow();
  }

  /* ---------- theme (world) picker ---------- */

  /* Tile preview: the world's bg + ring + a reward and a danger dot. */
  function buildThemeRow() {
    el.themeRow.innerHTML = '';
    var selected = Store.getTheme();
    var gh = $('ghThemes');
    if (gh) gh.textContent = Themes.LIST.length + ' worlds';
    Themes.LIST.forEach(function (t) {
      var btn = document.createElement('button');
      btn.className = 'skin theme-tile' + (t.id === selected ? ' selected' : '');
      tileAria(btn, t.name + ' theme', t.id === selected, false, 0);

      // 3x backing store: theme tiles render larger in the 3-column grid
      var cv = document.createElement('canvas');
      cv.className = 'dot';
      cv.width = 96; cv.height = 96;
      var cc = cv.getContext('2d');
      cc.scale(3, 3);
      cc.fillStyle = t.c.bgOuter; cc.fillRect(0, 0, 32, 32);
      cc.fillStyle = t.c.bgInner; cc.beginPath(); cc.arc(16, 16, 15, 0, Math.PI * 2); cc.fill();
      cc.strokeStyle = t.ringTint || t.c.gem; cc.lineWidth = 2;
      cc.beginPath(); cc.arc(16, 16, 10, 0, Math.PI * 2); cc.stroke();
      cc.fillStyle = t.c.gem; cc.beginPath(); cc.arc(11, 16, 2.3, 0, Math.PI * 2); cc.fill();
      cc.fillStyle = t.c.spikeTip; cc.beginPath(); cc.arc(21, 16, 2.3, 0, Math.PI * 2); cc.fill();
      btn.appendChild(cv);

      var tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = t.name;
      btn.appendChild(tag);

      btn.addEventListener('click', function () { onThemeTap(t); });
      el.themeRow.appendChild(btn);
    });
  }

  function onThemeTap(t) {
    Themes.select(t.id);
    Sound.click();
    Game.refreshTheme(); // the menu attract loop previews the world live
    buildThemeRow();
  }

  function onSkinTap(s, btn) {
    if (s.custom) { onCustomTap(s); return; }
    if (Skins.isOwned(s.id)) {
      Store.setSkin(s.id);
      Sound.click();
    } else if (Skins.buy(s.id)) {
      Store.setSkin(s.id);
      Sound.unlockSkin();
    } else {
      // can't afford: shake the tile
      Sound.deny();
      btn.classList.remove('denied');
      void btn.offsetWidth; // restart the CSS animation
      btn.classList.add('denied');
      return;
    }
    applyAccent();
    Game.refreshSkin();
    el.menuGemsVal.textContent = Store.getGems();
    refreshMenuSouls(); // a Soul-skin buy spent Souls, not gems
    buildSkinRow();
  }

  function refreshMenuSouls() {
    var s = Store.getSouls();
    if (el.menuSouls) el.menuSouls.textContent = s;
    // hide the Souls chip until the player has ever touched the Descent economy
    if (el.soulChip) el.soulChip.classList.toggle('hidden', s <= 0 && Store.getSoulsTotal() <= 0);
  }

  return {
    init: init,
    showMenu: showMenu,
    showHUD: showHUD,
    setZenHud: setZenHud,
    showGameOver: showGameOver,
    hideGameOver: hideGameOver,
    hideRevive: hideRevive,
    hideDouble: hideDouble,
    markDoubled: markDoubled,
    refreshOffers: refreshOffers,
    refreshMenuGems: refreshMenuGems,
    showPause: showPause,
    showCountdown: showCountdown,
    setScore: setScore,
    setSphere: setSphere,
    setRelicRail: setRelicRail,
    showRelic: showRelic,
    showWarden: showWarden,
    wardenTick: wardenTick,
    endWarden: endWarden,
    setRunGems: setRunGems,
    setMult: setMult,
    showCombo: showCombo,
    showMilestone: showMilestone,
    showStorm: showStorm,
    showPot: showPot,
    showLevelUp: showLevelUp,
    showTutorial: showTutorial,
    closeTopModal: closeTopModal,
    adsReady: adsReady,
    /* exposed for tests */
    _validatePhotoFile: validatePhotoFile
  };
})();
