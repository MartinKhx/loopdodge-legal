/* Tiny particle system with a hard cap so low-end phones never
 * drown in draw calls. Used for gem pickups, death bursts and
 * the new-best celebration. */
var Particles = (function () {
  var MAX = 220;
  var list = [];

  /* Radial burst at (x, y). opts: speed, size, life, gravity, spread. */
  function burst(x, y, color, count, opts) {
    opts = opts || {};
    var speed = opts.speed || 160;
    var size = opts.size || 4;
    var life = opts.life || 0.6;
    for (var i = 0; i < count; i++) {
      if (list.length >= MAX) break;
      var ang = Math.random() * Math.PI * 2;
      var vel = speed * (0.35 + Math.random() * 0.65);
      list.push({
        x: x, y: y,
        vx: Math.cos(ang) * vel,
        vy: Math.sin(ang) * vel,
        size: size * (0.6 + Math.random() * 0.8),
        life: life * (0.6 + Math.random() * 0.6),
        maxLife: life,
        gravity: opts.gravity || 0,
        color: color
      });
    }
  }

  /* Single particle for the cosmetic ball trails. Reserves headroom
   * under the cap so a death burst or celebration is never starved by
   * cosmetics. spec: { speed, size, life, gravity, colors[] }. */
  function emit(x, y, spec) {
    if (list.length >= MAX - 40) return;
    var ang = Math.random() * Math.PI * 2;
    var vel = (spec.speed || 20) * (0.4 + Math.random() * 0.6);
    list.push({
      x: x, y: y,
      vx: Math.cos(ang) * vel,
      vy: Math.sin(ang) * vel,
      size: (spec.size || 3) * (0.7 + Math.random() * 0.6),
      life: (spec.life || 0.5) * (0.7 + Math.random() * 0.6),
      maxLife: spec.life || 0.5,
      gravity: spec.gravity || 0,
      color: spec.colors[(Math.random() * spec.colors.length) | 0]
    });
  }

  function count() { return list.length; }

  function update(dt) {
    // Velocity drag must be ELAPSED-TIME based, not per-frame: a flat
    // `vx *= 0.94` each frame decays ~2x faster at 120Hz than 60Hz, making
    // bursts and trails visibly shorter on high-refresh phones. 0.94 is the
    // per-(1/60s)-frame factor, so raise it to the number of 60ths elapsed.
    var drag = Math.pow(0.94, dt * 60);
    for (var i = list.length - 1; i >= 0; i--) {
      var p = list[i];
      p.life -= dt;
      if (p.life <= 0) { list.splice(i, 1); continue; }
      p.vx *= drag;
      p.vy = p.vy * drag + p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  function draw(ctx) {
    for (var i = 0; i < list.length; i++) {
      var p = list[i];
      var a = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      var s = p.size * (0.5 + 0.5 * a);
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
    }
    ctx.globalAlpha = 1;
  }

  function clear() { list.length = 0; }

  return { burst: burst, emit: emit, count: count, update: update, draw: draw, clear: clear,
           /* test hook: the live particle list (harmless in production) */
           _peek: function () { return list; } };
})();
