/* Loop Dodge — core game.
 *
 * A ball orbits clockwise around a neon ring. Tapping toggles it
 * between the inner and outer lane. Spikes kill, gems pay, speed
 * ramps up, score is seconds survived.
 *
 * Everything is angle-based: entities live at a fixed angle on a
 * lane; `totalAngle` (the ball's cumulative travel in radians) is
 * the master clock for spawning and expiring them, which keeps
 * difficulty fair at any speed or frame rate.
 */
var Game = (function () {
  var TAU = Math.PI * 2;

  /* ---------- tuning ---------- */
  var CFG = {
    baseSpeed: 1.7,          // rad/s at t=0
    maxSpeed: 3.6,           // rad/s cap
    rampPerSec: 0.022,       // rad/s gained per second survived
    spawnLead: Math.PI,      // entities appear half a loop ahead of the ball
    gapMin: 0.55,            // min radians between spawns (same lane)
    gapMinSwitch: 1.0,       // min gap before a spike on the *other* lane (must stay passable)
    gapMaxStart: 1.5,        // spawn gap upper bound at t=0...
    gapMaxEnd: 0.95,         // ...shrinking to this
    gapRampTime: 75,         // seconds to reach the tightest spawning
    gemChance: 0.30,         // chance a spawn is a gem instead of a spike
    laneLerp: 16,            // lane-change snappiness
    deathAnim: 0.9,          // seconds of explosion before the game-over panel
    invulnAfterRevive: 2.2,  // seconds of safety after a rewarded revive
    powerChance: 0.12,       // chance a would-be gem is a power-up (after cooldown)
    powerMinGap: 24,         // min radians of travel between power-ups (~10s)
    magnetTime: 6,           // seconds of gem attraction
    magnetRadius: 0.68,      // ...as a fraction of ringR — must exceed the
                             // cross-lane gap (2*laneOff = 0.54*ringR) or the
                             // magnet can never reach the other lane
    slowTime: 4,             // seconds of slow-mo
    slowScale: 0.6,          // world speed multiplier while slowed
    shieldInvuln: 1.0,       // safety seconds after the shield absorbs a hit
    doubleTime: 8,           // seconds of x2 gem value (Doubler power-up)
    feastTime: 4,            // seconds spikes are edible (Feast power-up)
    feastGems: 3,            // flat gems per spike eaten during a feast

    /* --- pulser obstacle (round 2) ---
     * A spike that cycles armed/disarmed. The cycle advances with
     * totalAngle, NOT wall time: the ball always arrives spawnLead
     * radians after spawn, so whether a pulser is armed on arrival is
     * deterministic relative to its spawn roll — slow-mo can't desync
     * it (wScale scales time and totalAngle together). For the lane-
     * fairness bookkeeping a pulser counts as ALWAYS blocking, so the
     * escape lane never depends on catching a disarmed phase. */
    pulserStart: 20,         // seconds survived before pulsers may appear
    pulserChance: 0.18,      // chance an eligible spike spawns as a pulser
    pulserOn: 2.2,           // radians of travel spent armed (lethal)...
    pulserOff: 2.2,          // ...then disarmed (safe to pass)
    pulserWarn: 0.7,         // glow ramps up this many radians before arming

    /* --- milestone storm waves (round 2) ---
     * warn (flash + rising tone) -> burst (denser spawns, gems x2) ->
     * calm (no spawns, breathe). The first storm lands at 25s so a
     * decent first-session run still sees one; every 30s after that.
     * Burst density only squeezes gapMax — gapMin and gapMinSwitch
     * (the fairness guarantees) are never touched. */
    stormFirst: 25,          // seconds survived when the first warning starts
    stormEvery: 30,          // storm cadence after the first one
    stormWarn: 3,            // warning seconds
    stormBurst: 5,           // burst seconds (gems pay x2, NOT stacking with the Doubler)
    stormCalm: 3,            // post-burst no-spawn reward beat
    stormGapScale: 0.62,     // burst: gapMax multiplier (clamped above gapMin)

    /* --- Storm Bank (house-money ride pot) ---
     * Weathering a burst earns a POT of house money kept SEPARATE from
     * collected gems. A gate in the calm lets you BANK it (inner lane —
     * merged into your gems, safe forever) or RIDE it (outer lane — the
     * pot doubles at the next storm). Dying while riding forfeits ONLY
     * the unbanked pot — never a gem you actually collected — because the
     * pot lives outside runGems until the moment you bank it. Flat (not
     * track-scaled): it's a press-your-luck layer on top of gem income,
     * not gem income itself. */
    stormBankBase: 10,       // a fresh pot, the first storm after a bank
    stormBankCap: 250,       // pot ceiling so a long ride can't run away

    hitStopTime: 0.08,       // impact freeze on death (skipped by Reduce motion)

    /* --- Warden duels (P2.1): personal-run boss encounters at Sphere IV/VI.
     * Gated OFF the seeded daily AND Zen, so determinism + no-fail are never
     * touched. The track morph is dodging-INVARIANT (it shifts the ball AND
     * the spikes together; the cross-lane gap stays 2*laneOff), and attacks
     * are SCRIPTED single-lane telegraphs (no rng), so a safe lane always
     * exists — the radial-clearance guarantee, by construction. */
    wardenTelegraph: 2.4,    // telegraph card + morph-in before the duel
    wardenWrithe: 0.9,       // morph phase speed (the creature undulates)
    wardenMorphAmp: 0.15,    // max radial deformation (fraction of trackR)
    wardenFirstAttack: 1.6,  // grace before the first scripted attack
    wardenSoulReward: 4      // Souls granted for surviving a Warden duel
  };

  var State = { MENU: 'menu', PLAYING: 'playing', DYING: 'dying', OVER: 'over', PAUSED: 'paused' };
  var state = State.MENU;
  // slow-mo / storm wash colors come from the active theme (TC.slow / TC.storm),
  // applied with globalAlpha — constant strings per theme, no per-frame alloc

  /* ---------- canvas & geometry ---------- */
  var canvas, ctx, cb = {};
  var w = 0, h = 0, dpr = 1;
  var cx = 0, cy = 0, ringR = 0, laneOff = 0, ballR = 0, spikeLen = 0, gemR = 0;
  var popFont = '800 12px system-ui, sans-serif'; // float-label font, recomputed in resize()
  var bgCanvas = null, ringCanvas = null, ringSize = 0;

  /* ---------- run state ---------- */
  var time = 0;              // seconds survived (the score)
  var speed = CFG.baseSpeed;
  var totalAngle = 0;        // cumulative ball travel, radians
  // `off` is the radial offset from the track curve (lerps between lanes)
  var ball = { angle: -Math.PI / 2, lane: 1, off: 0 };
  var ents = [];             // { type:'spike'|'gem'|'power', kind, lane, angle, born, scale, ... }
  var spawnNextAt = 0;       // totalAngle at which the next entity spawns
  var lastSpikeLane = 1, lastSpikeAt = -10;
  var lastPowerAt = -100;    // totalAngle of the last power-up spawn
  var rng = Math.random;     // spawner randomness (seeded for the daily challenge)
  // active power-up effects
  var shieldOn = false;
  var magnetT = 0, slowT = 0, doubleT = 0, feastT = 0;
  var zenMode = false;       // Zen Drift: no-fail relax mode (no death, no economy)
  // storm wave state (phase derives from `time`; see stormPhaseAt)
  var stormPhase = 'none';   // none | warn | burst | calm
  var stormsRun = 0;         // bursts fully weathered this run
  var reportedStorms = 0;    // storms already credited (revive = 2 game overs)
  // Storm Bank: house-money pot, kept OUT of runGems until banked (so a
  // ride lost on death never touches a collected gem)
  var stormPot = 0;          // per-storm gem pot, banked safely at the Pact-Gate
  var pactGate = null;       // active Pact-Gate { born, angle, decided, scale, relics, opening }
  var relicState = Relics.freshState(); // per-run drafted-relic effects (fairness-neutral scalars)
  var relicRng = Math.random;           // SEPARATE seeded stream for relic OFFERS (spawn rng untouched)
  var pactCount = 0;         // gate ordinal this run; drives the relic tier ramp (framerate-independent)
  var seedRelicId = null;    // Forge Seed: attuned relic biased into the OPENING offer (personal runs only)
  var reportedSouls = 0;     // Souls already credited this run (revive double-finalize watermark)
  // Ghost racing (P0.2): recorder for THIS run + an optional racer tape replayed
  // beside you on the same seed. Pure render — never touches sim/economy/clock.
  var recTape = null;        // { start, sw:[totalAngle...], end, score } — this run's tape
  var ghostTape = null;      // the tape being replayed (null = no ghost this run)
  var ghostIdx = 0;          // monotonic cursor into ghostTape.sw
  var ghostOff = 0;          // eased lane offset for the ghost ball
  var ghostOn = true;        // preference toggle (Game.setGhost / Reduce-motion friendly)
  var ghostPassedFired = false; // fired the "outlasted your best" beat once
  var nmSincePhalanx = 0;    // near-miss counter for the Phalanx relic's shield-reform
  // Warden duels (P2.1): a personal-run boss phase at Sphere IV/VI. Gated OFF
  // the seeded daily + Zen, so neither determinism nor no-fail is touched.
  var wardenState = 'none';  // none | telegraph | duel
  var wardenT = 0;           // seconds remaining in the current Warden state
  var wardenIdx = 0;         // which Warden (cycles Wardens.LIST)
  var wardenLobes = 3;       // current Warden's morph lobe count
  var wardenMorph = 0;       // 0..1 eased morph amount (drives trackR deformation)
  var wardenMorphTarget = 0; // where wardenMorph is easing toward
  var wardenMorphPhase = 0;  // animates the morph (the creature writhes)
  var wardenAttackT = 0;     // countdown to the next scripted attack
  var wardenAttackN = 0;     // attack index (drives the single-lane pattern)
  var wardensTriggered = 0;  // Wardens started this run (trigger gate)
  var wardenAllowed = false; // personal run AND not Zen (set in startRun)
  var wardenSouls = 0;       // Souls earned from Wardens this run (folded into the depth payout)
  var lastWardenPct = -1;    // last timer-bar percent emitted (engine-driven, pauses correctly)
  var wScale = 1;            // world speed multiplier (slow-mo lerps it)
  // first-ever run: world at half speed + tap hint until the first dodge
  var tutorial = false;
  // near-miss combo: consecutive close passes within the time window
  var comboN = 0, comboT = 0;
  var maxCombo = 0;          // best combo this run (game-over recap / stats)
  var scoreBonus = 0;        // points earned from near misses (kept out of
                             // `time` so the difficulty ramp is unaffected)
  var runGems = 0;
  var bankedGems = 0;        // run gems already persisted to Store (gems are
                             // banked once per game over, not per pickup —
                             // a localStorage write per gem janks weak phones)
  var laneSwitches = 0;      // per-run tap count (missions)
  var nearMisses = 0;        // per-run near misses (combo + missions)
  var reportedGems = 0;      // gems already sent to missions (revive = 2 game overs)
  var reportedNM = 0;        // near misses already reported, same reason
  var reportedSec = 0;       // seconds already reported, same reason
  var prevBestCache = 0;     // best at run start (no Store reads in the loop)
  var bestNotified = false;  // mid-run "BEST!" flash fired this run
  var runId = 0;             // stable id per run (a revive keeps the same id)
  var runConfigRevision = 'builtin';
  var deathCause = 'unknown';

  function analyticsSummary() {
    return { score: Math.floor(time) + scoreBonus, seconds: Math.floor(time), gems: runGems,
      near_misses: nearMisses, switches: laneSwitches, best_combo: maxCombo,
      storms: stormsRun, sphere: sphere + 1, revived: usedRevive, death_cause: deathCause };
  }
  var usedRevive = false;
  var invuln = 0;
  var deathTimer = 0;
  var hitStop = 0;           // brief freeze on impact (death juice)
  var deathX = 0, deathY = 0;// impact point: the death zoom centres here
  var reduceMotion = false;  // cached accessibility toggle (no Store reads in the loop)
  var reduceFlash = false;   // cached: damp full-screen flashing (storm warn pulse)
  var shakeT = 0, shakeDur = 0.45, shakeMag = 8;
  // universal juice (render-only, decays each frame, off under Reduce motion):
  var ballSquash = 0;        // signed: + = stretch along motion, - = squash (jelly)
  var ringPulse = 0;         // 0..1: the track ring flares brighter/bigger on events
  var camKick = 0;           // 0..1: a subtle zoom-toward-centre punch on big events
  // ---- Strata / Descent (v10 P0.1): the world wakes as you descend ----
  // Pure render + time-derived; ZERO rng, ZERO clock touch (daily-safe).
  var SPHERE_SECONDS = 20;   // survival seconds per Sphere
  var SPHERE_MAX = 6;        // Spheres 0..6 (shown as I..VII)
  var sphere = 0;            // current Sphere depth (0..6), derived from `time`
  var depthF = 0;            // 0..1 continuous depth, drives parallax/atmosphere
  var worldClock = 0;        // always-advancing render clock (parallax drift, menu too)
  var strataCanvas = null;   // baked parallax dust field, blitted scrolling behind the ring
  var trail = [];
  var trailAcc = 0;          // fractional emitter accumulator (cosmetic trail)
  var BALL_GLOW = [[2.3, 0.08], [1.65, 0.16], [1.18, 0.38]]; // ball glow rings (hoisted: no per-frame alloc)
  var bloomAcc = 0;          // fractional emitter accumulator (storm bloom FX)
  var pops = [];             // pooled feedback rings on pickups: {x,y,t,life,r,color,text}
  var lastDeath = null; // debug: what triggered the last collision
  var lastShownScore = -1, lastShownGems = -1, lastShownRate = -1;

  /* ---------- helpers ---------- */

  // cached skin/level/trail/theme/tuning: no localStorage reads inside the frame loop
  var curSkin = null, curLevel = null, curTrail = null, curTheme = null, curTune = {};
  // theme palette shorthand (curTheme.c), re-pointed on every theme change
  var TC = {};

  /* Track radius at an angle — the selected level's polar shape, plus the
   * Warden's smooth radial morph during a duel. The morph shifts the ball AND
   * the spikes (both read trackR), and the lane gap is 2*laneOff regardless,
   * so it never changes passability — it's dodging-invariant feel. */
  function trackR(theta) {
    var base = ringR * curLevel.r(theta);
    // Reduce motion suppresses the writhe: large-amplitude full-playfield
    // geometric motion is a vestibular trigger. The morph is dodging-invariant
    // (it shifts ball + spikes together, gap stays 2*laneOff), so dropping it
    // changes only feel — the boss still reads via the wash + boss-tinted ring.
    if (wardenMorph > 0.0001 && !reduceMotion) {
      base *= 1 + Wardens.deform(theta, wardenMorphPhase, wardenLobes, CFG.wardenMorphAmp, wardenMorph);
    }
    return base;
  }

  function wardenActive() { return wardenState !== 'none'; }

  function laneSign(lane) { return lane === 0 ? -1 : 1; }

  /* Radial position of a lane at a given angle. */
  function laneRadiusAt(lane, theta) { return trackR(theta) + laneSign(lane) * laneOff; }

  /* The ball rides exactly on the curve plus its (lerped) lane offset. */
  function ballRadius() { return trackR(ball.angle) + ball.off; }

  /* Per-level personality knob, with a safe default (levels.js tuning). */
  function tune(key) { return curTune[key] || 0; }

  /* Is this pulser lethal right now? Phase advances with totalAngle
   * (see CFG.pulserOn) and each pulser carries a spawn-rolled offset
   * so they don't all blink in unison. */
  function pulserArmed(e) {
    var cycle = CFG.pulserOn + CFG.pulserOff;
    var ph = (totalAngle + e.phase) % cycle;
    return ph < CFG.pulserOn;
  }

  /* 0..1 glow ramp shown just before a disarmed pulser arms again. */
  function pulserWarnK(e) {
    var cycle = CFG.pulserOn + CFG.pulserOff;
    var ph = (totalAngle + e.phase) % cycle;
    if (ph < CFG.pulserOn) return 1; // armed: full glow
    var toArm = cycle - ph;
    return toArm < CFG.pulserWarn ? 1 - toArm / CFG.pulserWarn : 0;
  }

  /* Storm phase for a given run clock. Derived (not stateful), so the
   * seeded daily challenge stays identical for every player. */
  function stormPhaseAt(t) {
    if (t < CFG.stormFirst) return 'none';
    var lt = (t - CFG.stormFirst) % CFG.stormEvery;
    if (lt < CFG.stormWarn) return 'warn';
    if (lt < CFG.stormWarn + CFG.stormBurst) return 'burst';
    if (lt < CFG.stormWarn + CFG.stormBurst + CFG.stormCalm) return 'calm';
    return 'none';
  }

  function trackPoint(theta) {
    var r = trackR(theta);
    return { x: cx + Math.cos(theta) * r, y: cy + Math.sin(theta) * r };
  }

  /* Local frame of the track at an angle: point on the curve, unit
   * tangent, and outward unit normal. Computed numerically so it
   * works for every level shape (polygons, flowers, ovals...).
   *
   * Writes into a SHARED scratch object (no per-frame allocation) — it's
   * called per spike/pulser per frame in both collision and render. Safe
   * because every caller reads the result immediately and only one frame is
   * ever alive at a time (never two trackFrame results held at once). The
   * point math is inlined (was 3x trackPoint -> 3 {x,y} temporaries). */
  var _frame = { p: { x: 0, y: 0 }, tx: 0, ty: 0, nx: 0, ny: 0 };
  function trackFrame(theta) {
    var e = 0.02;
    var ra = trackR(theta - e), rb = trackR(theta + e), rp = trackR(theta);
    var ax = cx + Math.cos(theta - e) * ra, ay = cy + Math.sin(theta - e) * ra;
    var bx = cx + Math.cos(theta + e) * rb, by = cy + Math.sin(theta + e) * rb;
    var px = cx + Math.cos(theta) * rp, py = cy + Math.sin(theta) * rp;
    var tx = bx - ax, ty = by - ay;
    var l = Math.sqrt(tx * tx + ty * ty) || 1;
    tx /= l; ty /= l;
    var nx = ty, ny = -tx;
    if (nx * (px - cx) + ny * (py - cy) < 0) { nx = -nx; ny = -ny; }
    _frame.p.x = px; _frame.p.y = py;
    _frame.tx = tx; _frame.ty = ty; _frame.nx = nx; _frame.ny = ny;
    return _frame;
  }

  /* How sharply the track bends at an angle (radians of turn across a
   * small window). Used to keep spikes off polygon corners, where a
   * straight-based triangle can't sit flush. */
  function turnAngle(theta) {
    var e = 0.07;
    var a = trackPoint(theta - e), p = trackPoint(theta), b = trackPoint(theta + e);
    var v1x = p.x - a.x, v1y = p.y - a.y, v2x = b.x - p.x, v2y = b.y - p.y;
    var dot = (v1x * v2x + v1y * v2y) /
      ((Math.sqrt(v1x * v1x + v1y * v1y) * Math.sqrt(v2x * v2x + v2y * v2y)) || 1);
    return Math.acos(Math.max(-1, Math.min(1, dot)));
  }

  function distToSeg(px, py, x1, y1, x2, y2) {
    var dx = x2 - x1, dy = y2 - y1;
    var t = ((px - x1) * dx + (py - y1) * dy) / ((dx * dx + dy * dy) || 1);
    t = Math.max(0, Math.min(1, t));
    dx = px - (x1 + dx * t); dy = py - (y1 + dy * t);
    return Math.sqrt(dx * dx + dy * dy);
  }

  /* Distance from a point to the spike's solid triangle, 0 if inside.
   * Same geometry as drawSpike (minus the visual 2px base sink), so
   * the kill zone is exactly what the player sees — base included.
   * (The old single hit point near the tip let the ball slip through
   * the lower half of the spike when switching lanes late.) */
  function spikeDist(e, px, py) {
    var dir = laneSign(e.lane);
    var f = trackFrame(e.angle);
    var half = ballR * 1.05;
    var len = spikeLen * e.scale;
    var x1 = f.p.x + f.tx * half, y1 = f.p.y + f.ty * half;            // base corners
    var x2 = f.p.x - f.tx * half, y2 = f.p.y - f.ty * half;
    var x3 = f.p.x + f.nx * dir * len, y3 = f.p.y + f.ny * dir * len;  // tip
    var d1 = (px - x1) * (y3 - y1) - (py - y1) * (x3 - x1);
    var d2 = (px - x3) * (y2 - y3) - (py - y3) * (x2 - x3);
    var d3 = (px - x2) * (y1 - y2) - (py - y2) * (x1 - x2);
    if (!((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0))) return 0;
    return Math.min(distToSeg(px, py, x1, y1, x3, y3),
                    distToSeg(px, py, x3, y3, x2, y2),
                    distToSeg(px, py, x2, y2, x1, y1));
  }

  function angDist(a, b) {
    var d = Math.abs(a - b) % TAU;
    return d > Math.PI ? TAU - d : d;
  }

  function rgba(hex, a) {
    var n = parseInt(hex.slice(1), 16);
    return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  /* ---------- setup / geometry ---------- */

  function init(canvasEl, callbacks) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d');
    cb = callbacks || {};
    curSkin = Skins.current();
    curLevel = Levels.current();
    curTune = curLevel.tuning || {};
    curTrail = Trails.current();
    applyTheme();
    reduceMotion = Store.getReduceMotion();
    reduceFlash = Store.getReduceFlash();
    ball.off = laneSign(ball.lane) * laneOff;
    resize();
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2); // cap DPR: huge win on low-end phones
    // Guard against degenerate sizes (minimized/hidden window, WebView
    // reporting 0 during init) — they'd collapse the whole geometry.
    var iw = window.innerWidth, ih = window.innerHeight;
    if (iw < 80 || ih < 80) {
      if (w >= 80 && h >= 80) return; // keep the last sane geometry
      iw = 360; ih = 640;             // first call: fall back to a phone-ish size
    }
    w = iw;
    h = ih;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    cx = w / 2;
    cy = h * 0.54;
    // Solve for ringR so the OUTER lane plus the ball plus its glow
    // always stays on screen: ringR*(1 + laneOff% + ballR%) + pad <= bound.
    // (The old formula clipped the ball on tall narrow phones.)
    var bound = Math.min(w * 0.5, h * 0.33) - 12;
    ringR = bound / 1.38;
    laneOff = ringR * 0.27;
    ballR = Math.max(7, ringR * 0.078);
    spikeLen = laneOff + ballR * 0.6;
    gemR = ballR * 0.85;
    popFont = '800 ' + (ballR * 0.85).toFixed(1) + 'px system-ui, sans-serif'; // cached: no per-frame rebuild

    buildBackground();
    buildStrata();
    buildRing();
    buildSkinIcon();
    buildPowerIcons();
  }

  /* Strata: a faint parallax dust field baked once, blitted scrolling behind
   * the ring so the world "descends". Resize-time bake (Math.random here is
   * cosmetic only — it never touches the seeded spawn stream). */
  function buildStrata() {
    strataCanvas = document.createElement('canvas');
    strataCanvas.width = Math.round(w * dpr);
    strataCanvas.height = Math.round(2 * h * dpr); // 2x tall, tiled twice (period
    var c = strataCanvas.getContext('2d');          // h) so ONE blit wraps it
    c.scale(dpr, dpr);                              // seamlessly — half the fill
    var n = Math.min(130, Math.round((w * h) / 9000));
    for (var i = 0; i < n; i++) {
      var dx = Math.random() * w, dy = Math.random() * h, dr = 0.4 + Math.random() * 1.6;
      c.globalAlpha = 0.08 + Math.random() * 0.16;
      c.fillStyle = (i % 5 === 0) ? '#9fd0ff' : '#cfe6ff';
      c.beginPath(); c.arc(dx, dy, dr, 0, TAU); c.fill();
      c.beginPath(); c.arc(dx, dy + h, dr, 0, TAU); c.fill(); // periodic copy
    }
    for (var b = 0; b < 4; b++) {
      var by = ((b + 0.5) / 4 + (Math.random() - 0.5) * 0.1) * h;
      c.globalAlpha = 0.05;
      c.fillStyle = '#5f7bff';
      c.fillRect(0, by, w, 1.5);
      c.fillRect(0, by + h, w, 1.5); // periodic copy
    }
    c.globalAlpha = 1;
  }

  /* Background, baked ONCE per resize to bgCanvas and blitted each frame.
   * Dispatches to the active theme's world; a universal vignette focuses
   * the eye on the ring. (Gradients/loops here are resize-time only — the
   * per-frame cost is a single drawImage, same as before.) */
  function buildBackground() {
    bgCanvas = document.createElement('canvas');
    bgCanvas.width = Math.round(w * dpr);
    bgCanvas.height = Math.round(h * dpr);
    var c = bgCanvas.getContext('2d');
    c.scale(dpr, dpr);
    var bg = curTheme.bg;
    if (bg === 'abyss') bakeAbyss(c);
    else if (bg === 'aurora') bakeAurora(c);
    else if (bg === 'molten') bakeMolten(c);
    else if (bg === 'synth') bakeSynth(c);
    else bakeSpace(c);
    bakeVignette(c);
    c.globalAlpha = 1;
  }

  /* Classic: radial space gradient + scattered starfield. */
  function bakeSpace(c) {
    var g = c.createRadialGradient(cx, cy, ringR * 0.2, cx, cy, Math.max(w, h) * 0.75);
    g.addColorStop(0, TC.bgInner);
    g.addColorStop(1, TC.bgOuter);
    c.fillStyle = g;
    c.fillRect(0, 0, w, h);
    for (var i = 0; i < 46; i++) {
      c.globalAlpha = 0.04 + Math.random() * 0.14;
      c.fillStyle = TC.star;
      var s = Math.random() < 0.85 ? 1 : 2;
      c.fillRect(Math.random() * w, Math.random() * h, s, s);
    }
    c.globalAlpha = 1;
  }

  /* Hadal Bloom: light fades downward into the deep; soft round plankton
   * "marine snow" clustered up high for depth; near-black silt blobs
   * rising from the floor as silhouette parallax. */
  function bakeAbyss(c) {
    var g = c.createRadialGradient(cx, cy * 0.35, ringR * 0.2, cx, cy, Math.max(w, h) * 0.9);
    g.addColorStop(0, TC.bgInner);
    g.addColorStop(1, TC.bgOuter);
    c.fillStyle = g;
    c.fillRect(0, 0, w, h);
    for (var i = 0; i < 60; i++) {
      c.globalAlpha = 0.04 + Math.random() * 0.08;
      c.fillStyle = Math.random() < 0.7 ? TC.star : '#bcd2ff';
      var yy = Math.pow(Math.random(), 1.6) * h;      // denser near the top
      c.beginPath();
      c.arc(Math.random() * w, yy, 1 + Math.random() * 1.5, 0, TAU);
      c.fill();
    }
    c.globalAlpha = 0.5;
    c.fillStyle = '#04101c';
    for (var k = 0; k < 4; k++) {
      var bx = (k + 0.5) / 4 * w + (Math.random() - 0.5) * 80;
      c.beginPath();
      c.moveTo(bx - 70, h);
      c.quadraticCurveTo(bx, h - 120 - Math.random() * 80, bx + 70, h);
      c.fill();
    }
    c.globalAlpha = 1;
  }

  /* Universal vignette: darken the corners so the ring reads as the
   * lit focal point. Baked into the bg, so it's free per frame. */
  function bakeVignette(c) {
    var g = c.createRadialGradient(cx, cy, Math.min(w, h) * 0.3, cx, cy, Math.max(w, h) * 0.62);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, TC.vignette);
    c.fillStyle = g;
    c.fillRect(0, 0, w, h);
  }

  /* Cosmic Aurora: cool space gradient, soft nebula blobs for depth, and
   * a two-tier starfield (far violet + near white). */
  function bakeAurora(c) {
    var g = c.createRadialGradient(cx, cy, ringR * 0.2, cx, cy, Math.max(w, h) * 0.8);
    g.addColorStop(0, TC.bgInner); g.addColorStop(1, TC.bgOuter);
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    var blobs = [[w * 0.25, h * 0.3, TC.nebulaA], [w * 0.75, h * 0.25, TC.nebulaB],
                 [w * 0.6, h * 0.7, TC.nebulaA], [w * 0.2, h * 0.78, TC.nebulaB],
                 [w * 0.85, h * 0.6, TC.nebulaA]];
    for (var b = 0; b < blobs.length; b++) {
      var r = Math.max(w, h) * 0.36;
      var ng = c.createRadialGradient(blobs[b][0], blobs[b][1], 0, blobs[b][0], blobs[b][1], r);
      ng.addColorStop(0, blobs[b][2]); ng.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = ng; c.fillRect(0, 0, w, h);
    }
    for (var i = 0; i < 34; i++) { c.globalAlpha = 0.04 + Math.random() * 0.10; c.fillStyle = TC.star; c.fillRect(Math.random() * w, Math.random() * h, 1, 1); }
    for (var j = 0; j < 14; j++) { c.globalAlpha = 0.15 + Math.random() * 0.25; c.fillStyle = '#dce8ff'; c.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
    c.globalAlpha = 1;
  }

  /* Emberfall: a white-hot core glow at center fading to obsidian void,
   * magma cracks radiating from behind the ring, dim baked embers. */
  function bakeMolten(c) {
    var g = c.createRadialGradient(cx, cy, ringR * 0.1, cx, cy, Math.max(w, h) * 0.85);
    g.addColorStop(0, TC.coreGlow); g.addColorStop(0.35, TC.bgInner); g.addColorStop(1, TC.bgOuter);
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    var rim = (ringR + laneOff) * 1.2, far = Math.max(w, h) * 0.7;
    for (var k = 0; k < 6; k++) {
      var a = Math.random() * TAU;
      var x = cx + Math.cos(a) * rim, y = cy + Math.sin(a) * rim;
      var ex = cx + Math.cos(a) * far, ey = cy + Math.sin(a) * far;
      var mx = (x + ex) / 2 + (Math.random() - 0.5) * 90, my = (y + ey) / 2 + (Math.random() - 0.5) * 90;
      c.globalAlpha = 0.5; c.strokeStyle = '#9c2a0a'; c.lineWidth = 6;
      c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(mx, my, ex, ey); c.stroke();
      c.globalAlpha = 0.7; c.strokeStyle = TC.coreGlow; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(mx, my, ex, ey); c.stroke();
    }
    for (var i = 0; i < 30; i++) { c.globalAlpha = 0.05 + Math.random() * 0.1; c.fillStyle = TC.star; c.fillRect(Math.random() * w, Math.random() * h, Math.random() < 0.5 ? 1 : 2, 1); }
    c.globalAlpha = 1;
  }

  /* Neon Horizon: a synth sunset — sky gradient, a banded Outrun sun
   * behind the ring, and a magenta perspective grid floor. */
  function bakeSynth(c) {
    var horizon = cy + ringR * 0.6;
    var sg = c.createLinearGradient(0, 0, 0, horizon);
    sg.addColorStop(0, TC.bgOuter); sg.addColorStop(1, TC.bgInner);
    c.fillStyle = sg; c.fillRect(0, 0, w, horizon);
    for (var i = 0; i < 24; i++) { c.globalAlpha = 0.04 + Math.random() * 0.12; c.fillStyle = TC.star; c.fillRect(Math.random() * w, Math.random() * horizon * 0.6, 1, 1); }
    c.globalAlpha = 1;
    var sunY = horizon - 6, sunR = ringR * 0.95;
    var ug = c.createLinearGradient(0, sunY - sunR, 0, sunY + sunR);
    ug.addColorStop(0, TC.sunTop); ug.addColorStop(0.5, TC.sunMid); ug.addColorStop(1, TC.sunLow);
    c.fillStyle = ug; c.beginPath(); c.arc(cx, sunY, sunR, 0, TAU); c.fill();
    c.fillStyle = TC.bgInner;     // banded gaps across the lower sun
    for (var b = 0; b < 6; b++) { c.fillRect(cx - sunR, sunY + sunR * 0.22 + b * (sunR * 0.13), sunR * 2, 2 + b * 1.3); }
    c.fillStyle = '#0a0518'; c.fillRect(0, horizon, w, h - horizon);
    c.strokeStyle = rgba(TC.grid, 0.45); c.lineWidth = 1;
    for (var gx = -10; gx <= 10; gx++) { c.beginPath(); c.moveTo(cx, horizon); c.lineTo(cx + gx * (w / 8), h); c.stroke(); }
    var yy = horizon, step = 6;
    while (yy < h) { c.globalAlpha = 0.45 * (yy - horizon) / (h - horizon) + 0.1; c.beginPath(); c.moveTo(0, yy); c.lineTo(w, yy); c.stroke(); yy += step; step *= 1.32; }
    c.globalAlpha = 1;
  }

  /* The glowing track + faint lane guides, rendered once (shadowBlur
   * is far too slow to run every frame on weak GPUs). The path traces
   * the current level's polar shape. */
  function tracePath(c, m, offset) {
    var STEPS = 240;
    c.beginPath();
    for (var i = 0; i <= STEPS; i++) {
      var t = (i / STEPS) * TAU;
      var r = ringR * curLevel.r(t) + offset;
      var x = m + Math.cos(t) * r;
      var y = m + Math.sin(t) * r;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
  }

  function buildRing() {
    var pad = 42;
    ringSize = (ringR + laneOff) * 2 + pad * 2;
    ringCanvas = document.createElement('canvas');
    ringCanvas.width = ringCanvas.height = Math.round(ringSize * dpr);
    var c = ringCanvas.getContext('2d');
    c.scale(dpr, dpr);
    c.lineJoin = 'round';
    var m = ringSize / 2;
    // ring color = the theme's world tint, or the equipped skin on Classic
    var ringColor = curTheme.ringTint || curSkin.color;

    // lane guides
    c.strokeStyle = rgba(ringColor, 0.10);
    c.lineWidth = 1.5;
    c.setLineDash([3, 9]);
    tracePath(c, m, -laneOff); c.stroke();
    tracePath(c, m, laneOff); c.stroke();
    c.setLineDash([]);

    // glow pass (shadowBlur baked ONCE here, never per frame), then a
    // crisp core line — the shared base for every ring style
    c.shadowColor = ringColor;
    c.shadowBlur = 24;
    c.strokeStyle = rgba(ringColor, 0.55);
    c.lineWidth = 4;
    tracePath(c, m, 0); c.stroke();
    c.shadowBlur = 0;
    c.strokeStyle = 'rgba(230,240,255,0.9)';
    c.lineWidth = 2;
    tracePath(c, m, 0); c.stroke();

    // Hadal Bloom: bake glowing coral polyps along the track so the ring
    // reads as a living filament, not a tube
    if (curTheme.ringStyle === 'coral') {
      var NODES = 54;
      c.fillStyle = TC.gem;
      for (var i = 0; i < NODES; i++) {
        var t = (i / NODES) * TAU;
        var r = ringR * curLevel.r(t);
        c.globalAlpha = 0.45 + (i % 3) * 0.12;
        c.beginPath();
        c.arc(m + Math.cos(t) * r, m + Math.sin(t) * r, 1.7 + (i % 3) * 0.9, 0, TAU);
        c.fill();
      }
      c.globalAlpha = 1;
    }
  }

  /* The morphed track, traced LIVE during a Warden duel (the baked ring is a
   * static image and can't deform). Stacked translucent strokes fake the glow
   * with no per-frame shadowBlur. Drawn in screen space under the same camera
   * transform as the entities and ball. */
  function traceMorphed(c, offset) {
    var STEPS = 150;
    c.beginPath();
    for (var i = 0; i <= STEPS; i++) {
      var t = (i / STEPS) * TAU;
      var r = trackR(t) + offset;
      if (i === 0) c.moveTo(cx + Math.cos(t) * r, cy + Math.sin(t) * r);
      else c.lineTo(cx + Math.cos(t) * r, cy + Math.sin(t) * r);
    }
    c.closePath();
  }
  function drawMorphedRing() {
    var col = Wardens.byIndex(wardenIdx).color;
    ctx.save();
    ctx.lineJoin = 'round';
    ctx.lineWidth = 1.5; ctx.strokeStyle = rgba(col, 0.10);
    traceMorphed(ctx, -laneOff); ctx.stroke();
    traceMorphed(ctx, laneOff); ctx.stroke();
    ctx.lineWidth = 7; ctx.strokeStyle = rgba(col, 0.12 + wardenMorph * 0.22); traceMorphed(ctx, 0); ctx.stroke();
    ctx.lineWidth = 3.5; ctx.strokeStyle = rgba(col, 0.55); traceMorphed(ctx, 0); ctx.stroke();
    ctx.lineWidth = 1.8; ctx.strokeStyle = 'rgba(235,240,255,0.92)'; traceMorphed(ctx, 0); ctx.stroke();
    ctx.restore();
  }

  /* Character skins are prerendered to an offscreen canvas once and
   * drawImage'd every frame (a 30-line face redrawn per frame would
   * hurt low-end phones). Flat skins keep the cheap circle path. */
  var skinIcon = null, skinIconR = 0;
  function buildSkinIcon() {
    if (!curSkin.draw && !curSkin.custom) { skinIcon = null; return; }
    // photo skin not imported/loaded yet: fall back to the flat circle
    if (curSkin.custom && !Skins.customImage()) { skinIcon = null; return; }
    skinIconR = ballR * (curSkin.custom ? 1.15 : 1.35); // characters may overflow (ears, crowns…)
    var size = Math.max(16, Math.ceil(skinIconR * 2 * dpr));
    skinIcon = document.createElement('canvas');
    skinIcon.width = skinIcon.height = size;
    var c = skinIcon.getContext('2d');
    c.scale(size / (skinIconR * 2), size / (skinIconR * 2));
    c.translate(skinIconR, skinIconR);
    Skins.renderIcon(c, ballR, curSkin);
  }

  /* Power-up pickup icons, prerendered once per resize (one cached
   * drawImage per frame, same trick as character skins). Distinct
   * shape AND color per kind so they read at a glance. */
  var POWER_COLOR = { shield: '#4da6ff', magnet: '#ffb02e', slow: '#b86bff',
                      double: '#ffd24a', feast: '#5dff8f' };
  var POWER_KINDS = ['shield', 'magnet', 'slow', 'double', 'feast'];
  /* Doubler and Feast spawn at half the weight of the survival trio so
   * adding them doesn't cut the shield/magnet/slow drop rates by a full
   * fifth each — bonus gems and the brief feast both matter less than
   * the staple survival power-ups. */
  var POWER_WEIGHTS = [1, 1, 1, 0.5, 0.5];
  var powerIcons = {}, powerIconR = 0;

  function pickPowerKind(roll) {
    var total = 0, i;
    for (i = 0; i < POWER_WEIGHTS.length; i++) total += POWER_WEIGHTS[i];
    var r = roll * total;
    for (i = 0; i < POWER_KINDS.length; i++) {
      r -= POWER_WEIGHTS[i];
      if (r < 0) return POWER_KINDS[i];
    }
    return POWER_KINDS[0];
  }

  function buildPowerIcons() {
    powerIconR = gemR * 1.9; // halo included
    var size = Math.max(16, Math.ceil(powerIconR * 2 * dpr));
    powerIcons = {};
    for (var k = 0; k < POWER_KINDS.length; k++) {
      var kind = POWER_KINDS[k];
      var cv = document.createElement('canvas');
      cv.width = cv.height = size;
      var c = cv.getContext('2d');
      c.scale(size / (powerIconR * 2), size / (powerIconR * 2));
      c.translate(powerIconR, powerIconR);
      var col = POWER_COLOR[kind];
      var r = gemR * 1.25;
      // soft halo disc
      c.fillStyle = rgba(col, 0.22);
      c.beginPath(); c.arc(0, 0, r * 1.5, 0, TAU); c.fill();
      c.lineCap = 'round';
      c.lineJoin = 'round';
      if (kind === 'shield') {
        // badge silhouette
        c.fillStyle = col;
        c.beginPath();
        c.moveTo(-r * 0.72, -r * 0.55);
        c.quadraticCurveTo(0, -r * 0.85, r * 0.72, -r * 0.55);
        c.quadraticCurveTo(r * 0.78, r * 0.25, 0, r * 0.9);
        c.quadraticCurveTo(-r * 0.78, r * 0.25, -r * 0.72, -r * 0.55);
        c.fill();
        c.fillStyle = '#eaf6ff';
        c.beginPath(); c.arc(0, 0, r * 0.28, 0, TAU); c.fill();
      } else if (kind === 'magnet') {
        // horseshoe with white pole tips
        c.strokeStyle = col;
        c.lineWidth = r * 0.5;
        c.beginPath(); c.arc(0, -r * 0.15, r * 0.5, Math.PI, 0); c.stroke();
        c.beginPath(); c.moveTo(-r * 0.5, -r * 0.15); c.lineTo(-r * 0.5, r * 0.45); c.stroke();
        c.beginPath(); c.moveTo(r * 0.5, -r * 0.15); c.lineTo(r * 0.5, r * 0.45); c.stroke();
        c.fillStyle = '#fff6e6';
        c.fillRect(-r * 0.75, r * 0.35, r * 0.5, r * 0.35);
        c.fillRect(r * 0.25, r * 0.35, r * 0.5, r * 0.35);
      } else if (kind === 'slow') {
        // hourglass
        c.fillStyle = col;
        c.beginPath();
        c.moveTo(-r * 0.6, -r * 0.7); c.lineTo(r * 0.6, -r * 0.7); c.lineTo(0, 0);
        c.closePath(); c.fill();
        c.beginPath();
        c.moveTo(-r * 0.6, r * 0.7); c.lineTo(r * 0.6, r * 0.7); c.lineTo(0, 0);
        c.closePath(); c.fill();
        c.strokeStyle = '#f3e8ff';
        c.lineWidth = r * 0.14;
        c.beginPath(); c.moveTo(-r * 0.6, -r * 0.7); c.lineTo(r * 0.6, -r * 0.7); c.stroke();
        c.beginPath(); c.moveTo(-r * 0.6, r * 0.7); c.lineTo(r * 0.6, r * 0.7); c.stroke();
      } else if (kind === 'double') {
        // doubler: gold gem diamond with a "x2" badge
        c.fillStyle = col;
        c.save();
        c.rotate(Math.PI / 4);
        c.fillRect(-r * 0.62, -r * 0.62, r * 1.24, r * 1.24);
        c.restore();
        c.fillStyle = '#3a2a00';
        c.font = '900 ' + (r * 0.85) + 'px system-ui, sans-serif';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText('×2', 0, r * 0.05);
      } else {
        // feast: a hungry pellet (open mouth facing right) with an eye
        c.fillStyle = col;
        c.beginPath();
        c.moveTo(0, 0);
        c.arc(0, 0, r * 0.82, Math.PI * 0.22, Math.PI * 1.78);
        c.closePath();
        c.fill();
        c.fillStyle = '#06371c';
        c.beginPath();
        c.arc(-r * 0.12, -r * 0.34, r * 0.12, 0, TAU);
        c.fill();
      }
      powerIcons[kind] = cv;
    }
  }

  /* Called by the UI when the player picks a different skin/level/trail. */
  function refreshSkin() { curSkin = Skins.current(); buildRing(); buildSkinIcon(); }
  function refreshLevel() { curLevel = Levels.current(); curTune = curLevel.tuning || {}; buildRing(); }
  function refreshTrail() { curTrail = Trails.current(); }
  /* Cache the active theme + precompute any derived colors ONCE (so the
   * draw loop never allocates a color string per frame). */
  function applyTheme() {
    curTheme = Themes.current();
    TC = curTheme.c;
    TC.pulserHalo = rgba(TC.pulser, 0.30);
    TC.pulserLine = rgba(TC.pulser, 0.75);
  }
  function refreshTheme() {
    applyTheme();
    buildBackground(); buildRing();
  }

  /* ---------- run lifecycle ---------- */

  /* opts (optional, used by the daily challenge):
   *   rng     — replaces the spawner's randomness for this run
   *   levelId — forces a track shape for this run (selection untouched) */
  function startRun(opts) {
    if (window.Analytics) Analytics.endRun(state === State.OVER ? 'death' : 'restarted', analyticsSummary());
    if (window.RemoteConfig) {
      var tuning = RemoteConfig.forRun(!!(opts && (opts.rng || opts.zen)));
      runConfigRevision = tuning.revision;
      ['baseSpeed', 'maxSpeed', 'rampPerSec', 'gemChance', 'powerChance'].forEach(function (k) { CFG[k] = tuning[k]; });
    }
    deathCause = 'unknown';
    rng = (opts && opts.rng) || Math.random;
    var lvl = (opts && opts.levelId) ? Levels.byId(opts.levelId) : Levels.current();
    if (lvl.id !== curLevel.id) { curLevel = lvl; buildRing(); }
    curTune = curLevel.tuning || {};
    zenMode = !!(opts && opts.zen); // no-fail relax mode (set by main.js)
    time = 0;
    speed = CFG.baseSpeed;
    totalAngle = 0;
    ball.angle = -Math.PI / 2;
    ball.lane = 1;
    ball.off = laneOff;
    ents = [];
    spawnNextAt = 1.0;
    lastSpikeLane = 1;
    lastSpikeAt = -10;
    lastPowerAt = -100;
    shieldOn = false;
    magnetT = 0;
    slowT = 0;
    doubleT = 0;
    feastT = 0;
    stormPhase = 'none';
    stormsRun = 0;
    reportedStorms = 0;
    stormPot = 0;
    pactGate = null;
    relicState = Relics.freshState();
    relicRng = (opts && opts.relicRng) || Math.random;
    pactCount = 0;
    // Forge Seed applies to PERSONAL runs only — never the seeded daily (which
    // never passes one), so the shared challenge stays byte-identical.
    seedRelicId = (opts && opts.seedRelic) || null;
    reportedSouls = 0;
    // Ghost: record THIS run (ball.lane is 1 here) and, on a seeded run, race
    // the supplied tape. Recording/replay are pure timeline ops (no rng/sim).
    recTape = { start: ball.lane, sw: [], end: 0, score: 0 };
    ghostTape = (opts && opts.ghost) ? Ghost.clean(opts.ghost) : null;
    if (!Ghost.isReplayable(ghostTape)) ghostTape = null;
    ghostIdx = 0;
    ghostOff = ghostTape ? laneSign(ghostTape.start) * laneOff : 0;
    ghostPassedFired = false;
    // Warden duels: personal runs only (never the seeded daily, never Zen),
    // so geometry morph + scripted attacks never affect determinism or no-fail.
    wardenState = 'none'; wardenT = 0; wardenIdx = 0; wardenLobes = 3;
    wardenMorph = 0; wardenMorphTarget = 0; wardenMorphPhase = 0;
    wardenAttackT = 0; wardenAttackN = 0; wardensTriggered = 0; wardenSouls = 0;
    wardenAllowed = !(opts && opts.rng) && !zenMode;
    nmSincePhalanx = 0;
    wScale = 1;
    comboN = 0;
    comboT = 0;
    maxCombo = 0;
    scoreBonus = 0;
    tutorial = !Store.getTutorialDone();
    if (window.Analytics) Analytics.beginRun({
      mode: (opts && opts.analyticsMode) || (zenMode ? 'zen' : (opts && opts.rng ? 'seed' : 'personal')),
      track: curLevel.id, config_revision: runConfigRevision, tutorial: tutorial
    });
    if (tutorial) wScale = 0.5; // start slowed; eases up after the first dodge
    if (cb.onTutorial) cb.onTutorial(tutorial);
    runGems = 0;
    bankedGems = 0;
    laneSwitches = 0;
    nearMisses = 0;
    reportedGems = 0;
    reportedNM = 0;
    reportedSec = 0;
    prevBestCache = Store.getBest();
    bestNotified = false;
    runId += 1;          // a fresh run; a revive does NOT change this id
    usedRevive = false;
    invuln = 0;
    shakeT = 0;
    ballSquash = 0;
    ringPulse = 0;
    camKick = 0;
    sphere = 0;
    depthF = 0;
    if (Sound.setIntensity) Sound.setIntensity(0);
    if (cb.onSphere) cb.onSphere(1);
    hitStop = 0;
    trail.length = 0;
    trailAcc = 0;
    bloomAcc = 0;
    pops.length = 0;
    lastShownScore = -1;
    lastShownGems = -1;
    lastShownRate = -1;   // re-announce the rate: the track may have changed
    Particles.clear();
    state = State.PLAYING;
    if (cb.onStorm) cb.onStorm('none'); // clear a banner left by the last run
    if (cb.onPot) cb.onPot(0, false);   // clear the storm-bank pot indicator
    if (cb.onRelicRail) cb.onRelicRail([]); // clear the relic rail
    // Opening Pact: a spawn-free half-loop to draft your starting relic by lane.
    pactGate = openPactGate(true);
    pushHud();
  }

  /* A Pact-Gate floats two relic portals across the lanes (reusing the
   * Storm-Bank gate timing). Offers are drawn from the SEPARATE seeded relic
   * stream with a FIXED draw count, so the daily stays byte-identical. */
  function openPactGate(opening) {
    // The OFFER POOL widens with the gate ORDINAL (pactCount), never the clock,
    // so deeper gates draft rarer relics while the seeded daily stays identical.
    var offers = Relics.drawOffers(relicRng, 2, Relics.poolForGate(pactCount));
    // Forge Seed: bias the OPENING offer to the player's attuned relic (adds no
    // rng draw). Personal runs only — the daily never passes a seed.
    if (opening) offers = Relics.applySeed(offers, seedRelicId);
    pactCount++;
    return {
      born: totalAngle,
      angle: (ball.angle + CFG.spawnLead) % TAU,
      decided: false, scale: 0,
      relics: offers,
      opening: !!opening
    };
  }

  /* Draft the relic the ball's lane chose: apply its fairness-neutral effect,
   * push it onto the rail, fire feedback. A shield-granting relic (Thick Skin,
   * Bulwark, Aegis, Titan) grants a Shield the first time the build gains one. */
  function draftRelic(relic, x, y) {
    if (!relic) return;
    var hadShield = relicState.startShield;
    relic.apply(relicState);
    relicState.held.push(relic.id);
    if (relicState.startShield && !hadShield && !shieldOn) shieldOn = true;
    Particles.burst(x, y, relic.color, 18, { speed: 200, size: 4, life: 0.6 });
    pushPop(x, y, relic.color, ballR * 1.8);
    if (!reduceFlash) { ringPulse = 0.95; camKick = 0.6; }
    Sound.bank(); // a "pact sealed" chime (reuse the bank tone)
    if (cb.onRelic) cb.onRelic({ id: relic.id, name: relic.name, color: relic.color, desc: relic.desc });
    if (cb.onRelicRail) cb.onRelicRail(relicState.held.slice());
  }

  function toMenu() {
    if (window.Analytics) Analytics.endRun(state === State.OVER ? 'death' : 'abandoned', analyticsSummary());
    bankGems(); // backing out mid-run still keeps collected gems
    state = State.MENU;
    ents = [];
    trail.length = 0;
    Particles.clear();
    // Clear leftover HUD banners symmetrically with startRun() (the menu/back/
    // Zen-exit paths can reach here mid-storm or mid-Warden). Today these are
    // masked by the HUD hiding, but resetting them removes that fragile coupling.
    stormPhase = 'none'; stormPot = 0;
    wardenState = 'none'; wardenMorph = 0; wardenMorphTarget = 0;
    if (Sound.setIntensity) Sound.setIntensity(0); // calm the menu (don't keep the dead run's deep mix)
    if (cb.onStorm) cb.onStorm('none');
    if (cb.onPot) cb.onPot(0, false);
    if (cb.onRelicRail) cb.onRelicRail([]);
    // a daily-challenge run may have forced a track: restore the selection
    var sel = Levels.current();
    if (sel.id !== curLevel.id) { curLevel = sel; buildRing(); }
  }

  function onTap() {
    if (state !== State.PLAYING) return;
    ball.lane = ball.lane === 0 ? 1 : 0;
    laneSwitches++;
    // Ghost tape: stamp the lane toggle at the master clock (bounded).
    if (recTape && recTape.sw.length < Ghost.MAX_SWITCHES) recTape.sw.push(totalAngle);
    ballSquash = 0.42; // a snappy stretch along the orbit on the flick
    Sound.tap();
  }

  function pause() {
    if (state !== State.PLAYING) return false;
    // bank collected gems now: a backgrounded WebView process can be
    // killed by Android at any time, and these are already earned
    bankGems();
    if (window.Analytics) Analytics.checkpoint(analyticsSummary());
    state = State.PAUSED;
    return true;
  }

  function resume() {
    if (state === State.PAUSED) state = State.PLAYING;
  }

  /* Rewarded-ad revive: clear every spike, brief invulnerability.
   * Guarded on OVER: the rewarded ad resolves asynchronously, and the
   * player may have already left the panel (back button, MENU, even
   * started a new run) — a late "earned" must never resurrect a dead
   * run from the menu or hijack a fresh one. */
  function revive() {
    if (state !== State.OVER) return;
    if (window.Analytics) Analytics.revive();
    for (var i = ents.length - 1; i >= 0; i--) {
      if (ents[i].type === 'spike' || ents[i].type === 'pulser') {
        var p = entityPos(ents[i]);
        Particles.burst(p.x, p.y, '#ff3355', 6, { speed: 110, size: 3, life: 0.4 });
        ents.splice(i, 1);
      }
    }
    usedRevive = true;
    invuln = CFG.invulnAfterRevive;
    deathTimer = 0;
    state = State.PLAYING;
    pushHud();
  }

  function canRevive() { return !usedRevive; }

  /* ---------- spawning ---------- */

  function occupied(angle, lane, win) {
    for (var i = 0; i < ents.length; i++) {
      if (ents[i].lane === lane && angDist(ents[i].angle, angle) < win) return true;
    }
    return false;
  }

  function spawn() {
    /* Determinism: every spawn consumes the SAME number of rng()
     * draws no matter which gates pass. Frame timing differs across
     * devices (60/90/120Hz), so `time` at a given spawn differs by
     * milliseconds — if a draw sat behind a time gate, two devices
     * could disagree on whether it happens and permanently offset
     * the seeded daily-challenge stream. With the draws hoisted the
     * stream NEVER offsets; a borderline gate can still flip one
     * entity's type (plus its lane-forced neighbor) right at the
     * boundary, which is the accepted residual — verified: 60 vs
     * 90fps runs differ in at most ~2 of 40 entities, all local. */
    var gemRoll = rng(), laneRoll = rng(), powerRoll = rng(),
        magnetRoll = rng(), kindRoll = rng(), pulserRoll = rng(),
        phaseRoll = rng(), gapRoll = rng();

    var angle = (ball.angle + CFG.spawnLead) % TAU;
    var isGem = gemRoll < CFG.gemChance + tune('gemChance');
    var lane = laneRoll < 0.5 ? 0 : 1;

    /* Rarely a gem slot becomes a power-up instead — same fair lanes,
     * same growth/expiry, just a different payload on pickup. Track
     * personality can bias the roll (Bloom favors magnets). */
    var kind = null;
    if (isGem && totalAngle - lastPowerAt > CFG.powerMinGap &&
        powerRoll < CFG.powerChance + tune('powerBias')) {
      // A track can bias the kind by reusing magnetRoll (NO extra rng draw, so
      // the 8-draw spawn contract holds): magnet first, then feast, else the
      // normal weighted pick. magnetBias + feastBias never overlap (<= 1).
      var mb = tune('magnetBias');
      kind = (magnetRoll < mb) ? 'magnet'
           : (magnetRoll < mb + tune('feastBias')) ? 'feast'
           : pickPowerKind(kindRoll);
    }

    var type = kind ? 'power' : (isGem ? 'gem' : 'spike');

    if (!isGem) {
      /* Fairness: if the previous obstacle is recent and on the other
       * lane, keep this one on the same lane so a path always exists.
       * Pulsers share this bookkeeping and count as ALWAYS blocking,
       * so the escape lane never depends on their blink phase. */
      if (lane !== lastSpikeLane && totalAngle - lastSpikeAt < CFG.gapMinSwitch) {
        lane = lastSpikeLane;
      }
      lastSpikeLane = lane;
      lastSpikeAt = totalAngle;
      /* Keep spikes off sharp corners (polygon levels) where a flat
       * base can't sit flush — nudge them onto the nearest edge. */
      for (var k2 = 0; k2 < 6 && turnAngle(angle) > 0.3; k2++) {
        angle = (angle + 0.13) % TAU;
      }
      /* Pulsers (the armed/disarmed "disappearing" spikes) were removed — every
       * obstacle is now a plain spike. pulserRoll is still drawn above to keep
       * the 8-draw-per-spawn determinism contract (and the seeded daily) intact. */
    }

    if (!occupied(angle, lane, 0.3)) {
      // one object shape for every entity keeps the engine JIT-friendly
      ents.push({
        type: type, kind: kind, lane: lane, angle: angle, born: totalAngle, scale: 0,
        pulled: false, sx: 0, sy: 0, px: 0, py: 0, pp: 0, minD: 1e9, nm: false,
        phase: phaseRoll * (CFG.pulserOn + CFG.pulserOff), // pulser blink offset
        /* armedPrev starts TRUE: the arm tick means "this pulser just
         * became lethal near you" — a pulser that was already armed
         * when it entered the window must stay silent. */
        armedPrev: true
      });
      if (kind) lastPowerAt = totalAngle;
    }

    var k = Math.min(1, time / CFG.gapRampTime);
    var gapMax = CFG.gapMaxStart + (CFG.gapMaxEnd - CFG.gapMaxStart) * k;
    // storm burst: denser, but only by squeezing the UPPER bound —
    // gapMin/gapMinSwitch (the fairness floor) are never touched
    if (stormPhase === 'burst') {
      gapMax = Math.max(CFG.gapMin + 0.1, gapMax * CFG.stormGapScale);
    }
    spawnNextAt = totalAngle + CFG.gapMin + gapRoll * Math.max(0.1, gapMax - CFG.gapMin);
  }

  function entityPos(e) {
    var r = laneRadiusAt(e.lane, e.angle);
    return { x: cx + Math.cos(e.angle) * r, y: cy + Math.sin(e.angle) * r };
  }

  /* ---------- update ---------- */

  function update(dt) {
    if (state === State.PAUSED) return;
    // hit-stop: a beat of frozen impact before the death animation
    // (skipped entirely under Reduce motion)
    if (hitStop > 0) { hitStop -= dt; return; }

    Particles.update(dt);
    for (var pi = pops.length - 1; pi >= 0; pi--) {
      pops[pi].t += dt;
      if (pops[pi].t >= pops[pi].life) pops.splice(pi, 1);
    }
    if (shakeT > 0) shakeT -= dt;
    // juice decays toward rest every frame (time-based, framerate independent)
    if (ballSquash) { ballSquash -= ballSquash * Math.min(1, dt * 11); if (Math.abs(ballSquash) < 0.002) ballSquash = 0; }
    if (ringPulse > 0) { ringPulse -= ringPulse * Math.min(1, dt * 6); if (ringPulse < 0.004) ringPulse = 0; }
    if (camKick > 0) { camKick -= camKick * Math.min(1, dt * 7); if (camKick < 0.004) camKick = 0; }
    worldClock += dt; // always-advancing render clock (parallax drift, menu too)

    if (state === State.MENU) {
      // attract mode: ball idles around the track behind the menu
      ball.angle = (ball.angle + CFG.baseSpeed * 0.5 * dt) % TAU;
      ball.off += (laneSign(ball.lane) * laneOff - ball.off) * Math.min(1, dt * CFG.laneLerp);
      pushTrail();
      emitTrail(dt); // the selected cosmetic trail previews on the menu
      return;
    }

    if (state === State.DYING) {
      deathTimer -= dt;
      if (deathTimer <= 0) finalizeGameOver();
      return;
    }

    if (state !== State.PLAYING) return;

    /* Slow-mo scales a single world-time multiplier. Everything paced
     * by `time` or `totalAngle` (difficulty ramp, spawning, score)
     * slows with it, so patterns stay exactly as fair as at full
     * speed (constraint: no impossible situations). Eases back. */
    if (slowT > 0) slowT -= dt;
    if (magnetT > 0) magnetT -= dt;
    if (doubleT > 0) doubleT -= dt;
    if (feastT > 0) feastT -= dt;
    wScale += ((tutorial ? 0.5 : slowT > 0 ? CFG.slowScale : 1) - wScale) * Math.min(1, dt * 3);
    var wdt = dt * wScale;

    // the combo dies a few seconds after the last near miss
    if (comboT > 0) {
      comboT -= dt;
      if (comboT <= 0) comboN = 0;
    }

    // clock & difficulty: `time` is real survival (also the score).
    time += wdt;
    speed = Math.min(CFG.maxSpeed, CFG.baseSpeed + CFG.rampPerSec * time);
    if (invuln > 0) invuln -= wdt;

    // Descent depth (derived from `time` only -> slow-mo-scaled + daily-safe).
    depthF = Math.min(1, time / (SPHERE_SECONDS * SPHERE_MAX));
    var s = Math.min(SPHERE_MAX, Math.floor(time / SPHERE_SECONDS));
    if (s !== sphere) { sphere = s; onSphereCross(s); }

    /* In-run feedback. "BEST!" fires the moment the live score passes
     * the run-start best (same time+scoreBonus formula the game over
     * uses); suppressed while the best is tiny so brand-new players
     * aren't flashed every other run. */
    if (!bestNotified && prevBestCache >= 5 && time + scoreBonus > prevBestCache) {
      bestNotified = true;
      if (cb.onBestPass) cb.onBestPass();
    }

    /* Storm waves: the phase derives from the run clock, so we only
     * react to transitions (sound + banner + survived counter). The
     * counter persists via stormsDelta in the run summary — never a
     * localStorage write mid-run. */
    // Storms are SUPPRESSED for the whole Warden phase (frozen at 'none'); they
    // resync to the run clock once the duel ends, so a Warden is never muddied
    // by a storm and the duel's only threats are its scripted attacks.
    if (!wardenActive()) {
      var sp = stormPhaseAt(time);
      if (sp !== stormPhase) {
        if (sp === 'warn') Sound.stormWarn();
        else if (sp === 'burst') Sound.stormHit();
        else if (sp === 'calm' && stormPhase === 'burst') {
          stormsRun++;   // weathered it
          vacuumGems();  // Aftershock Vacuum: sweep up every gem on the track
          // A storm gem pot opens (+ Stormcaller relic bonus) and a PACT-GATE
          // floats in the calm: pick a relic by lane; the pot banks safely at
          // the gate. (The v1.2 bank/ride gamble is folded into the relic draft.)
          stormPot = CFG.stormBankBase + Math.min(70, relicState.stormGems); // capped (re-draft runaway)
          pactGate = openPactGate(false);
          if (cb.onPot) cb.onPot(stormPot, true);
        }
        stormPhase = sp;
        if (cb.onStorm) cb.onStorm(sp);
      }
    }

    // Warden duel: advance the boss phase + scripted attacks, then ease the
    // track morph toward its target (ease always runs so it decays on victory/death).
    updateWarden(dt);
    if (wardenMorph !== wardenMorphTarget) {
      wardenMorph += (wardenMorphTarget - wardenMorph) * Math.min(1, dt * 3);
      if (Math.abs(wardenMorph - wardenMorphTarget) < 0.002) wardenMorph = wardenMorphTarget;
    }

    // ball motion (clockwise: +angle with y-down canvas coords)
    var step = speed * wdt;
    ball.angle = (ball.angle + step) % TAU;
    totalAngle += step;
    ball.off += (laneSign(ball.lane) * laneOff - ball.off) * Math.min(1, dt * CFG.laneLerp);
    pushTrail();
    emitTrail(dt);

    // Ghost racer: advance the lane cursor (monotonic timeline), ease its lane
    // offset like the ball, and fire ONE beat the moment you outlast your best.
    if (ghostTape) {
      // STRICT '<': the live ball flips at onTap (before this frame's motion),
      // so the recorded switch angle == the END of the previous frame. Strict
      // '<' makes the ghost toggle on the SAME frame the ball did, not one early.
      while (ghostIdx < ghostTape.sw.length && ghostTape.sw[ghostIdx] < totalAngle) ghostIdx++;
      var gLane = ghostTape.start ^ (ghostIdx & 1);
      ghostOff += (laneSign(gLane) * laneOff - ghostOff) * Math.min(1, dt * CFG.laneLerp);
      if (!ghostPassedFired && totalAngle > ghostTape.end) {
        ghostPassedFired = true;
        if (cb.onGhostPassed) cb.onGhostPassed();
      }
    }

    // Hadal "Bloom": during a storm burst the abyss fills with rising
    // bioluminescent plankton (mint + lure-red). Capped under the pool
    // limit so the death/celebration reserve is never starved.
    if (curTheme.stormStyle === 'bloom' && stormPhase === 'burst') {
      bloomAcc += dt * 45;
      while (bloomAcc >= 1) {
        bloomAcc -= 1;
        if (Particles.count() < 170) {
          Particles.burst(Math.random() * w, h + 4,
            Math.random() < 0.6 ? TC.gem : TC.spikeTip, 1,
            { speed: 45, size: 2.5, life: 1.7, gravity: -26 });
        }
      }
    }

    // spawning is held during the post-storm calm, while a Pact-Gate is open,
    // AND for the whole Warden duel (the duel's only threats are its scripted
    // single-lane attacks, so a draft/boss beat is never a death trap).
    if (totalAngle >= spawnNextAt && stormPhase !== 'calm' && !pactGate && !wardenActive()) spawn();

    // entities: grow in, expire behind the ball, collide
    var br = ballRadius();
    var bx = cx + Math.cos(ball.angle) * br;
    var by = cy + Math.sin(ball.angle) * br;
    var expireAt = CFG.spawnLead + 1.3;

    // Storm Bank gate: grows in, then locks the BANK/RIDE choice the
    // instant the ball reaches its angle (spawnLead of travel after it
    // opened — exactly the entity-arrival timing). Inner lane banks the
    // pot into runGems (safe forever); outer lane rides it to the next
    // storm. The pot lives outside runGems until this bank, so a ride
    // lost to death never costs a collected gem.
    // Pact-Gate: grows in, then locks the relic draft the instant the ball
    // reaches the gate angle (spawnLead of travel after it opened — the same
    // entity-arrival timing). The chosen lane's relic is drafted, and any
    // storm pot is banked into runGems (safe forever).
    if (pactGate && !pactGate.decided) {
      pactGate.scale = Math.min(1, pactGate.scale + dt * 4);
      if (totalAngle - pactGate.born >= CFG.spawnLead) {
        pactGate.decided = true;
        draftRelic(pactGate.relics[ball.lane === 0 ? 0 : 1], bx, by);
        if (stormPot > 0) {
          runGems += stormPot;
          stormPot = 0;
          if (cb.onPot) cb.onPot(0, false);
        }
        pactGate = null;
        pushHud();
      }
    }

    for (var i = ents.length - 1; i >= 0; i--) {
      var e = ents[i];
      e.scale = Math.min(1, e.scale + dt * 4);
      var travel = totalAngle - e.born;
      if (travel > expireAt && !e.pulled) { ents.splice(i, 1); continue; }

      /* Near miss: once a spike has passed behind the ball, check how
       * close the pass got. Tighter than 1.8 ball radii (but outside
       * the 0.9 kill ring, or we'd be dead) counts. Passes made while
       * invulnerable (or past a disarmed pulser) never tracked minD,
       * so they can't trigger this. */
      if ((e.type === 'spike' || e.type === 'pulser') && !e.nm && travel >= CFG.spawnLead + 0.7) {
        e.nm = true;
        if (e.minD < ballR * 1.8) nearMiss();
        // tutorial: any spike survived counts as the first dodge —
        // drop the hint and let the world speed ease back up
        if (tutorial) {
          tutorial = false;
          if (cb.onTutorial) cb.onTutorial(false);
        }
      }

      /* Magnet: gems anywhere inside the radius detach from their
       * lane and fly to the ball over a fixed ~0.35s (interpolating
       * from the pull point to the MOVING ball, so they always catch
       * it — a plain chase-lerp never wins against the ball's speed).
       * Once pulled they finish the flight even if the magnet ends. */
      if (e.type === 'gem' && e.scale > 0.9) {
        if (!e.pulled && magnetT > 0) {
          var mp = entityPos(e);
          var mdx = mp.x - bx, mdy = mp.y - by;
          if (Math.sqrt(mdx * mdx + mdy * mdy) < ringR * CFG.magnetRadius) {
            e.pulled = true;
            e.sx = mp.x; e.sy = mp.y;
            e.px = mp.x; e.py = mp.y;
          }
        }
        if (e.pulled) {
          e.pp = Math.min(1, e.pp + dt * 3);
          var kk = e.pp * e.pp * (3 - 2 * e.pp); // smoothstep ease
          e.px = e.sx + (bx - e.sx) * kk;
          e.py = e.sy + (by - e.sy) * kk;
          var pdx = e.px - bx, pdy = e.py - by;
          if (e.pp >= 1 || Math.sqrt(pdx * pdx + pdy * pdy) < ballR * 1.6) {
            collectGem(i, e.px, e.py);
          }
          continue;
        }
      }

      // collision only near the ball, once fully grown
      if (travel > CFG.spawnLead - 0.7 && travel < CFG.spawnLead + 0.7 && e.scale > 0.9) {
        if (e.type === 'gem') {
          var p = entityPos(e);
          var dx = p.x - bx, dy = p.y - by;
          if (Math.sqrt(dx * dx + dy * dy) < ballR + gemR * 1.25) {
            collectGem(i, p.x, p.y);
          }
        } else if (e.type === 'power') {
          var pp = entityPos(e);
          var qdx = pp.x - bx, qdy = pp.y - by;
          if (Math.sqrt(qdx * qdx + qdy * qdy) < ballR + gemR * 1.4) {
            ents.splice(i, 1);
            applyPower(e.kind, pp.x, pp.y);
          }
        } else {
          // spike or pulser — a pulser only bites while armed
          var armed = e.type !== 'pulser' || pulserArmed(e);
          if (e.type === 'pulser') {
            if (armed && !e.armedPrev) Sound.pulserArm(); // arms near the ball: tick
            e.armedPrev = armed;
          }
          // Feast overrides invulnerability: during a feast the ball
          // EATS armed obstacles on contact instead of dying to them.
          if (armed && (feastT > 0 || invuln <= 0)) {
            var sd = spikeDist(e, bx, by);
            if (feastT > 0) {
              // ram it to eat it — no death, and no near-miss bookkeeping
              // (during a feast you're hunting spikes, not dodging them)
              if (sd < ballR * 0.9) {
                var fp = entityPos(e);
                ents.splice(i, 1);
                runGems += CFG.feastGems;
                Particles.burst(fp.x, fp.y, POWER_COLOR.feast, 14, { speed: 170, size: 3.5, life: 0.5 });
                Sound.feastEat();
                pushHud();
                continue;
              }
            } else {
              if (sd < e.minD) e.minD = sd; // closest ARMED pass, for the near-miss check
              if (sd < ballR * 0.9) { // slightly inside the drawn ball: feels fair
                if (shieldOn) {
                  // the shield eats the hit: pop the obstacle, brief safety
                  shieldOn = false;
                  invuln = CFG.shieldInvuln;
                  var sp2 = entityPos(e);
                  ents.splice(i, 1);
                  Particles.burst(sp2.x, sp2.y, '#4da6ff', 16, { speed: 200, size: 4, life: 0.55 });
                  Sound.shieldHit();
                  continue;
                }
                if (zenMode) {
                  // Zen Drift: no failure — the hit pops the spike, grants a
                  // beat of grace, and the drift continues. No death, no economy.
                  invuln = CFG.shieldInvuln;
                  var zp = entityPos(e);
                  ents.splice(i, 1);
                  if (!reduceMotion) shakeT = Math.max(shakeT, shakeDur * 0.5);
                  Particles.burst(zp.x, zp.y, '#c9a8ff', 12, { speed: 150, size: 3, life: 0.45 });
                  Sound.shieldHit();
                  continue;
                }
                lastDeath = { entAngle: e.angle, entLane: e.lane, type: e.type, travel: travel,
                              dist: sd, ballAngle: ball.angle, ballOff: ball.off, ballR: ballR, br: br };
                die(bx, by, e.type);
                break;
              }
            }
          }
        }
      }
    }

    pushHud();
  }

  /* A spike slid past within the margin: bonus points scale with the
   * combo (+1, +2, +3... capped at +5 so long chains can't snowball
   * the score past what surviving is worth), tiny spark, rising tick. */
  function nearMiss() {
    nearMisses++;
    comboN++;
    if (comboN > maxCombo) maxCombo = comboN;
    comboT = Math.max(0.8, 3.5 + relicState.comboHold); // Momentum +; cursed pacts - (floored)
    scoreBonus += Math.min(comboN, 5);
    if (relicState.nearGem) runGems += Math.min(8, relicState.nearGem); // Gem Shrapnel (capped: re-draft runaway)
    // Phalanx: a shield reforms every 8 near-misses if you have none
    if (relicState.phalanx > 0) {
      nmSincePhalanx++;
      if (nmSincePhalanx >= 8 && !shieldOn) {
        shieldOn = true; nmSincePhalanx = 0;
        if (ringPulse < 0.6) ringPulse = 0.6;
      }
    }
    // juice: a squash pulse, and the ring + camera react harder as the combo climbs
    ballSquash = -0.22;
    var rp = 0.3 + Math.min(comboN, 5) * 0.08; if (ringPulse < rp) ringPulse = rp;
    if (camKick < 0.3) camKick = 0.3;
    var r = ballRadius();
    Particles.burst(cx + Math.cos(ball.angle) * r, cy + Math.sin(ball.angle) * r,
                    TC.spark, 5, { speed: 130, size: 2.5, life: 0.35 });
    Sound.nearMiss(comboN);
    if (cb.onNearMiss) cb.onNearMiss(comboN);
    pushHud();
  }

  /* Gems are NOT persisted here — a synchronous localStorage write per
   * pickup janks weak WebViews. They accumulate in runGems and are
   * banked once in finalizeGameOver/pause/toMenu (see bankGems).
   * Value: track multiplier (+ personality bonus), then x2 if the
   * Doubler OR a storm burst is live — they do NOT stack (a Tri x7
   * gem at x4 would blow past the economy guardrail). */
  /* What ONE gem is worth right now, before any transient multiplier.
   *
   * Single source of truth for the payout: collectGem pays it and pushHud
   * reports it to the HUD badge, so the number on screen can never drift
   * from the number credited. It used to be computed only here, which let
   * the badge advertise a track's ×20 while a hidden bonus or a drafted
   * relic quietly paid 21.
   *
   * Flat adds first (Prospector/Quartz/Hoard…); a cursed pact can drive the
   * base negative, so floor at 1 — a collected gem is always worth
   * something. Relic gemAdd is CAPPED: a relic can be re-offered across
   * gates, so an uncapped += would let a long run stack the same relic into
   * unbounded per-pickup gems. The cap (16) still allows a full
   * single-of-each gem build; it only kills duplication runaway. */
  function gemBase() {
    return Math.max(1, curLevel.mult + tune('gemBonus') + Math.min(16, relicState.gemAdd));
  }

  function collectGem(i, x, y) {
    ents.splice(i, 1);
    var doubled = doubleT > 0 || stormPhase === 'burst';
    var pay = gemBase();
    // Gem multipliers do NOT stack — the strongest wins. The storm/Doubler x2
    // and relic gem-mults (Midas x1.5, Philosopher x2, Hunger x2.5) all collapse
    // to a single MAX factor, keeping a high-mult gem inside the same economy
    // guardrail the Doubler already sets.
    var mult = doubled ? 2 : 1;
    if (relicState.gemMult > mult) mult = relicState.gemMult;
    var boosted = mult > 1;
    if (boosted) {
      pay = Math.round(pay * mult);
    }
    if (!zenMode) runGems += pay;                    // Zen earns nothing — pure juice
    ballSquash = -0.30;                              // bounce on pickup
    if (ringPulse < 0.42) ringPulse = 0.42;
    if (camKick < 0.22) camKick = 0.22;
    Particles.burst(x, y, boosted ? '#ffd24a' : TC.gem, 12, { speed: 150, size: 3.5, life: 0.5 });
    pushPop(x, y, boosted ? '#ffd24a' : TC.gem, ballR * 1.3, zenMode ? null : '+' + pay);
    Sound.gem();
  }

  /* Aftershock Vacuum: weathering a storm burst magnet-pulls every gem
   * still on the track into the ball. Each un-pulled gem is flagged with
   * the same flight state the magnet uses, so update()'s pull loop
   * carries it home (and collectGem banks it) over the next ~0.35s.
   * Pure reward — no rng draws and no clock change, so the seeded daily
   * stays byte-identical. (Pulled gems are also exempt from the expiry
   * sweep, so none are lost in flight.) */
  function vacuumGems() {
    var swept = false;
    for (var i = 0; i < ents.length; i++) {
      var e = ents[i];
      if (e.type === 'gem' && !e.pulled) {
        var p = entityPos(e);
        e.pulled = true;
        e.sx = p.x; e.sy = p.y;
        e.px = p.x; e.py = p.y;
        e.pp = 0;
        swept = true;
      }
    }
    if (swept) Sound.vacuum();
  }

  /* Cosmetic trail: a steady drip of particles behind the ball. The
   * accumulator keeps emission framerate-independent, and the pool
   * reserve means a busy moment (death burst, celebration) is never
   * starved by cosmetics. */
  function emitTrail(dt) {
    if (!curTrail || !curTrail.emit) return;
    trailAcc += dt * curTrail.emit.rate;
    if (trailAcc < 1) return;
    var r = ballRadius();
    var x = cx + Math.cos(ball.angle) * r;
    var y = cy + Math.sin(ball.angle) * r;
    while (trailAcc >= 1) {
      trailAcc -= 1;
      Particles.emit(x, y, curTrail.emit);
    }
  }

  /* Persist any not-yet-banked run gems. Called from finalizeGameOver
   * (revive-safe: only the delta since the last bank), from pause()
   * (Android can kill a backgrounded process) and from toMenu (backing
   * out of a run keeps them). The lifetime gems-collected stat moves
   * here too, so it can never diverge from what was actually banked. */
  function bankGems() {
    if (zenMode) return; // Zen Drift earns nothing — it never touches the wallet
    if (runGems > bankedGems) {
      Store.addGems(runGems - bankedGems);
      Store.setGemsTotal(Store.getGemsTotal() + (runGems - bankedGems));
      bankedGems = runGems;
    }
  }

  function applyPower(kind, x, y) {
    // Relic duration bonuses (Lodestone/Glacier/Avalanche/Gourmand/Overcharge);
    // floored at 1s so a cursed pact's subtraction can never zero a power-up.
    if (kind === 'shield') shieldOn = true;
    else if (kind === 'magnet') magnetT = Math.max(1, CFG.magnetTime + relicState.magnetDur);
    else if (kind === 'slow') slowT = Math.max(1, CFG.slowTime + relicState.slowDur);
    else if (kind === 'feast') feastT = Math.max(1, CFG.feastTime + relicState.feastDur);
    else doubleT = Math.max(1, CFG.doubleTime + relicState.doubleDur);
    ballSquash = -0.34;
    if (ringPulse < 0.78) ringPulse = 0.78;          // big ring flare on a power-up
    if (camKick < 0.5) camKick = 0.5;
    Particles.burst(x, y, POWER_COLOR[kind], 14, { speed: 180, size: 4, life: 0.55 });
    pushPop(x, y, POWER_COLOR[kind], ballR * 1.7);
    Sound.power(kind);
    if (cb.onPower) cb.onPower(kind);
  }

  /* Crossing into a deeper Sphere: a ring flare + the music deepens a tier
   * (swaps on the next bar boundary) + the HUD readout updates. Pure feel —
   * the gem-multiplier/relic-tier ramp lands in P1.2. */
  function onSphereCross(s) {
    if (!reduceFlash) { ringPulse = 0.95; camKick = 0.6; }
    if (Sound.setIntensity) Sound.setIntensity(s);
    if (cb.onSphere) cb.onSphere(s + 1); // 1-based for display (Sphere I..VII)
    // A Warden rises at Sphere IV (s=3) and VI (s=5) — personal runs only.
    if (wardenAllowed && (s === 3 || s === 5) && wardenState === 'none') startWarden();
  }

  /* ---------- Warden duels (P2.1) ---------- */

  function startWarden() {
    var w = Wardens.byIndex(wardensTriggered);
    wardenIdx = wardensTriggered;
    wardenLobes = w.lobes;
    wardensTriggered++;
    wardenState = 'telegraph';
    wardenT = CFG.wardenTelegraph;
    wardenMorphTarget = 1;
    wardenAttackN = 0;
    wardenAttackT = CFG.wardenFirstAttack;
    lastWardenPct = -1;
    // Clear in-flight spikes + any storm so the duel starts clean and fair;
    // spawns + storms stay suppressed for its whole duration (wardenActive()).
    for (var i = ents.length - 1; i >= 0; i--) {
      if (ents[i].type === 'spike' || ents[i].type === 'pulser') ents.splice(i, 1);
    }
    if (stormPhase !== 'none') { stormPhase = 'none'; if (cb.onStorm) cb.onStorm('none'); }
    if (stormPot > 0) { stormPot = 0; if (cb.onPot) cb.onPot(0, false); }
    feastT = 0; // a live Feast must not turn the boss's attacks into edible gems
    if (!reduceFlash) { camKick = 0.9; ringPulse = 1.0; }
    Sound.stormHit(); // a dramatic rising sting (reuse)
    if (cb.onWarden) cb.onWarden({ name: w.name, color: w.color, dur: CFG.wardenTelegraph + w.dur });
  }

  /* Drive the Warden phase: morph target, scripted single-lane attacks, and the
   * transition telegraph -> duel -> defeat. (Morph EASING happens in update().) */
  function updateWarden(dt) {
    if (wardenState === 'none') return;
    var w = Wardens.byIndex(wardenIdx);
    wardenMorphPhase += dt * CFG.wardenWrithe;

    // Engine-driven timer bar: fraction of the whole encounter remaining, fired
    // only when the integer percent changes (~100 cheap DOM writes). Because it
    // rides the run clock, it FREEZES on pause (update() doesn't run) instead of
    // the CSS wall-clock animation that used to drain while the duel was frozen.
    var total = CFG.wardenTelegraph + w.dur;
    var remaining = (wardenState === 'telegraph') ? (wardenT + w.dur) : wardenT;
    var pct = Math.max(0, Math.min(100, Math.round(remaining / total * 100)));
    if (pct !== lastWardenPct) { lastWardenPct = pct; if (cb.onWardenTick) cb.onWardenTick(pct); }

    if (wardenState === 'telegraph') {
      wardenT -= dt;
      if (wardenT <= 0) { wardenState = 'duel'; wardenT = w.dur; }
      return;
    }

    // duel
    wardenT -= dt;
    // ease the morph out over the final beat so the world is calm on victory
    wardenMorphTarget = wardenT < 1.2 ? Math.max(0, wardenT / 1.2) : 1;
    // scripted, telegraphed, single-lane attacks (stop in the final second)
    wardenAttackT -= dt;
    if (wardenAttackT <= 0 && wardenT > 1.0) {
      wardenAttackT = w.attackEvery;
      spawnWardenAttack(Wardens.attackLane(wardenAttackN));
      wardenAttackN++;
    }
    if (wardenT <= 0) endWarden(true);
  }

  /* A scripted bite: a normal spike entity on ONE lane, telegraphed a full
   * spawnLead ahead (same reaction window as a real spike). No rng. */
  function spawnWardenAttack(lane) {
    ents.push({
      type: 'spike', kind: null, lane: lane, angle: (ball.angle + CFG.spawnLead) % TAU,
      born: totalAngle, scale: 0, pulled: false, sx: 0, sy: 0, px: 0, py: 0, pp: 0,
      minD: 1e9, nm: false, phase: 0, armedPrev: true, warden: true
    });
  }

  function endWarden(survived) {
    wardenState = 'none';
    wardenT = 0;
    wardenMorphTarget = 0; // eases out in update()
    if (survived) {
      wardenSouls += CFG.wardenSoulReward; // folded into the depth Souls payout at finalize
      Store.setWardensFelled(Store.getWardensFelled() + 1); // lifetime stat (once per duel, not finalize)
      if (!shieldOn) shieldOn = true;      // spoils: a fresh shield
      if (!reduceFlash) { ringPulse = 1.0; camKick = 0.8; }
      Sound.newBest();                     // a triumphant sting
    }
    if (cb.onWardenEnd) cb.onWardenEnd(!!survived);
  }

  function pushTrail() {
    // Record one point EVERY frame (the original behaviour): a dense FIFO of
    // the last 14 ball positions whose discs overlap into a smooth smear.
    var r = ballRadius();
    trail.push({ x: cx + Math.cos(ball.angle) * r, y: cy + Math.sin(ball.angle) * r });
    if (trail.length > 14) trail.shift();
  }

  /* Universal juice: an expanding-and-fading ring (and optional floating
   * label) at a pickup/event point. Tiny fixed pool, no per-frame alloc
   * beyond the push; one stroked arc each in render. */
  function pushPop(x, y, color, r, text) {
    if (pops.length > 16) pops.shift();
    pops.push({ x: x, y: y, t: 0, life: 0.45, r: r, color: color, text: text || null });
  }

  function drawPops() {
    for (var i = 0; i < pops.length; i++) {
      var p = pops[i], k = p.t / p.life;
      ctx.globalAlpha = (1 - k) * 0.8;
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 2 * (1 - k) + 0.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * (0.3 + k * 1.1), 0, TAU);
      ctx.stroke();
      if (p.text) {
        ctx.globalAlpha = 1 - k;
        ctx.fillStyle = p.color;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = popFont; // cached in resize() — no per-frame string build
        ctx.fillText(p.text, p.x, p.y - p.r - k * ballR * 1.6);
      }
    }
    ctx.globalAlpha = 1;
  }

  function pushHud() {
    var s = Math.floor(time) + scoreBonus;
    if (s !== lastShownScore) { lastShownScore = s; if (cb.onScore) cb.onScore(s); }
    if (runGems !== lastShownGems) { lastShownGems = runGems; if (cb.onGems) cb.onGems(runGems); }
    // the badge follows the live payout, so drafting a gem relic updates it
    // instead of leaving the track's opening rate on screen all run
    var rate = gemBase();
    if (rate !== lastShownRate) { lastShownRate = rate; if (cb.onRate) cb.onRate(rate); }
  }

  function die(bx, by, cause) {
    deathCause = cause || 'unknown';
    state = State.DYING;
    deathTimer = CFG.deathAnim;
    deathX = bx;
    deathY = by;
    // dying mid-duel ends the Warden (clears its banner). The morph-ease in
    // update() won't run outside PLAYING, yet render() draws the morphed ring
    // whenever wardenMorph>0 — so SNAP it to 0 here, or a frozen morph would
    // show behind the game-over panel.
    if (wardenActive()) { wardenState = 'none'; if (cb.onWardenEnd) cb.onWardenEnd(false); }
    wardenMorph = 0; wardenMorphTarget = 0;
    // impact juice: a beat of hit-stop + shake (both honor Reduce motion)
    if (!reduceMotion) {
      hitStop = CFG.hitStopTime;
      shakeT = shakeDur;
    }
    comboN = 0;
    comboT = 0;
    trail.length = 0;
    Particles.burst(bx, by, curSkin.color, 26, { speed: 270, size: 4.5, life: 0.7 });
    Particles.burst(bx, by, TC.spark, 8, { speed: 180, size: 3, life: 0.45 });
    Sound.death();
    if (cb.onDeath) cb.onDeath(); // haptics live in main.js
  }

  function finalizeGameOver() {
    state = State.OVER;
    bankGems(); // persist this run's gems (once per game over, not per pickup)
    if (window.Analytics) Analytics.death(analyticsSummary());
    if (!Store.getTutorialDone()) Store.setTutorialDone(true); // one run done: tutorial never again
    // SCORE = survival seconds + near-miss bonus POINTS (the headline number).
    // SECONDS = pure survival time, the basis for time-based unlocks,
    // survival achievements and the survival leaderboard. They are tracked as
    // SEPARATE bests so points can never buy a seconds-gated reward.
    var secs = Math.floor(time);                 // runSeconds
    var pts = scoreBonus;                         // runPoints (near-miss bonus)
    var total = time + scoreBonus;                // runScore (hybrid)
    var prevBest = Store.getBest();
    var prevBestSec = Store.getBestSeconds();
    var isNewBest = total > prevBest && Math.floor(total) >= 1;
    if (total > prevBest) Store.setBest(total);
    if (secs > prevBestSec) Store.setBestSeconds(secs);
    if (pts > Store.getBestPoints()) Store.setBestPoints(pts);

    /* Souls: the Descent pays a SECOND currency from depth — triangular over
     * Spheres crossed, plus one per relic drafted. Funds the Forge only; the
     * gem economy is untouched. Revive double-finalizes, so credit only the
     * delta past the depth already paid (reportedSouls watermark). */
    var runSouls = (sphere * (sphere + 1)) / 2 + relicState.held.length + wardenSouls;
    var soulsDelta = Math.max(0, runSouls - reportedSouls);
    if (soulsDelta > 0) {
      Store.addSouls(soulsDelta);
      Store.setSoulsTotal(Store.getSoulsTotal() + soulsDelta);
      reportedSouls = runSouls;
    }
    var deepest = sphere + 1;                       // 1-based display depth (Sphere I..VII)
    if (deepest > Store.getDeepestSphere()) Store.setDeepestSphere(deepest);
    // Codex: union the relics drafted this run (idempotent; revive-safe).
    for (var ci = 0; ci < relicState.held.length; ci++) Store.addRelicSeen(relicState.held[ci]);

    // Ghost: stamp this run's tape with where it ended + its score, so the
    // glue can keep the best tape per seed (the daily, today). A revive
    // re-finalizes; the end/score reflect the FINAL death each time.
    if (recTape) { recTape.end = totalAngle; recTape.score = Math.floor(total); }
    var ghostOut = recTape
      ? { start: recTape.start, sw: recTape.sw.slice(), end: recTape.end, score: recTape.score }
      : null;

    if (cb.onGameOver) {
      cb.onGameOver({
        runId: runId,                                 // stable per-run id (revive keeps it)
        outcome: usedRevive ? 'death-revived' : 'death',
        score: Math.floor(total),
        best: Math.floor(Math.max(prevBest, total)),  // best SCORE (hybrid)
        bestSeconds: Math.max(prevBestSec, secs),     // best pure survival time
        runSeconds: secs,
        runPoints: pts,
        isNewBest: isNewBest,
        runGems: runGems,
        totalGems: Store.getGems(),
        canRevive: canRevive(),
        // Run summary for missions (consumed in main.js). A revived
        // run finalizes twice, so cumulative stats go out as deltas
        // (gemsDelta) or are suppressed on the second pass (revived).
        level: curLevel.id,
        seconds: Math.floor(time), // pure survival time (no combo bonus)
        switches: laneSwitches,
        nearMisses: nearMisses,
        bestCombo: maxCombo,       // best near-miss combo this run (recap/stats)
        storms: stormsRun,         // bursts weathered this run
        descent: sphere + 1,       // deepest Sphere reached (1..7)
        relics: relicState.held.slice(), // relics drafted this Descent
        souls: runSouls,           // total Souls this run (Forge currency)
        soulsDelta: soulsDelta,    // Souls just credited (revive-safe; second finalize adds only new depth)
        ghostTape: ghostOut,       // this run's lane tape (the glue keeps the best per seed)
        gemsDelta: runGems - reportedGems,
        nmDelta: nearMisses - reportedNM,
        secondsDelta: Math.floor(time) - reportedSec,
        stormsDelta: stormsRun - reportedStorms,
        revived: usedRevive
      });
      reportedGems = runGems;
      reportedNM = nearMisses;
      reportedSec = Math.floor(time);
      reportedStorms = stormsRun;
    }
  }

  /* Confetti volleys behind the "NEW BEST!" banner — three staggered
   * bursts across the top of the screen. The later volleys check the
   * state so a quick PLAY AGAIN doesn't spray confetti into the run. */
  function celebrate() {
    Particles.burst(cx, h * 0.30, '#ffd24a', 22, { speed: 240, size: 4, life: 0.8, gravity: 240 });
    Particles.burst(cx, h * 0.30, '#ffffff', 10, { speed: 170, size: 3, life: 0.6, gravity: 240 });
    setTimeout(function () {
      if (state !== State.OVER) return;
      Particles.burst(cx - ringR * 0.7, h * 0.26, '#ffd24a', 16, { speed: 220, size: 4, life: 0.8, gravity: 260 });
      Particles.burst(cx - ringR * 0.7, h * 0.26, '#2bffc8', 8, { speed: 170, size: 3, life: 0.7, gravity: 260 });
    }, 260);
    setTimeout(function () {
      if (state !== State.OVER) return;
      Particles.burst(cx + ringR * 0.7, h * 0.26, '#ffd24a', 16, { speed: 220, size: 4, life: 0.8, gravity: 260 });
      Particles.burst(cx + ringR * 0.7, h * 0.26, curSkin.color, 8, { speed: 170, size: 3, life: 0.7, gravity: 260 });
    }, 520);
  }

  /* ---------- render ---------- */

  function render() {
    ctx.drawImage(bgCanvas, 0, 0, w, h);

    // Strata: parallax dust scrolls (descends) and grows present with depth.
    // ONE seamless blit: sample the h-tall window [drift, drift+h] from the
    // 2x-tall tiled canvas (period h). Allocation-free, behind the ring.
    if (strataCanvas) {
      var drift = (worldClock * 14 * (0.6 + depthF * 1.2)) % h;
      ctx.globalAlpha = 0.5 + depthF * 0.5;
      ctx.drawImage(strataCanvas, 0, drift * dpr, w * dpr, h * dpr, 0, 0, w, h);
      ctx.globalAlpha = 1;
    }
    // atmosphere deepens (darkens the backdrop) the deeper you descend
    if (depthF > 0.01) {
      ctx.globalAlpha = depthF * 0.28;
      ctx.fillStyle = TC.bgOuter || '#05080f';
      ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    }

    ctx.save();
    // death zoom: a slight push toward the impact point while the
    // explosion plays (one canvas transform; off under Reduce motion)
    if (!reduceMotion && state === State.DYING) {
      var z = 1 + 0.10 * (1 - deathTimer / CFG.deathAnim);
      ctx.translate(deathX, deathY);
      ctx.scale(z, z);
      ctx.translate(-deathX, -deathY);
    }
    if (shakeT > 0) {
      var k = (shakeT / shakeDur) * shakeMag;
      ctx.translate((Math.random() * 2 - 1) * k, (Math.random() * 2 - 1) * k);
    }
    // camera kick: a subtle zoom-toward-centre punch on gems/near-miss/power
    if (!reduceMotion && camKick > 0.004) {
      var cz = 1 + camKick * 0.03;
      ctx.translate(cx, cy); ctx.scale(cz, cz); ctx.translate(-cx, -cy);
    }

    if (wardenMorph > 0.001) {
      // Warden duel: the baked ring can't show the live morph, so trace it
      // procedurally (no per-frame shadowBlur — stacked strokes fake the glow).
      drawMorphedRing();
    } else {
      ctx.drawImage(ringCanvas, cx - ringSize / 2, cy - ringSize / 2, ringSize, ringSize);
      // reactive ring: additively redraw the prebaked ring brighter + slightly
      // larger so the whole track "flares" on events (no re-tracing, no alloc).
      // Gated on reduceFlash here (the single consume point) so the per-pickup
      // writers (collectGem/applyPower/nearMiss/Phalanx) are suppressed too —
      // a full-track additive luminance pop is exactly what reduceFlash damps.
      if (ringPulse > 0.01 && !reduceFlash) {
        ctx.globalAlpha = ringPulse * 0.6;
        ctx.globalCompositeOperation = 'lighter';
        var rs = ringSize * (1 + ringPulse * 0.045);
        ctx.drawImage(ringCanvas, cx - rs / 2, cy - rs / 2, rs, rs);
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1;
      }
    }

    drawEntities();
    if (state === State.PLAYING) drawPactGate(); // gameplay-only, like the storm wash
    Particles.draw(ctx);
    drawPops();
    if (state === State.PLAYING) drawGhost(); // behind the real ball; pure render
    if (state !== State.DYING && state !== State.OVER) drawBall();

    ctx.restore();

    // slow-mo: one cheap full-screen wash so the effect reads instantly.
    // Gated on the live states — wScale doesn't tick outside PLAYING, so
    // a death during slow-mo would otherwise tint the panel and menu
    // forever. Constant fillStyle + globalAlpha: no per-frame string
    // allocation in the render hot path.
    if (wScale < 0.97 && (state === State.PLAYING || state === State.DYING)) {
      ctx.globalAlpha = 0.10 * (1 - wScale) / (1 - CFG.slowScale);
      ctx.fillStyle = TC.slow;
      ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    }

    // storm wash: pulsing red during the warning, steady during the
    // burst (same constant-fillStyle + globalAlpha pattern as above)
    if (state === State.PLAYING && (stormPhase === 'warn' || stormPhase === 'burst')) {
      // Reduce-flash keeps the warning tint STEADY instead of pulsing, for
      // players sensitive to flashing (the pulse is the only fast flash).
      ctx.globalAlpha = stormPhase === 'burst'
        ? 0.10
        : (reduceFlash ? 0.06 : 0.06 * (0.5 + 0.5 * Math.sin(time * 12)));
      ctx.fillStyle = TC.storm;
      ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    }

    // Warden wash: the boss color floods the screen during the morph (steady
    // under Reduce flash). The color is a constant hex from the LIST — no
    // per-frame string allocation in the render hot path.
    if (state === State.PLAYING && wardenMorph > 0.01) {
      ctx.globalAlpha = (reduceFlash ? 0.09 : 0.07 + 0.05 * Math.sin(time * 5)) * wardenMorph;
      ctx.fillStyle = Wardens.byIndex(wardenIdx).color;
      ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    }
  }

  /* Storm Bank gate: two markers the ball drives through during the calm
   * — inner lane = BANK (teal), outer lane = RIDE (gold), each showing
   * the gems at stake. Drawn only while the gate is open and undecided. */
  function drawPactGate() {
    if (!pactGate || pactGate.decided) return;
    drawRelicPortal(0, pactGate.angle, pactGate.scale, pactGate.relics[0]);
    drawRelicPortal(1, pactGate.angle, pactGate.scale, pactGate.relics[1]);
  }

  function drawRelicPortal(lane, angle, scale, relic) {
    if (!relic) return;
    var r = laneRadiusAt(lane, angle);
    var x = cx + Math.cos(angle) * r, y = cy + Math.sin(angle) * r;
    var rad = ballR * 1.95 * scale;
    ctx.globalAlpha = scale;
    ctx.strokeStyle = relic.color;
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.14 * scale;
    ctx.fillStyle = relic.color;
    ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill();
    Relics.drawIcon(ctx, x, y, rad * 0.6, relic);
    // relic name, offset radially clear of the ring (inner inward, outer outward)
    var dir = lane === 0 ? -1 : 1;
    var f = trackFrame(angle);
    var lx = x + f.nx * dir * rad * 1.5, ly = y + f.ny * dir * rad * 1.5;
    ctx.globalAlpha = scale;
    ctx.fillStyle = relic.color;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = '800 ' + (ballR * 0.6).toFixed(1) + 'px system-ui, sans-serif';
    ctx.fillText(relic.name, lx, ly);
    ctx.globalAlpha = 1;
  }

  function drawGateMarker(lane, angle, scale, color, label, amount) {
    var r = laneRadiusAt(lane, angle);
    var x = cx + Math.cos(angle) * r, y = cy + Math.sin(angle) * r;
    var rad = ballR * 1.85 * scale;
    // portal ring + soft fill (the ball passes through this circle)
    ctx.globalAlpha = scale;
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.14 * scale;
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill();
    // label + amount, offset radially clear of the ring (inner inward,
    // outer outward) so the track line never crosses the text
    var dir = lane === 0 ? -1 : 1;
    var f = trackFrame(angle);
    var lx = x + f.nx * dir * rad * 1.6, ly = y + f.ny * dir * rad * 1.6;
    ctx.globalAlpha = scale;
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '800 ' + (ballR * 0.72).toFixed(1) + 'px system-ui, sans-serif';
    ctx.fillText(label, lx, ly - ballR * 0.55);
    ctx.font = '800 ' + (ballR * 0.9).toFixed(1) + 'px system-ui, sans-serif';
    ctx.fillText('◆' + amount, lx, ly + ballR * 0.55);
    ctx.globalAlpha = 1;
  }

  function drawEntities() {
    var expireAt = CFG.spawnLead + 1.3;
    for (var i = 0; i < ents.length; i++) {
      var e = ents[i];
      var travel = totalAngle - e.born;
      var alpha = Math.min(1, (expireAt - travel) / 0.5); // fade out behind the ball
      if (alpha <= 0) continue;
      if (e.type === 'spike') drawSpike(e, alpha);
      else if (e.type === 'pulser') drawPulser(e, alpha);
      else if (e.type === 'power') drawPower(e, alpha);
      else drawGem(e, alpha);
    }
  }

  function drawSpike(e, alpha) {
    // Spikes sit flush on the track: base along the local tangent
    // (sunk 2px into the line so it reads attached), tip along the
    // outward/inward surface normal — correct on every shape.
    var dir = laneSign(e.lane);                // inner spikes point inward
    var f = trackFrame(e.angle);
    var half = ballR * 1.05;
    var len = spikeLen * e.scale;
    var sx = f.nx * dir, sy = f.ny * dir;
    var x1 = f.p.x + f.tx * half - sx * 2, y1 = f.p.y + f.ty * half - sy * 2;
    var x2 = f.p.x - f.tx * half - sx * 2, y2 = f.p.y - f.ty * half - sy * 2;
    var x3 = f.p.x + sx * len,             y3 = f.p.y + sy * len;

    // during a feast, spikes turn edible-mint so the player reads that
    // ramming them now pays gems instead of killing
    var edible = feastT > 0;
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.moveTo(x1, y1); ctx.lineTo(x3, y3); ctx.lineTo(x2, y2);
    ctx.closePath();
    // soft halo via a fat rounded stroke, then solid fill — cheap "glow"
    ctx.lineJoin = 'round';
    ctx.strokeStyle = edible ? 'rgba(93,255,143,0.30)' : TC.spikeHalo;
    ctx.lineWidth = ballR * 0.55;
    ctx.stroke();
    ctx.fillStyle = edible ? POWER_COLOR.feast : TC.spike;
    ctx.fill();
    // per-theme spike accent over the base triangle (not while edible —
    // the mint read wins)
    if (!edible) drawSpikeDetail(e, alpha, x1, y1, x2, y2, x3, y3);
    ctx.globalAlpha = 1;
  }

  /* Theme-specific spike accents. Cheap: a few arcs/lines per spike,
   * only for themes that want them. */
  function drawSpikeDetail(e, alpha, x1, y1, x2, y2, x3, y3) {
    var st = curTheme.spikeStyle;
    if (st === 'thornLure') {
      // Hadal: a glowing bioluminescent lure bulb at the tip = the kill
      // point; it breathes, so the danger is alive and luminous
      var r = ballR * (0.40 + 0.06 * Math.sin(time * 3 + e.angle));
      ctx.fillStyle = TC.spikeTip;
      ctx.globalAlpha = alpha * 0.3;
      ctx.beginPath(); ctx.arc(x3, y3, r, 0, TAU); ctx.fill();
      ctx.globalAlpha = alpha;
      ctx.beginPath(); ctx.arc(x3, y3, r * 0.5, 0, TAU); ctx.fill();
    } else if (st === 'obsidian') {
      // Emberfall: a hot fire seam up the spine, brightening as it grows
      ctx.globalAlpha = alpha * Math.min(1, e.scale);
      ctx.strokeStyle = TC.spikeTip;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo((x1 + x2) / 2, (y1 + y2) / 2); ctx.lineTo(x3, y3); ctx.stroke();
    } else if (st === 'iceTip' || st === 'laser') {
      // Cosmic / Neon: a bright white-hot inset tip triangle
      ctx.globalAlpha = alpha;
      ctx.fillStyle = TC.spikeTip;
      ctx.beginPath();
      ctx.moveTo((x1 + x3) / 2, (y1 + y3) / 2);
      ctx.lineTo(x3, y3);
      ctx.lineTo((x2 + x3) / 2, (y2 + y3) / 2);
      ctx.closePath(); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  /* Pulser: same flush triangle as a spike, but orange and blinking.
   * Disarmed it's a hollow outline; the fill fades in over the warn
   * window so the player always sees an arming pulser coming. */
  function drawPulser(e, alpha) {
    var dir = laneSign(e.lane);
    var f = trackFrame(e.angle);
    var half = ballR * 1.05;
    var len = spikeLen * e.scale;
    var sx = f.nx * dir, sy = f.ny * dir;
    var x1 = f.p.x + f.tx * half - sx * 2, y1 = f.p.y + f.ty * half - sy * 2;
    var x2 = f.p.x - f.tx * half - sx * 2, y2 = f.p.y - f.ty * half - sy * 2;
    var x3 = f.p.x + sx * len,             y3 = f.p.y + sy * len;
    var warm = pulserWarnK(e); // 0 dormant .. 1 armed

    ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.moveTo(x1, y1); ctx.lineTo(x3, y3); ctx.lineTo(x2, y2);
    ctx.closePath();
    ctx.lineJoin = 'round';
    if (warm >= 1) {
      // armed: solid + halo, like a spike but the theme's warning hue
      // (edible-mint instead while a feast is live)
      var edibleP = feastT > 0;
      ctx.strokeStyle = edibleP ? 'rgba(93,255,143,0.30)' : TC.pulserHalo;
      ctx.lineWidth = ballR * 0.55;
      ctx.stroke();
      ctx.fillStyle = edibleP ? POWER_COLOR.feast : TC.pulser;
      ctx.fill();
    } else {
      // disarmed: hollow outline; the fill warms up before arming
      if (warm > 0) {
        ctx.globalAlpha = alpha * warm * 0.6;
        ctx.fillStyle = TC.pulser;
        ctx.fill();
        ctx.globalAlpha = alpha;
      }
      ctx.strokeStyle = TC.pulserLine;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  function drawPower(e, alpha) {
    var p = entityPos(e);
    var pulse = 1 + 0.10 * Math.sin(time * 4 + e.angle * 5);
    var r = powerIconR * e.scale * pulse;
    ctx.globalAlpha = alpha;
    ctx.drawImage(powerIcons[e.kind], p.x - r, p.y - r, r * 2, r * 2);
    ctx.globalAlpha = 1;
  }

  function drawGem(e, alpha) {
    var gx, gy;
    if (e.pulled) { gx = e.px; gy = e.py; }
    else { var pos = entityPos(e); gx = pos.x; gy = pos.y; }
    var pulse = 1 + 0.12 * Math.sin(time * 5 + e.angle * 7);
    var s = gemR * e.scale * pulse;
    ctx.globalAlpha = alpha;
    if (curTheme.gemStyle === 'spore') {
      // Hadal: a soft round bioluminescent spore with a bright nucleus
      // and (when free) three orbiting motes — a living micro-cluster
      ctx.fillStyle = TC.gemHalo;
      ctx.beginPath(); ctx.arc(gx, gy, s * 1.5, 0, TAU); ctx.fill();
      ctx.fillStyle = TC.gem;
      ctx.beginPath(); ctx.arc(gx, gy, s * 0.9, 0, TAU); ctx.fill();
      ctx.fillStyle = TC.gemCore;
      ctx.beginPath(); ctx.arc(gx, gy, s * 0.4, 0, TAU); ctx.fill();
      if (!e.pulled) {
        ctx.fillStyle = TC.gem;
        for (var mi = 0; mi < 3; mi++) {
          var ma = time * 2 + mi * (TAU / 3);
          ctx.beginPath();
          ctx.arc(gx + Math.cos(ma) * s * 1.6, gy + Math.sin(ma) * s * 1.6, s * 0.18, 0, TAU);
          ctx.fill();
        }
      }
    } else {
      // diamond / ice / crystal / drop: a rotating faceted square
      ctx.save();
      ctx.translate(gx, gy);
      ctx.rotate(e.angle + Math.PI / 4);
      ctx.fillStyle = TC.gemHalo;
      ctx.fillRect(-s * 1.45, -s * 1.45, s * 2.9, s * 2.9); // halo
      ctx.fillStyle = TC.gem;
      ctx.fillRect(-s, -s, s * 2, s * 2);
      ctx.fillStyle = TC.gemCore;
      // ice/crystal get an OFF-centre facet glint (cut-crystal read);
      // diamond/drop keep the centred sparkle
      if (curTheme.gemStyle === 'ice' || curTheme.gemStyle === 'crystal') {
        ctx.fillRect(-s * 0.72, -s * 0.72, s * 0.62, s * 0.62);
      } else {
        ctx.fillRect(-s * 0.4, -s * 0.4, s * 0.8, s * 0.8);
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  /* Hadal: four short tendrils streaming OPPOSITE the ball's travel,
   * swaying — the firefly-jelly pulsing forward through water. */
  function drawBallTendrils(bx, by) {
    var ux = Math.sin(ball.angle), uy = -Math.cos(ball.angle); // trail behind
    var px = -uy, py = ux;                                     // perpendicular
    var len = ballR * 1.6;
    ctx.strokeStyle = curTheme.ringTint || curSkin.color;
    ctx.lineWidth = 1.4;
    ctx.lineCap = 'round';
    ctx.globalAlpha = 0.55;
    for (var i = 0; i < 4; i++) {
      var off = (i - 1.5) * ballR * 0.4;
      var sway = Math.sin(time * 4 + i) * ballR * 0.5;
      ctx.beginPath();
      ctx.moveTo(bx + px * off, by + py * off);
      ctx.quadraticCurveTo(
        bx + ux * len * 0.5 + px * (off + sway * 0.5), by + uy * len * 0.5 + py * (off + sway * 0.5),
        bx + ux * len + px * (off + sway), by + uy * len + py * (off + sway));
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  /* Ghost racer: a translucent twin of your best run on this seed, riding the
   * same ring at the live angle but the tape's lane. Drawn behind the real
   * ball; vanishes the instant the recorded run ended (you've gone deeper). */
  function drawGhost() {
    if (!ghostOn || !ghostTape || totalAngle > ghostTape.end) return;
    var gr = trackR(ball.angle) + ghostOff;
    var gx = cx + Math.cos(ball.angle) * gr;
    var gy = cy + Math.sin(ball.angle) * gr;
    ctx.save();
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = curSkin.color;
    ctx.beginPath(); ctx.arc(gx, gy, ballR * 0.9, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = curSkin.color;
    ctx.beginPath(); ctx.arc(gx, gy, ballR * 1.08, 0, TAU); ctx.stroke();
    ctx.restore();
    ctx.globalAlpha = 1;
  }

  function drawBall() {
    var skin = curSkin;
    var br = ballRadius();
    var bx = cx + Math.cos(ball.angle) * br;
    var by = cy + Math.sin(ball.angle) * br;

    // trail: the ORIGINAL dense smear (restored — this is the look people
    // liked). Each of the last 14 ball positions is a translucent disc,
    // brightest+largest at the ball and fading/shrinking toward the tail.
    // pushTrail records one point EVERY frame, so the discs overlap densely
    // and read as a smooth streak (the later distance-gated version spaced them
    // out, which is what made them look like separate balls).
    for (var ti = 0; ti < trail.length; ti++) {
      var tf = (ti + 1) / trail.length;
      ctx.globalAlpha = tf * 0.22;
      ctx.fillStyle = skin.color;
      ctx.beginPath();
      ctx.arc(trail[ti].x, trail[ti].y, ballR * (0.35 + 0.5 * tf), 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // theme ball extras (jelly tendrils etc.) render behind the bright core
    if (curTheme.ballExtra === 'tendrils') drawBallTendrils(bx, by);

    // magnet: faint reach circle, fading out over the last second
    if (magnetT > 0) {
      ctx.globalAlpha = 0.10 * Math.min(1, magnetT);
      ctx.strokeStyle = POWER_COLOR.magnet;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(bx, by, ringR * CFG.magnetRadius, 0, TAU);
      ctx.stroke();
    }

    // doubler: golden ring around the ball, fading out over the last second
    if (doubleT > 0) {
      ctx.globalAlpha = (0.35 + 0.15 * Math.sin(time * 7)) * Math.min(1, doubleT);
      ctx.strokeStyle = POWER_COLOR.double;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(bx, by, ballR * 1.55, 0, TAU);
      ctx.stroke();
    }

    // feast: pulsing mint ring while spikes are edible
    if (feastT > 0) {
      ctx.globalAlpha = (0.4 + 0.2 * Math.sin(time * 9)) * Math.min(1, feastT);
      ctx.strokeStyle = POWER_COLOR.feast;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(bx, by, ballR * 1.7, 0, TAU);
      ctx.stroke();
    }

    // shield: pulsing aura ring around the ball
    if (shieldOn) {
      ctx.globalAlpha = 0.45 + 0.2 * Math.sin(time * 6);
      ctx.strokeStyle = POWER_COLOR.shield;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(bx, by, ballR * 1.9, 0, TAU);
      ctx.stroke();
      ctx.globalAlpha = 0.10;
      ctx.fillStyle = POWER_COLOR.shield;
      ctx.beginPath();
      ctx.arc(bx, by, ballR * 1.9, 0, TAU);
      ctx.fill();
    }

    // blink while invulnerable (post-revive)
    var a = invuln > 0 ? 0.4 + 0.6 * Math.abs(Math.sin(time * 14)) : 1;

    // jelly squash/stretch of the ball CORE (auras above stay round), oriented
    // along the orbit tangent. Volume-preserving-ish; off under Reduce motion.
    var squashing = !reduceMotion && Math.abs(ballSquash) > 0.002;
    if (squashing) {
      ctx.save();
      ctx.translate(bx, by);
      ctx.rotate(ball.angle + Math.PI / 2); // motion direction (tangent)
      ctx.scale(1 + ballSquash, 1 - ballSquash * 0.55);
      ctx.translate(-bx, -by);
    }

    // layered translucent circles read as neon glow without shadowBlur
    // (BALL_GLOW is hoisted to module scope — no per-frame array allocation)
    for (var g = 0; g < BALL_GLOW.length; g++) {
      ctx.globalAlpha = BALL_GLOW[g][1] * a;
      ctx.fillStyle = skin.color;
      ctx.beginPath();
      ctx.arc(bx, by, ballR * BALL_GLOW[g][0], 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = a;
    if (skinIcon) {
      // character skin: one cached image draw
      ctx.drawImage(skinIcon, bx - skinIconR, by - skinIconR, skinIconR * 2, skinIconR * 2);
    } else {
      // flat neon skin: circle + highlight
      ctx.fillStyle = skin.color;
      ctx.beginPath(); ctx.arc(bx, by, ballR, 0, TAU); ctx.fill();
      ctx.fillStyle = skin.core || '#ffffff';
      ctx.beginPath(); ctx.arc(bx - ballR * 0.25, by - ballR * 0.25, ballR * 0.42, 0, TAU); ctx.fill();
    }
    if (squashing) ctx.restore();
    ctx.globalAlpha = 1;
  }

  /* ---------- public API ---------- */

  return {
    init: init,
    resize: resize,
    update: update,
    render: render,
    startRun: startRun,
    toMenu: toMenu,
    onTap: onTap,
    pause: pause,
    resume: resume,
    revive: revive,
    canRevive: canRevive,
    refreshSkin: refreshSkin,
    refreshLevel: refreshLevel,
    refreshTrail: refreshTrail,
    refreshTheme: refreshTheme,
    celebrate: celebrate,
    state: function () { return state; },
    setReduceMotion: function (v) { reduceMotion = !!v; },
    setReduceFlash: function (v) { reduceFlash = !!v; },
    setGhost: function (v) { ghostOn = !!v; },
    /* debug aid for automated tests (harmless in production) */
    _debug: {
      info: function () {
        return { state: state, time: time, speed: speed, ents: ents.length, gems: runGems };
      },
      lastDeath: function () { return lastDeath; },
      spikeDist: function (e, x, y) { return spikeDist(e, x, y); },
      snapshot: function () {
        return {
          ball: { angle: ball.angle, lane: ball.lane, off: ball.off },
          totalAngle: totalAngle,
          ballR: ballR,
          ents: ents.map(function (e) {
            return { type: e.type, kind: e.kind, lane: e.lane, angle: e.angle,
                     travel: totalAngle - e.born, minD: e.minD };
          })
        };
      },
      forceDeath: function () {
        if (state === State.PLAYING) {
          var r = ballRadius();
          die(cx + Math.cos(ball.angle) * r, cy + Math.sin(ball.angle) * r);
        }
      },
      setTime: function (t) { time = t; },
      applyPower: function (kind) { applyPower(kind, cx, cy); },
      effects: function () {
        return { shield: shieldOn, magnetT: magnetT, slowT: slowT, doubleT: doubleT,
                 feastT: feastT, wScale: wScale, invuln: invuln, nearMisses: nearMisses,
                 comboN: comboN, maxCombo: maxCombo, scoreBonus: scoreBonus, runGems: runGems,
                 bankedGems: bankedGems, stormPhase: stormPhase, stormsRun: stormsRun,
                 hitStop: hitStop, zen: zenMode,
                 warden: wardenState, wardenT: wardenT, wardenMorph: wardenMorph,
                 wardenSouls: wardenSouls, wardensTriggered: wardensTriggered,
                 stormPot: stormPot, held: relicState.held.slice(),
                 pactCount: pactCount, gemMult: relicState.gemMult,
                 gateOpen: !!(pactGate && !pactGate.decided) };
      },
      gateOffers: function () { // ids offered at the OPEN gate (tier-ramp / seed tests)
        if (!pactGate) return null;
        var ids = [];
        for (var i = 0; i < pactGate.relics.length; i++) ids.push(pactGate.relics[i].id);
        return ids;
      },
      // ghost replay state (P0.2 tests): live ghost lane, whether it's on screen
      ghostLane: function () { return ghostTape ? (ghostTape.start ^ (ghostIdx & 1)) : null; },
      ghostActive: function () { return !!(ghostTape && totalAngle <= ghostTape.end); },
      forceWarden: function () { if (state === State.PLAYING && wardenState === 'none') startWarden(); },
      wardenAllow: function (on) { wardenAllowed = !!on; },
      recTape: function () { return recTape ? { start: recTape.start, sw: recTape.sw.slice(), end: recTape.end } : null; },
      setLane: function (l) { ball.lane = l === 0 ? 0 : 1; },
      armed: function (idx) { // pulser arm state for fairness tests
        var e = ents[idx];
        return !e ? null : (e.type !== 'pulser' || pulserArmed(e));
      }
    }
  };
})();
