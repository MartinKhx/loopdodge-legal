/* Missions: three concurrent goals drawn from a pool, each paying
 * gems on completion. The engine stays decoupled — game.js only
 * counts things (gems, lane switches, near misses) and hands one
 * summary object to onRunEnd(); all mission logic lives here.
 *
 * Active set is persisted via Store. Completing a mission grants its
 * reward immediately and draws a replacement (never duplicating a
 * template already in the active set). */
var Missions = (function () {

  /* Template pool. Each tier is [target, reward]; rewards scale with
   * difficulty but stay inside the 50-200 economy guardrail.
   *   per-run templates complete when ONE run reaches the target;
   *   'total'/'runs' accumulate across runs. */
  var POOL = [
    { tid: 'survive',   tiers: [[20, 60], [35, 90], [50, 140], [75, 200]],
      text: function (m) { return I18n.t('Survive {n}s in one run', { n: m.n }); },
      runValue: function (s) { return s.seconds; } },
    { tid: 'rungems',   tiers: [[15, 60], [30, 100], [50, 150]],
      text: function (m) { return I18n.t('Collect {n} ◆ in one run', { n: m.n }); },
      runValue: function (s) { return s.runGems; } },
    { tid: 'totalgems', tiers: [[75, 50], [150, 80], [300, 120], [600, 180]],
      total: true,
      text: function (m) { return I18n.t('Collect {n} ◆ in total', { n: m.n }); },
      runValue: function (s) { return s.gemsDelta; } },
    { tid: 'runs',      tiers: [[3, 50], [7, 90], [15, 150]],
      total: true,
      text: function (m) { return I18n.t('Finish {n} runs', { n: m.n }); },
      runValue: function (s) { return s.revived ? 0 : 1; } },
    { tid: 'track',     tiers: [[1, 70]],
      text: function (m) { return I18n.t('Finish a run on {track}', { track: Levels.byId(m.track).name }); },
      runValue: function (s, m) { return s.level === m.track ? 1 : 0; } },
    { tid: 'switches',  tiers: [[40, 60], [80, 100], [150, 160]],
      text: function (m) { return I18n.t('Switch lanes {n}× in one run', { n: m.n }); },
      runValue: function (s) { return s.switches; } },
    { tid: 'nearmiss',  tiers: [[3, 80], [8, 130], [15, 200]],
      text: function (m) { return I18n.t('Near-miss {n} spikes in one run', { n: m.n }); },
      runValue: function (s) { return s.nearMisses; } },
    { tid: 'level',     tiers: [[2, 60], [4, 110], [7, 170]],
      text: function (m) { return I18n.t('Reach player level {n}', { n: m.n }); },
      // XP.addRun ran before onRunEnd in main.js, so this sees the
      // post-run level; per-run "best value" semantics complete it
      runValue: function () { return Store.getPlayerLevel(); } }
  ];

  function tmpl(tid) {
    for (var i = 0; i < POOL.length; i++) {
      if (POOL[i].tid === tid) return POOL[i];
    }
    return null;
  }

  /* Tiers a template may draw right now. 'level' only offers targets
   * ABOVE the current player level — runValue is the persistent level,
   * so an already-met tier would auto-complete (and re-pay) on the
   * very next run end, a recurring free-gem faucet. */
  function drawableTiers(t) {
    if (t.tid !== 'level') return t.tiers;
    var lvl = Store.getPlayerLevel();
    var out = [];
    for (var i = 0; i < t.tiers.length; i++) {
      if (t.tiers[i][0] > lvl) out.push(t.tiers[i]);
    }
    return out;
  }

  /* Draw one new mission whose template isn't already active (and is
   * actually achievable as a fresh goal). */
  function draw(activeList) {
    var used = {};
    for (var i = 0; i < activeList.length; i++) used[activeList[i].tid] = true;
    var open = [];
    for (var j = 0; j < POOL.length; j++) {
      if (!used[POOL[j].tid] && drawableTiers(POOL[j]).length > 0) open.push(POOL[j]);
    }
    var t = open[Math.floor(Math.random() * open.length)];
    var tiers = drawableTiers(t);
    var tier = tiers[Math.floor(Math.random() * tiers.length)];
    var m = { tid: t.tid, n: tier[0], reward: tier[1], p: 0 };
    if (t.tid === 'track') {
      // pick from owned tracks so the goal is always achievable
      var owned = Levels.LIST.filter(function (l) { return Levels.isOwned(l.id); });
      m.track = owned[Math.floor(Math.random() * owned.length)].id;
    }
    return m;
  }

  /* Active set, created on first access. Drops any stored mission
   * whose template no longer exists, and any 'track' mission whose
   * level id was removed in an update (Levels.byId falls back to the
   * default track, which would leave the mission silently
   * uncompletable while showing the wrong name). */
  function active() {
    var list = Store.getMissions();
    if (!list) list = [];
    list = list.filter(function (m) {
      if (!tmpl(m.tid)) return false;
      if (m.track && Levels.byId(m.track).id !== m.track) return false;
      return true;
    });
    while (list.length < 3) list.push(draw(list));
    Store.setMissions(list);
    return list;
  }

  /* Rows for the menu panel: text, progress, reward. */
  function list() {
    return active().map(function (m) {
      return { text: tmpl(m.tid).text(m), p: Math.min(m.p, m.n), n: m.n, reward: m.reward };
    });
  }

  /* Feed one finished run (the game-over summary from game.js).
   * Returns the missions completed by this run, already rewarded
   * and replaced, so the UI can toast them. */
  function onRunEnd(s) {
    var listA = active();
    var completed = [];
    for (var i = 0; i < listA.length; i++) {
      var m = listA[i];
      var t = tmpl(m.tid);
      var v = t.runValue(s, m);
      // cumulative missions add up; per-run ones track the best run
      m.p = t.total ? m.p + v : Math.max(m.p, v);
      /* A revived run finalizes TWICE (game.js finalizeGameOver runs on each
       * death). Only CUMULATIVE missions may complete on the second, revived
       * pass — their progress uses the revive-safe gemsDelta watermark. Per-run
       * missions complete only on the first (pre-revive) finalize, so a
       * freshly-drawn per-run replacement can never be re-paid by the same run
       * (the gem faucet), and a "do X in one run" goal correctly does not count
       * a revive as part of that one run. */
      if (s.revived && !t.total) continue;
      if ((t.total ? m.p : v) >= m.n) {
        Store.addGems(m.reward);
        Store.setMissionsDone(Store.getMissionsDone() + 1);
        completed.push({ text: t.text(m), reward: m.reward });
        listA[i] = draw(listA);
      }
    }
    Store.setMissions(listA);
    return completed;
  }

  return { list: list, onRunEnd: onRunEnd };
})();
