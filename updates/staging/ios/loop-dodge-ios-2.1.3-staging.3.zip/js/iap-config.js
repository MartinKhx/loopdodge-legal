/* ============================================================
 * IN-APP PURCHASE CONFIGURATION
 *
 * These product IDs must EXACTLY match the in-app products you
 * create in Google Play Console:
 *   Play Console > your app > Monetize > Products > In-app products
 *   > Create product
 *
 * - gems_* products: one-time products that Play treats as
 *   consumable (the game consumes them on grant, so they can be
 *   bought repeatedly).
 * - remove_ads: a permanent one-time purchase.
 *
 * Until the products exist in Play Console AND the app is in a
 * testing track with your account as a license tester, the shop
 * shows "store unavailable" — that is expected during development.
 * Browser testing: open the game with ?fakeiap=1 to simulate.
 * ============================================================ */
var IAP_CONFIG = {
  products: [
    // id                      what the buyer gets                  platforms
    // `platforms` gates which store registers + shows each product. iOS uses
    // App Store Connect product ids; Android uses Play Console ids (same ids).
    //
    // GEM AMOUNTS ARE A VALUE LADDER. Store prices (set in ASC/Play, not
    // here) as of 2026-08: small $0.99, medium $3.99, large $7.99. Gems per
    // dollar MUST rise with pack size — 505 -> 627 -> 814 — so the POPULAR
    // and BEST VALUE badges the shop draws on the bigger packs are true.
    // (The original 500/1500/5000 made the medium pack the WORST deal in the
    // shop at 376 gems/$.) If a price tier changes in ASC, re-derive the
    // amounts, update the ASC product names to match, and keep
    // test/gempack-value.test.js in sync — it pins these prices.
    { id: 'gems_small',  type: 'consumable',     gems: 500,
      title: '500 gems',  platforms: ['ios', 'android'] },
    { id: 'gems_medium', type: 'consumable',     gems: 2500,
      title: '2500 gems', platforms: ['ios', 'android'] },
    { id: 'gems_large',  type: 'consumable',     gems: 6500,
      title: '6500 gems', platforms: ['ios', 'android'] },
    // Android-only legacy: hides interstitials forever; rewarded revive stays.
    // iOS never offers this — its only ads are opt-in rewarded, so there is
    // nothing involuntary to remove (offering it would be an App Store rejection).
    { id: 'remove_ads',  type: 'non_consumable',
      title: 'Remove ads', platforms: ['android'] },
    // Ultra Pass: permanent x3 multiplier on EARNED gems + a daily gem gift.
    { id: 'ultra_pass',  type: 'non_consumable',
      title: 'Ultra Pass', platforms: ['ios', 'android'] }
  ]
};
