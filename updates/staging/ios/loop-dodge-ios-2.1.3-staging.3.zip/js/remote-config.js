/* Data only. Remote input can tune these existing mechanics, never supply code,
 * URLs, purchases, ad IDs, permissions, or enable undisclosed game features. */
var RemoteConfig = (function () {
  var KEY = 'ld_remote_config_v1';
  var DEFAULTS = { revision: 'builtin', baseSpeed: 1.7, maxSpeed: 3.6,
    rampPerSec: 0.022, gemChance: 0.30, powerChance: 0.12 };
  var LIMITS = { baseSpeed: [1.4, 1.9], maxSpeed: [2.5, 3.6],
    rampPerSec: [0.01, 0.03], gemChance: [0.20, 0.40], powerChance: [0.05, 0.20] };
  var pending = copy(DEFAULTS), fetchedAt = 0, request = null;
  function copy(v) { return JSON.parse(JSON.stringify(v)); }
  function settings() { return (window.SERVICES_CONFIG && SERVICES_CONFIG.remoteConfig) || {}; }
  function environment() { return (window.SERVICES_CONFIG && SERVICES_CONFIG.environment) || 'staging'; }
  function valid(v) {
    if (!v || v.schemaVersion !== 1 || v.environment !== environment() ||
        typeof v.revision !== 'string' || !/^[a-zA-Z0-9_.-]{1,40}$/.test(v.revision) ||
        !v.tuning || typeof v.tuning !== 'object') return null;
    var out = copy(DEFAULTS);
    out.revision = v.revision;
    var keys = Object.keys(v.tuning);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i], n = v.tuning[k], range = LIMITS[k];
      if (!range || typeof n !== 'number' || !isFinite(n) || n < range[0] || n > range[1]) return null;
      out[k] = n;
    }
    if (out.maxSpeed < out.baseSpeed) return null;
    return out;
  }
  function accept(v, stamp) {
    try {
      var out = valid(v);
      if (!out) return false;
      pending = out; fetchedAt = stamp || Date.now();
      try { localStorage.setItem(KEY, JSON.stringify({ payload: v, fetchedAt: fetchedAt })); } catch (e) {}
      return true;
    } catch (e) { return false; }
  }
  function fresh() {
    var hours = Number(settings().cacheMaxAgeHours) || 24;
    var age = Date.now() - fetchedAt;
    return fetchedAt > 0 && age >= 0 && age <= Math.min(168, Math.max(1, hours)) * 3600000;
  }
  function loadCache() {
    try {
      var saved = JSON.parse(localStorage.getItem(KEY));
      if (saved && typeof saved.fetchedAt === 'number') {
        fetchedAt = saved.fetchedAt;
        var value = valid(saved.payload);
        if (value && fresh()) pending = value;
        else fetchedAt = 0;
      }
    } catch (e) { fetchedAt = 0; }
  }
  function fetchConfig() {
    var url = settings().url;
    if (!url || !/^https:\/\//.test(url) || typeof fetch !== 'function') return Promise.resolve(false);
    if (request) return request;
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    var timer;
    var network = fetch(url, { credentials: 'omit', cache: 'no-store', signal: controller ? controller.signal : undefined })
      .then(function (r) { if (!r.ok) throw new Error('config_http'); return r.text(); })
      .then(function (body) { if (body.length > 8192) return false; return accept(JSON.parse(body)); });
    request = Promise.race([network, new Promise(function (resolve) {
      timer = setTimeout(function () { if (controller) controller.abort(); resolve(false); }, 5000);
    })]).catch(function () { return false; }).then(function (ok) {
      clearTimeout(timer); request = null; return ok;
    });
    return request;
  }
  loadCache();
  return {
    refresh: fetchConfig,
    accept: accept,
    /* Seeded Daily / Oracle races always use built-in tuning. Even a cached
     * config cannot change an existing seed's physics or spawn stream. */
    forRun: function (seeded) { return copy(seeded || !fresh() ? DEFAULTS : pending); },
    status: function () { return { revision: fresh() ? pending.revision : 'builtin', source: fresh() ? 'remote' : 'builtin' }; }
  };
})();
