/* Small observers around successful actions. They do not change rewards,
 * receipts, save data, ad decisions, RNG, or the game frame loop. */
var GameServices = (function () {
  var initialized = false, transactions = 0, tutorialReported = false, consentOpen = false;
  var returnFocus = null;
  function track(name, fields) { try { Analytics.track(name, fields); } catch (e) {} }
  function safeMenu() { return Game.state() === 'menu' && transactions === 0 && !consentOpen; }
  function refreshChoice() {
    var button = document.getElementById('setAnalyticsBtn');
    if (!button) return;
    button.classList.toggle('hidden', !Analytics.available());
    document.getElementById('analyticsSettingsNote').classList.toggle('hidden', !Analytics.available());
    button.setAttribute('aria-pressed', Analytics.getConsent() === true ? 'true' : 'false');
    document.getElementById('setAnalyticsVal').textContent = Analytics.getConsent() === true ? 'ON' : 'OFF';
  }
  function choose(on) {
    Analytics.setConsent(on); consentOpen = false;
    document.getElementById('analyticsConsent').classList.add('hidden');
    refreshChoice();
    if (returnFocus && returnFocus.focus) returnFocus.focus();
  }
  function ask() {
    if (!Analytics.available()) return;
    returnFocus = document.activeElement; consentOpen = true;
    document.getElementById('analyticsConsent').classList.remove('hidden');
    document.getElementById('analyticsDecline').focus();
  }
  function wrapBuy(module, kind) {
    if (!module || !module.buy) return;
    var original = module.buy;
    module.buy = function (id) {
      var owned = module.isOwned(id), result = original.apply(module, arguments);
      if (result && !owned) {
        var item = module.byId(id);
        track('item_unlocked', { item_id: id, item_type: kind, currency: item.soul ? 'Souls' : 'Gems', amount: item.soul || item.cost || 0 });
      }
      return result;
    };
  }
  function wrapAd(method, type) {
    var original = Ads[method];
    if (!original) return;
    Ads[method] = function (placement) {
      placement = typeof placement === 'string' ? placement : type;
      track('ad_requested', { placement: placement }); transactions++;
      var result;
      try { result = original.apply(Ads, arguments); } catch (e) { result = Promise.reject(e); }
      return Promise.resolve(result).then(function (earned) {
        transactions--;
        if (type === 'rewarded') track(earned ? 'ad_reward_earned' : 'ad_not_rewarded', { placement: placement });
        return earned;
      }, function () {
        transactions--; track('ad_error', { placement: placement }); return false;
      });
    };
  }
  function init() {
    if (initialized) return;
    initialized = true;
    Analytics.init(); RemoteConfig.refresh();
    LiveUpdates.init(safeMenu);
    // Capture boot errors already seen before this module was initialized.
    if (window.Telemetry && Telemetry.recent().length) LiveUpdates.bootFailed();
    wrapAd('showRewarded', 'rewarded'); wrapAd('showInterstitial', 'interstitial');
    wrapBuy(Skins, 'skin'); wrapBuy(Levels, 'track'); wrapBuy(Trails, 'trail');
    ['setSkin', 'setTrail', 'setLevel', 'setTheme', 'setRelicSeed'].forEach(function (name) {
      var original = Store[name];
      if (!original) return;
      Store[name] = function (id) {
        var result = original.apply(Store, arguments);
        track(name === 'setRelicSeed' ? 'relic_seeded' : 'item_selected', { item_id: id, item_type: name.slice(3).toLowerCase() });
        return result;
      };
    });
    var buy = Iap.buy;
    Iap.buy = function (id) {
      track('purchase_requested', { product_id: id }); transactions++;
      var result;
      try { result = buy.apply(Iap, arguments); } catch (e) { result = Promise.reject(e); }
      return Promise.resolve(result).then(function (ok) {
        transactions--; if (!ok) track('purchase_order_failed', { product_id: id }); return ok;
      }, function () { transactions--; track('purchase_order_failed', { product_id: id }); return false; });
    };
    var claim = Daily.claimStreak;
    Daily.claimStreak = function () {
      var result = claim.apply(Daily, arguments);
      if (result) track('daily_claimed', { amount: result.gems }); return result;
    };
    var menu = UI.showMenu;
    UI.showMenu = function () { var result = menu.apply(UI, arguments); LiveUpdates.atMenu(); return result; };
    document.getElementById('analyticsDecline').addEventListener('click', function () { choose(false); });
    document.getElementById('analyticsAccept').addEventListener('click', function () { choose(true); });
    document.getElementById('setAnalyticsBtn').addEventListener('click', function () {
      if (Analytics.getConsent() === true) { Analytics.setConsent(false); refreshChoice(); }
      else ask();
    });
    document.getElementById('analyticsConsent').addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); choose(false); }
      if (event.key === 'Tab') {
        var items = this.querySelectorAll('a,button'), first = items[0], last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
    document.addEventListener('visibilitychange', function () {
      Analytics.foreground(!document.hidden);
      if (!document.hidden) { RemoteConfig.refresh(); LiveUpdates.check(); }
    });
    try {
      var app = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App;
      if (app) Promise.resolve(app.addListener('appStateChange', function (event) {
        Analytics.foreground(event.isActive);
      })).catch(function () {});
    } catch (e) {}
    refreshChoice();
    if (Analytics.available() && Analytics.getConsent() === null) ask();
  }
  return { init: init, safeMenu: safeMenu,
    dismissConsent: function () { if (!consentOpen) return false; choose(false); return true; },
    tutorialCompleted: function () {
      if (!tutorialReported && !Store.getTutorialDone()) { tutorialReported = true; track('tutorial_completed', {}); }
    }
  };
})();
