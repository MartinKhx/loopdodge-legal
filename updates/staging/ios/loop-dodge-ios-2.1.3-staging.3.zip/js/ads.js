/* AdMob wrapper (via @capacitor-community/admob).
 *
 * Design rule: ads are strictly optional. In a desktop browser, with no
 * network, or if any plugin call throws, the public API quietly no-ops and
 * the game keeps working fully offline.
 *
 * CONSENT + AD SAFETY (Google UMP — developers.google.com/admob/android/privacy)
 *   init() runs an explicit state machine:
 *     unavailable -> initializing -> (consent_required | ready | failed)
 *   Ads are loaded ONLY when consent permits requesting them
 *   (canRequestAds = consent status NOT_REQUIRED or OBTAINED). A consent
 *   info / form FAILURE never silently falls through to loading ads — it
 *   moves to `failed` and schedules a bounded retry, so a transient offline
 *   error recovers without ever serving an unconsented ad. When the user is
 *   in a consent jurisdiction we expose a privacy-options entry
 *   (showPrivacyOptions) for a settings action.
 *
 * REWARD INTEGRITY
 *   Each showRewarded()/showInterstitial() mints a unique offer token. Event
 *   and timeout callbacks settle an offer only if it is still the ACTIVE
 *   offer, so a late callback from a previous, already-settled offer can
 *   never resolve — or grant a reward to — a newer one. (The run-level
 *   guards in main.js, which re-check game state before applying a reward,
 *   complete this protection; the plugin cannot tag a reward event with an
 *   offer id, so cross-offer attribution is bounded here, not eliminated.)
 *
 * Browser testing aid: open with ?fakeads=1 to simulate ads (revive button
 * appears and "ads" grant instantly). Ad unit IDs live in ad-config.js. */
var Ads = (function () {
  var ST = {
    UNAVAILABLE:      'unavailable',       // no native plugin (browser)
    INITIALIZING:     'initializing',      // SDK init + consent flow running
    CONSENT_REQUIRED: 'consent_required',  // consent not obtained -> no ad requests
    READY:            'ready',             // consent OK -> ads may load/show
    FAILED:           'failed',            // init/consent error -> retrying, no ads
    FAKE:             'fake'               // ?fakeads=1 simulation
  };

  var plugin = null;
  var state = ST.UNAVAILABLE;
  var wired = false;
  var privacyRequired = false;  // user is in a consent jurisdiction (show privacy options)
  var retries = 0;

  var interstitialReady = false;
  var rewardedReady = false;
  var intActive = null;         // current interstitial offer { seq, settled, resolve, timer }
  var rwActive = null;          // current rewarded offer { seq, granted, settled, resolve, timer }
  var intSeq = 0, rwSeq = 0;
  var readyCb = null;           // notified when a rewarded ad finishes loading
  var consentInfo = null;
  var errors = [];              // local, bounded diagnostics; never uploaded
  var loadGeneration = 0;       // discard loads started before a privacy change
  var rwLoading = false, intLoading = false;
  var rwRetry = null, intRetry = null;

  var FAKE = /[?&]fakeads=1/.test(location.search);

  var NEVER_SHOWED_MS = 30000;  // short fuse: the ad never appeared
  var STUCK_AD_MS = 90000;      // long fuse once Showed fires (never settle mid-playback)
  var RELOAD_MS = 45000;        // retry a failed preload (e.g. after being offline)
  var RETRY_MS = 60000;         // retry the consent/init flow after a transient failure
  var MAX_RETRIES = 5;

  /* Event names from @capacitor-community/admob. */
  var EV = {
    intShowed:     'interstitialAdShowed',
    intDismissed:  'interstitialAdDismissed',
    intFailedShow: 'interstitialAdFailedToShow',
    intFailedLoad: 'interstitialAdFailedToLoad',
    rwShowed:      'onRewardedVideoAdShowed',
    rwDismissed:   'onRewardedVideoAdDismissed',
    rwFailedShow:  'onRewardedVideoAdFailedToShow',
    rwFailedLoad:  'onRewardedVideoAdFailedToLoad',
    rwRewarded:    'onRewardedVideoAdReward'
  };

  function notifyReady() {
    if (readyCb) { try { readyCb(); } catch (e) { /* UI hook is optional */ } }
  }

  function isNative() {
    return !!(window.Capacitor &&
              typeof window.Capacitor.isNativePlatform === 'function' &&
              window.Capacitor.isNativePlatform() &&
              window.Capacitor.Plugins &&
              window.Capacitor.Plugins.AdMob);
  }

  /* iOS now ships WITH opt-in rewarded ads (non-personalized; no ATT prompt).
   * AdMob ids are per-platform, so on iOS we use AD_CONFIG.iosRewardedId /
   * iosInterstitialId and Info.plist carries a GADApplicationIdentifier +
   * SKAdNetworkItems. isIOS() is now only used to pick the right ad units. */
  function isIOS() {
    return !!(window.Capacitor &&
              typeof window.Capacitor.getPlatform === 'function' &&
              window.Capacitor.getPlatform() === 'ios');
  }

  /* Per-platform ad unit ids (AdMob ids differ by platform). */
  function rewardedUnit() {
    return (isIOS() && AD_CONFIG.iosRewardedId) ? AD_CONFIG.iosRewardedId : AD_CONFIG.rewardedId;
  }
  function interstitialUnit() {
    return (isIOS() && AD_CONFIG.iosInterstitialId) ? AD_CONFIG.iosInterstitialId : AD_CONFIG.interstitialId;
  }

  function adOptions(adId) {
    // Absence of Apple's tracking prompt does not set AdMob's NPA flag.
    // Enforce the iOS non-personalized-only promise on every request.
    return { adId: adId, isTesting: AD_CONFIG.isTesting, npa: isIOS() };
  }

  function recordError(stage, error) {
    var message = error && error.message != null ? String(error.message) : String(error || 'Unknown ad error');
    var code = error && error.code != null ? String(error.code) : null;
    var last = errors[errors.length - 1];
    // Android emits the SDK code in an event, then rejects the promise with
    // only the message. Preserve the richer event instead of overwriting it.
    if (last && last.stage === stage && last.message === message.slice(0, 1000) && Date.now() - last.time < 1000) {
      if (code != null) last.code = code;
      return;
    }
    var entry = { time: Date.now(), stage: stage, code: code, message: message.slice(0, 1000) };
    errors.push(entry);
    if (errors.length > 20) errors.shift();
    console.warn('[ads] ' + stage + ' failed:', JSON.stringify(entry));
  }

  function rememberConsent(info) {
    consentInfo = info ? {
      status: info.status,
      canRequestAds: info.canRequestAds,
      isConsentFormAvailable: info.isConsentFormAvailable,
      privacyOptionsRequirementStatus: info.privacyOptionsRequirementStatus
    } : null;
    return info;
  }

  function invalidateLoads() {
    loadGeneration++;
    interstitialReady = rewardedReady = false;
    if (intRetry != null) clearTimeout(intRetry);
    if (rwRetry != null) clearTimeout(rwRetry);
    intRetry = rwRetry = null;
  }

  function getDiagnostics() {
    return JSON.parse(JSON.stringify({
      state: state,
      platform: isIOS() ? 'ios' : (isNative() ? 'android' : 'web'),
      testAds: !!AD_CONFIG.isTesting,
      nonPersonalizedOnly: isIOS(),
      rewardedUnit: rewardedUnit(),
      rewardedReady: rewardedReady,
      rewardedLoading: rwLoading,
      consent: consentInfo,
      errors: errors
    }));
  }

  /* ---------- consent decision (pure, testable) ----------
   * info: { status: 'NOT_REQUIRED'|'REQUIRED'|'OBTAINED'|'UNKNOWN',
   *         isConsentFormAvailable: bool,
   *         canRequestAds: bool,                    (plugin >= 7.0.3)
   *         privacyOptionsRequirementStatus: 'NOT_REQUIRED'|'REQUIRED'|'UNKNOWN' }
   * or null on error.
   *
   * The two @since 7.0.3 fields are AUTHORITATIVE when present: under UMP 3.x a
   * US-regulated-state user can come back with status NOT_REQUIRED while
   * privacyOptionsRequirementStatus is REQUIRED, and deriving the answer from
   * `status` alone would then hide the in-app privacy-options entry point.
   * Both reads fall back to the old status rule so an older plugin (or a test
   * stub that only sets `status`) behaves exactly as before. */
  function evalConsent(info) {
    if (!info || typeof info.status !== 'string') {
      return { ok: false, canRequestAds: false, needForm: false, privacyRequired: false };
    }
    var s = info.status;
    var can = (typeof info.canRequestAds === 'boolean')
      ? info.canRequestAds
      : (s === 'NOT_REQUIRED' || s === 'OBTAINED');
    var pr = (info.privacyOptionsRequirementStatus === 'REQUIRED') ||
             (s === 'REQUIRED' || s === 'OBTAINED');
    return {
      ok: true,
      canRequestAds: can,
      needForm: (s === 'REQUIRED' && !!info.isConsentFormAvailable),
      privacyRequired: pr
    };
  }

  /* ---------- developer-only UMP debug geography (C1-7) ----------
   * Lets a registered test device be shown the EEA consent form anywhere in
   * the world. OFF unless ALL of: DEV_MODE is true, CONSENT_DEBUG_GEOGRAPHY is
   * 'EEA' or 'NOT_EEA', and CONSENT_TEST_DEVICES is non-empty (all three live
   * in www/js/dev-config.js). The release preflight fails the build if either
   * consent-debug value is set, so a shipped build can never take this path.
   * Returns undefined -> requestConsentInfo() keeps its original call shape. */
  var GEO = { EEA: 1, NOT_EEA: 2 };  // AdmobConsentDebugGeography
  function consentOpts() {
    try {
      if (typeof DEV_MODE === 'undefined' || !DEV_MODE) return undefined;
      if (typeof CONSENT_DEBUG_GEOGRAPHY === 'undefined') return undefined;
      var geo = GEO[CONSENT_DEBUG_GEOGRAPHY];
      if (!geo) return undefined;
      var ids = (typeof CONSENT_TEST_DEVICES !== 'undefined' && CONSENT_TEST_DEVICES) || [];
      if (!ids.length) return undefined;
      console.warn('[ads] UMP debug geography:', CONSENT_DEBUG_GEOGRAPHY);
      return { debugGeography: geo, testDeviceIdentifiers: ids };
    } catch (e) { return undefined; }  // fail-safe: never break init
  }

  /* ---------- init: SDK + UMP consent + (conditionally) preload ---------- */

  function init() {
    if (FAKE) {
      state = ST.FAKE;
      interstitialReady = true;
      rewardedReady = true;
      notifyReady();
      return Promise.resolve();
    }
    if (!isNative()) { state = ST.UNAVAILABLE; return Promise.resolve(); }
    plugin = window.Capacitor.Plugins.AdMob;
    return runConsentAndInit();
  }

  function runConsentAndInit() {
    state = ST.INITIALIZING;
    var devices = AD_CONFIG.testingDevices || [];
    return plugin.initialize({
      initializeForTesting: devices.length > 0 || AD_CONFIG.isTesting,
      testingDevices: devices,
      /* Loop Dodge is NOT child-directed: the Google Play target audience is
       * 13+ and the App Store rating is 4+ but the app is not in the Kids
       * category. COPPA (tagForChildDirectedTreatment) and TFUA
       * (tagForUnderAgeOfConsent) are therefore declared FALSE on purpose
       * rather than left unspecified, so the decision is auditable here.
       * Ad content is capped at ParentalGuidance ("PG") to match those
       * ratings — an ad rated Teen/Mature inside a 4+ app is a store-policy
       * mismatch. (Android maps false -> TAG_..._FALSE; iOS treats false as
       * a no-op, i.e. unspecified. Both are correct for this app.) */
      tagForChildDirectedTreatment: false,
      tagForUnderAgeOfConsent: false,
      maxAdContentRating: 'ParentalGuidance'
    })
      .then(function () { return plugin.requestConsentInfo(consentOpts()); })
      .then(rememberConsent)
      .then(function (info) {
        var d = evalConsent(info);
        privacyRequired = d.privacyRequired;
        // Show the consent form only where UMP says it's required + available,
        // then RE-QUERY so the decision reflects the user's choice.
        if (d.needForm) {
          return plugin.showConsentForm()
            .then(function () { return plugin.requestConsentInfo(consentOpts()); })
            .then(rememberConsent)
            .then(function (info2) {
              var d2 = evalConsent(info2);
              privacyRequired = privacyRequired || d2.privacyRequired;
              return d2;
            });
        }
        return d;
      })
      .then(function (d) {
        if (d.ok && d.canRequestAds) {
          retries = 0;
          state = ST.READY;
          if (!wired) { wireEvents(); wired = true; }
          if (!AD_CONFIG.rewardedOnly) loadInterstitial(); // reward-only: skip interstitials entirely
          loadRewarded();
        } else if (d.ok) {
          // Consent genuinely not obtained (REQUIRED w/o form, or declined):
          // do NOT request ads. Not an error — just no ads this session.
          state = ST.CONSENT_REQUIRED;
        } else {
          // Malformed consent info: treat as a transient failure.
          fail('consent info unavailable');
        }
      })
      .catch(function (e) {
        // initialize / requestConsentInfo / showConsentForm rejected. CRUCIAL:
        // never fall through to loading ads on a swallowed error.
        fail(e);
      });
  }

  function fail(why) {
    state = ST.FAILED;
    invalidateLoads();
    recordError('initialize-or-consent', why);
    if (retries < MAX_RETRIES) {
      retries++;
      setTimeout(function () { if (state === ST.FAILED) runConsentAndInit(); }, RETRY_MS);
    }
  }

  /* Settings action: let the user revisit consent where required. */
  function showPrivacyOptions() {
    if (FAKE || !plugin) return Promise.resolve(false);
    var fn = plugin.showPrivacyOptionsForm || plugin.showConsentForm;
    if (typeof fn !== 'function') return Promise.resolve(false);
    if (rwActive || intActive) return Promise.resolve(false);
    // A previously loaded ad must not survive changed consent preferences.
    invalidateLoads();
    state = ST.INITIALIZING;
    return fn.call(plugin)
      .then(function () { return plugin.requestConsentInfo(consentOpts()); })
      .then(rememberConsent)
      .then(function (info) {
        var d = evalConsent(info);
        privacyRequired = d.privacyRequired;
        if (d.canRequestAds && state !== ST.READY) {
          state = ST.READY;
          if (!wired) { wireEvents(); wired = true; }
          if (!AD_CONFIG.rewardedOnly) loadInterstitial(); // reward-only: skip interstitials entirely
          loadRewarded();
        } else if (!d.canRequestAds) {
          // consent revoked: stop serving ads
          state = ST.CONSENT_REQUIRED;
          interstitialReady = false;
          rewardedReady = false;
        }
        return true;
      })
      .catch(function (error) { fail(error); return false; });
  }

  function wireEvents() {
    plugin.addListener(EV.intShowed,     function () {
      var o = intActive; if (o && o.timer) { clearTimeout(o.timer); o.timer = setTimeout(function () { settleInterstitial(o); }, STUCK_AD_MS); }
    });
    plugin.addListener(EV.intDismissed,  function () { settleInterstitial(intActive); });
    plugin.addListener(EV.intFailedShow, function (error) { recordError('interstitial-show', error); settleInterstitial(intActive); });
    plugin.addListener(EV.intFailedLoad, function (error) { recordError('interstitial-load', error); });
    plugin.addListener(EV.rwShowed,      function () {
      var o = rwActive; if (o && o.timer) { clearTimeout(o.timer); o.timer = setTimeout(function () { settleRewarded(o, o.granted); }, STUCK_AD_MS); }
    });
    plugin.addListener(EV.rwRewarded,    function () { if (rwActive && !rwActive.settled) rwActive.granted = true; });
    plugin.addListener(EV.rwDismissed,   function () { settleRewarded(rwActive, rwActive && rwActive.granted); });
    plugin.addListener(EV.rwFailedShow,  function (error) { recordError('rewarded-show', error); settleRewarded(rwActive, false); });
    plugin.addListener(EV.rwFailedLoad,  function (error) { recordError('rewarded-load', error); });
  }

  /* ---------- loading (gated on consent; quiet retry) ---------- */

  function loadInterstitial() {
    if (state !== ST.READY || AD_CONFIG.rewardedOnly || intLoading || interstitialReady || intActive) return;
    intLoading = true;
    var generation = loadGeneration;
    plugin.prepareInterstitial(adOptions(interstitialUnit()))
      .then(function () {
        intLoading = false;
        if (generation !== loadGeneration) { loadInterstitial(); return; }
        interstitialReady = state === ST.READY;
      })
      .catch(function (error) {
        intLoading = false;
        if (generation !== loadGeneration) { loadInterstitial(); return; }
        recordError('interstitial-load', error);
        intRetry = setTimeout(function () { intRetry = null; loadInterstitial(); }, RELOAD_MS);
      });
  }

  function loadRewarded() {
    if (state !== ST.READY || rwLoading || rewardedReady || rwActive) return;
    rwLoading = true;
    var generation = loadGeneration;
    plugin.prepareRewardVideoAd(adOptions(rewardedUnit()))
      .then(function () {
        rwLoading = false;
        if (generation !== loadGeneration) { loadRewarded(); return; }
        rewardedReady = state === ST.READY;
        if (rewardedReady) notifyReady();
      })
      .catch(function (error) {
        rwLoading = false;
        if (generation !== loadGeneration) { loadRewarded(); return; }
        recordError('rewarded-load', error);
        rwRetry = setTimeout(function () { rwRetry = null; loadRewarded(); }, RELOAD_MS);
      });
  }

  /* ---------- interstitial ---------- */

  function settleInterstitial(offer) {
    if (!offer || offer.settled || offer !== intActive) return;
    offer.settled = true;
    if (offer.timer) { clearTimeout(offer.timer); offer.timer = null; }
    intActive = null;
    offer.resolve();
    loadInterstitial(); // preload the next one
  }

  function showInterstitial() {
    // Reward-only is a SHIPPED promise (store listing + privacy policy): refuse
    // at this boundary, not only at the preload gate and the callers.
    if (AD_CONFIG.rewardedOnly) return Promise.resolve();
    // "Remove ads" IAP kills interstitials forever (rewarded revive stays).
    if (Store.getAdsRemoved()) return Promise.resolve();
    if (FAKE) return fakeAd('interstitial').then(function () {});
    if (state !== ST.READY || !interstitialReady) return Promise.resolve();
    interstitialReady = false;
    intSeq++;
    var offer = { seq: intSeq, settled: false, resolve: null, timer: null };
    intActive = offer;
    var p = new Promise(function (resolve) { offer.resolve = resolve; });
    offer.timer = setTimeout(function () { settleInterstitial(offer); }, NEVER_SHOWED_MS);
    plugin.showInterstitial().catch(function (error) { recordError('interstitial-show', error); settleInterstitial(offer); });
    return p;
  }

  /* ---------- rewarded ---------- */

  function settleRewarded(offer, granted) {
    if (!offer || offer.settled || offer !== rwActive) return;
    offer.settled = true;
    if (offer.timer) { clearTimeout(offer.timer); offer.timer = null; }
    rwActive = null;
    offer.resolve(!!granted);
    loadRewarded();
  }

  /* Resolves true only if the user earned the reward. */
  function showRewarded() {
    if (FAKE) return fakeAd('rewarded').then(function () { return true; });
    if (state !== ST.READY || !rewardedReady) return Promise.resolve(false);
    rewardedReady = false;
    rwSeq++;
    var offer = { seq: rwSeq, granted: false, settled: false, resolve: null, timer: null };
    rwActive = offer;
    var p = new Promise(function (resolve) { offer.resolve = resolve; });
    offer.timer = setTimeout(function () { settleRewarded(offer, offer.granted); }, NEVER_SHOWED_MS);
    plugin.showRewardVideoAd().catch(function (error) { recordError('rewarded-show', error); settleRewarded(offer, false); });
    return p;
  }

  /* ?fakeads=1 browser stub: brief black flash standing in for an ad. */
  function fakeAd(kind) {
    return new Promise(function (resolve) {
      var div = document.createElement('div');
      div.style.cssText = 'position:fixed;inset:0;background:#000;color:#fff;' +
        'display:flex;align-items:center;justify-content:center;z-index:99;' +
        'font:700 18px system-ui;letter-spacing:.2em';
      div.textContent = '[ fake ' + kind + ' ad ]';
      document.body.appendChild(div);
      setTimeout(function () { div.remove(); resolve(); }, 900);
    });
  }

  return {
    init: init,
    showInterstitial: showInterstitial,
    showRewarded: showRewarded,
    isRewardedReady: function () { return FAKE || (state === ST.READY && rewardedReady); },
    onRewardedReady: function (fn) { readyCb = fn; },
    /* consent / settings surface */
    getState: function () { return state; },
    getDiagnostics: getDiagnostics,
    canRequestAds: function () { return FAKE || state === ST.READY; },
    isPrivacyOptionsRequired: function () { return privacyRequired; },
    showPrivacyOptions: showPrivacyOptions,
    /* test/internal hooks */
    _evalConsent: evalConsent,
    STATES: ST
  };
})();
