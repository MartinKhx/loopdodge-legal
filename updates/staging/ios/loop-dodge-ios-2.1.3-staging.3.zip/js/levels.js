/* Levels: each one changes the SHAPE of the track, costs gems to
 * unlock (spent, like skins), and multiplies every gem you collect.
 *
 * A shape is a closed polar curve r(theta) normalized so its maximum
 * is 1.0 — the whole engine (spawning, fairness, collision) stays
 * angle-based and works on any shape unchanged. Harder shapes pay
 * more per gem. */
var Levels = (function () {
  var TAU = Math.PI * 2;

  /* gentle oval: radius swings with cos(2t) */
  function oval(amp) {
    return function (t) { return (1 + amp * Math.cos(2 * t)) / (1 + amp); };
  }

  /* flower / wavy ring with n lobes */
  function flower(lobes, amp) {
    return function (t) { return (1 + amp * Math.cos(lobes * t)) / (1 + amp); };
  }

  /* regular polygon with n sides, softened toward a circle.
   * sharp = 1 is the exact polygon, 0 is a circle. */
  function polygon(sides, sharp) {
    var seg = Math.PI / sides;
    return function (t) {
      var a = ((t % (2 * seg)) + 2 * seg) % (2 * seg) - seg;
      var r = Math.cos(seg) / Math.cos(a); // exact polygon, max 1 at corners
      return 1 + (r - 1) * sharp;
    };
  }

  /* an asymmetric throat ("gullet"): an egg pinched on one side, max 1 at t=0. */
  function gullet() {
    return function (t) {
      return (1 + 0.17 * Math.cos(2 * t) + 0.11 * Math.cos(t)) / 1.28;
    };
  }

  /* n-pointed star: sharp tips at r=1 alternating with sharp valleys at
   * r=1-depth (a triangle wave on the radius, via asin(cos)). Keep depth<=0.4
   * so the inner lane never approaches the centre. */
  function star(points, depth) {
    return function (t) {
      var tri = (2 / Math.PI) * Math.asin(Math.cos(points * t)); // +1 tips, -1 valleys
      return 1 - depth * (0.5 - 0.5 * tri);
    };
  }

  /* teardrop / comet: a sharp tip at t=0 easing back to a round base at t=PI.
   *
   * The previous version used (0.5 + 0.5*cos t)^1.6, which is dominated by a
   * cos(t) first harmonic — i.e. a TRANSLATION. Measured from its own
   * centroid it was 94% uniform: not a teardrop at all, just a circle drawn
   * off to the right, which is exactly how it looked in play. This builds the
   * taper from |t| instead, so the tip is a real geometric feature that
   * survives re-centring. The sub-1 exponent puts a genuine cusp at t=0.
   *
   * depth/power are tuned to keep the lurch (max|v|/min|v| at constant
   * angular rate) at 1.66 once re-centred — just under Eye at 1.69 and well
   * inside the shipped band, whose ceiling is Tri at 2.41. Deeper tapers were
   * measured and rejected: 0.55/0.65 reaches 2.47, past Tri. */
  function teardrop(depth, power) {
    return function (t) {
      // 0 at the tip (t=0), 1 at the base (t=PI), symmetric about the axis
      var u = Math.abs((((t + Math.PI) % TAU) + TAU) % TAU - Math.PI) / Math.PI;
      return 1 - depth * Math.pow(u, power);
    };
  }

  /* lens / eye: two sharp points at t=0 and t=PI, pinched at the sides. */
  function lens(depth) {
    return function (t) {
      var u = 0.5 + 0.5 * Math.cos(2 * t);      // 1 at the two points, 0 at the sides
      return (1 - depth) + depth * Math.pow(u, 1.8);
    };
  }

  /* prism / crystal: a faceted, irregular gem from three stacked harmonics
   * (normalized so the aligned peak at t=0 is exactly 1, trough 0.6 at t=PI). */
  function prism() {
    return function (t) {
      return (1 + 0.12 * Math.cos(3 * t) + 0.08 * Math.cos(5 * t)
                + 0.05 * Math.cos(7 * t)) / 1.25;
    };
  }

  /* Re-centre a polar shape on its own centroid.
   *
   * A cos(t) term in r(theta) is NOT asymmetry — in polar coordinates it is
   * exactly a translation along x. Gullet and Comet each carry one, so their
   * tracks sat visibly right of screen centre (10% and 21% of their own
   * radius). Dropping the term would destroy both silhouettes, so instead the
   * curve is translated back onto its centroid and resampled into a lookup
   * table: identical shape, centred, and O(1) to read per frame.
   *
   * Valid because both curves stay star-shaped about the new origin — the
   * offset is far smaller than the minimum radius — so every ray from the
   * centre still meets the outline exactly once. The max-is-1 normalization
   * contract the engine relies on is restored at the end. */
  function recenter(fn, samples) {
    var N = samples || 1440, i, t, r;
    var area = 0, ix = 0, iy = 0;
    for (i = 0; i < N; i++) {
      t = (i / N) * TAU; r = fn(t);
      area += r * r;
      ix += r * r * r * Math.cos(t);
      iy += r * r * r * Math.sin(t);
    }
    var cx = (2 / 3) * ix / area, cy = (2 / 3) * iy / area;

    // the translated outline, expressed in polar about the new origin
    var pts = [];
    for (i = 0; i < N; i++) {
      t = (i / N) * TAU; r = fn(t);
      var x = r * Math.cos(t) - cx, y = r * Math.sin(t) - cy;
      pts.push([Math.atan2(y, x), Math.sqrt(x * x + y * y)]);
    }
    pts.sort(function (p, q) { return p[0] - q[0]; });
    pts.push([pts[0][0] + TAU, pts[0][1]]); // wrap sentinel for the seam

    // resample onto a uniform angle grid so playback is a plain array read
    var tbl = new Array(N), maxR = 0, j = 0;
    for (i = 0; i < N; i++) {
      var ang = -Math.PI + (i / N) * TAU;
      while (j < pts.length - 2 && pts[j + 1][0] < ang) j++;
      var p0 = pts[j], p1 = pts[j + 1];
      var span = p1[0] - p0[0];
      var k = span > 1e-9 ? (ang - p0[0]) / span : 0;
      k = k < 0 ? 0 : (k > 1 ? 1 : k);
      tbl[i] = p0[1] + (p1[1] - p0[1]) * k;
      if (tbl[i] > maxR) maxR = tbl[i];
    }
    for (i = 0; i < N; i++) tbl[i] /= maxR;

    return function (t2) {
      var u = (((t2 + Math.PI) % TAU) + TAU) % TAU; // -> [0, TAU)
      var f = (u / TAU) * N, i0 = Math.floor(f), frac = f - i0;
      var v0 = tbl[i0 % N], v1 = tbl[(i0 + 1) % N];
      return v0 + (v1 - v0) * frac;
    };
  }

  /* Each track carries a small `tuning` object — its gameplay
   * personality — read by the engine through tune() with safe
   * defaults, so a track is data, never an `if (level.id === ...)`
   * in game.js. Only fairness-neutral scalars are allowed:
   *   gemChance  added chance a spawn is a gem (not a spike)
   *   powerBias  added chance a gem slot becomes a power-up
   *   magnetBias chance a power-up roll is forced to magnet
   *   feastBias  chance a power-up roll is forced to feast
   *   pulserBias added chance a spike spawns as a pulser
   * RETIRED — `gemBonus` (a flat add to every gem's value). The engine still
   * reads it, but no track may set it again: it made the number on the badge
   * a lie. Prism advertised x20 and paid 21, Tri x6 paid 7, Clover x12 paid
   * 14. It cannot simply be folded into `mult` either — 12+2 collides with
   * Star's 14 and 6+1 with Gullet's 7, breaking the strictly-ascending
   * ladder. So the value moved into `gemChance` (more gems appear) and the
   * multiplier is now exactly what one gem pays. Pinned by
   * content-integrity.test.js.
   * (Speed or spawn-floor modifiers are deliberately NOT supported —
   * they would touch the fairness clock. magnetBias + feastBias share the
   * same roll, so a track sets at most one of them high.) `desc` is the
   * one-word personality line under the track name in the menu. */
  var LIST = [
    { id: 'loop',  name: 'Loop',  cost: 0,    mult: 1, r: function () { return 1; },
      desc: 'classic',  tuning: {} },
    { id: 'orbit', name: 'Orbit', cost: 100,  mult: 2, r: oval(0.10),
      desc: '+gems',    tuning: { gemChance: 0.04 } },
    { id: 'hex',   name: 'Hex',   cost: 300,  mult: 3, r: polygon(6, 1),
      desc: '+gems',    tuning: { gemChance: 0.05 } },
    { id: 'box',   name: 'Box',   cost: 700,  mult: 4, r: polygon(4, 0.85),
      desc: '+power-ups', tuning: { powerBias: 0.05 } },
    { id: 'bloom', name: 'Bloom', cost: 1200, mult: 5, r: flower(5, 0.10),
      desc: 'magnets',  tuning: { magnetBias: 0.45 } },
    { id: 'tri',   name: 'Tri',   cost: 2000, mult: 6, r: polygon(3, 0.7),
      desc: '+gems',    tuning: { gemChance: 0.05 } },
    { id: 'gullet', name: 'Gullet', cost: 3000, mult: 7, r: recenter(gullet()),
      desc: 'feasts',   tuning: { feastBias: 0.4 } },
    { id: 'shard', name: 'Shard', cost: 4500, mult: 8, r: polygon(5, 0.9),
      desc: '+power-ups', tuning: { powerBias: 0.06 } },
    /* ---- deep tracks: distinct silhouettes + bolder personalities ----
     * Cog (12-tooth gear) and Vortex (pinwheel) were cut after a per-map
     * playability audit: the gear seated ~40% of its spikes on tooth corners
     * and both lurched the ball hardest (radial-speed swing 3.6x / 2.2x vs a
     * circle's 1.0). The survivors keep mult ~= 0.124*sqrt(cost) and re-space
     * to a smooth 10 -> 12 -> 14 -> 17 -> 20 ladder (no gaps from the cuts). */
    { id: 'comet',  name: 'Comet',  cost: 6000,  mult: 10, r: recenter(teardrop(0.45, 0.70)),
      desc: '+gems',         tuning: { gemChance: 0.06 } },
    { id: 'clover', name: 'Clover', cost: 9000,  mult: 12, r: flower(3, 0.25),
      desc: '+gems',         tuning: { gemChance: 0.07 } },
    { id: 'star',   name: 'Star',   cost: 13000, mult: 14, r: star(5, 0.38),
      desc: 'magnets+',      tuning: { magnetBias: 0.5 } },
    { id: 'eye',    name: 'Eye',    cost: 18500, mult: 17, r: lens(0.4),
      desc: 'magnets+',      tuning: { magnetBias: 0.55 } },
    { id: 'prism',  name: 'Prism',  cost: 26000, mult: 20, r: prism(),
      desc: 'rich gems',     tuning: { gemChance: 0.08 } }
  ];

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) {
      if (LIST[i].id === id) return LIST[i];
    }
    return LIST[0];
  }

  function isOwned(id) {
    var l = byId(id);
    return l.cost === 0 || Store.getOwnedLevels().indexOf(l.id) !== -1;
  }

  /* Spend gems to unlock. Returns true on success. */
  function buy(id) {
    var l = byId(id);
    if (isOwned(l.id)) return true;
    var gems = Store.getGems();
    if (gems < l.cost) return false;
    Store.setGems(gems - l.cost);
    var owned = Store.getOwnedLevels();
    owned.push(l.id);
    Store.setOwnedLevels(owned);
    return true;
  }

  function current() { return byId(Store.getLevel()); }

  return { LIST: LIST, byId: byId, isOwned: isOwned, buy: buy, current: current };
})();
