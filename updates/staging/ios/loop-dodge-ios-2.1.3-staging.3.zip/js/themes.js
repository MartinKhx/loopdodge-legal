/* Visual themes ("worlds"): a selectable art direction for the whole
 * game — background, ring, spikes, gems, storm and particle palette,
 * plus structural style flags the renderer branches on. Picking a theme
 * is like picking a skin or trail; it changes the LOOK only, never the
 * gameplay, spawn stream, or fairness (so the seeded daily stays
 * byte-identical across themes).
 *
 * Division of labor that keeps the cosmetic economy intact:
 *   - the THEME owns the world: bg, ring color/shape, danger (spike/
 *     pulser) and reward (gem) hues, storm/slow washes, structural
 *     extras (ball tendrils, lure bulbs, comet tail, embers, scanlines).
 *   - the equipped SKIN still tints the BALL (and, on Classic, the ring),
 *     so every skin stays meaningful inside any world.
 *
 * Colors are read by game.js through curTheme.c.* (assigned once at
 * select/resize — never built per frame). Style flags (bg/ringStyle/
 * spikeStyle/gemStyle/ballExtra/stormStyle) pick which draw branch runs.
 */
var Themes = (function () {

  var LIST = [
    {
      id: 'classic', name: 'Classic',
      bg: 'space', ringStyle: 'tube', ringTint: null /* = equipped skin */,
      ballExtra: 'none', spikeStyle: 'blade', gemStyle: 'diamond', stormStyle: 'wash',
      c: {
        bgInner: '#0d1322', bgOuter: '#05080f', star: '#bcd2ff',
        spike: '#ff3355', spikeHalo: 'rgba(255,51,85,0.28)', spikeTip: '#ff6b85',
        gem: '#2bffc8', gemCore: '#eafffb', gemHalo: 'rgba(43,255,200,0.25)',
        pulser: '#ff9e2e',
        storm: 'rgb(255,45,70)', slow: 'rgb(120,70,220)',
        spark: '#ffffff', ringReact: '#bcd2ff', vignette: 'rgba(0,0,0,0.45)'
      }
    },

    {
      id: 'hadal', name: 'Hadal Bloom',
      bg: 'abyss', ringStyle: 'coral', ringTint: '#0bd4d0',
      ballExtra: 'tendrils', spikeStyle: 'thornLure', gemStyle: 'spore', stormStyle: 'bloom',
      c: {
        bgInner: '#06182b', bgOuter: '#02060d', star: '#7af0c8',
        spike: '#1a0810', spikeHalo: 'rgba(255,77,109,0.30)', spikeTip: '#ff4d6d',
        gem: '#7af0c8', gemCore: '#eafffb', gemHalo: 'rgba(122,240,200,0.22)',
        pulser: '#ff9a3c',
        storm: 'rgb(255,77,109)', slow: 'rgb(185,140,255)',
        spark: '#7af0c8', ringReact: '#7af0c8', vignette: 'rgba(0,4,9,0.6)'
      }
    },

    {
      id: 'cosmic', name: 'Cosmic Aurora',
      bg: 'aurora', ringStyle: 'ribbon', ringTint: '#1bc6c0',
      ballExtra: 'comet', spikeStyle: 'iceTip', gemStyle: 'ice', stormStyle: 'ignition',
      c: {
        bgInner: '#0e1c3a', bgOuter: '#070b1a', star: '#5f7bff',
        nebulaA: 'rgba(27,198,192,0.08)', nebulaB: 'rgba(176,123,255,0.08)',
        ringA: '#1bc6c0', ringB: '#5f7bff', ringC: '#b07bff',
        spike: '#ff5b6e', spikeHalo: 'rgba(255,91,110,0.28)', spikeTip: '#ffd27a',
        gem: '#1bc6c0', gemCore: '#eafffb', gemHalo: 'rgba(27,198,192,0.22)',
        pulser: '#ff5b6e',
        storm: 'rgb(255,91,110)', slow: 'rgb(176,123,255)',
        spark: '#ffd27a', ringReact: '#ffffff', vignette: 'rgba(0,2,12,0.5)'
      }
    },

    {
      id: 'ember', name: 'Emberfall',
      bg: 'molten', ringStyle: 'molten', ringTint: '#ff7a18',
      ballExtra: 'plasma', spikeStyle: 'obsidian', gemStyle: 'drop', stormStyle: 'flare',
      c: {
        bgInner: '#3d0f06', bgOuter: '#1a0602', coreGlow: '#ff7a18', star: '#ff9e2e',
        spike: '#9c2a0a', spikeHalo: 'rgba(255,122,24,0.35)', spikeTip: '#ffec9e',
        gem: '#ffd24a', gemCore: '#ffec9e', gemHalo: 'rgba(255,122,24,0.25)',
        pulser: '#ffec9e',
        storm: 'rgb(255,180,90)', slow: 'rgb(43,214,255)',
        spark: '#ffec9e', ringReact: '#ffec9e', vignette: 'rgba(20,3,1,0.55)'
      }
    },

    {
      id: 'neon', name: 'Neon Horizon',
      bg: 'synth', ringStyle: 'chrome', ringTint: '#ff2d95',
      ballExtra: 'none', spikeStyle: 'laser', gemStyle: 'crystal', stormStyle: 'scanlines',
      c: {
        bgInner: '#3a1150', bgOuter: '#1a0b2e', star: '#ffffff',
        sunTop: '#ffe14d', sunMid: '#ff7a18', sunLow: '#ff2d95', grid: '#ff2d95', gridAccent: '#00e5ff',
        spike: '#ff2d95', spikeHalo: 'rgba(255,45,149,0.30)', spikeTip: '#ffffff',
        gem: '#00e5ff', gemCore: '#ffffff', gemHalo: 'rgba(0,229,255,0.25)',
        pulser: '#ff7a18',
        storm: 'rgb(255,45,149)', slow: 'rgb(177,77,255)',
        spark: '#00e5ff', ringReact: '#00e5ff', vignette: 'rgba(10,4,24,0.5)'
      }
    },

    {
      id: 'verdant', name: 'Verdant',
      bg: 'abyss', ringStyle: 'coral', ringTint: '#3ad17a',
      ballExtra: 'tendrils', spikeStyle: 'thornLure', gemStyle: 'spore', stormStyle: 'bloom',
      c: {
        bgInner: '#0a2615', bgOuter: '#030f08', star: '#aef0a0',
        spike: '#10240f', spikeHalo: 'rgba(120,255,90,0.30)', spikeTip: '#9cff5a',
        gem: '#7af0a0', gemCore: '#eafff0', gemHalo: 'rgba(122,240,160,0.22)',
        pulser: '#ffd23c',
        storm: 'rgb(120,255,90)', slow: 'rgb(120,200,255)',
        spark: '#aef0a0', ringReact: '#7af0a0', vignette: 'rgba(0,9,4,0.6)'
      }
    },

    {
      id: 'caldera', name: 'Caldera',
      bg: 'molten', ringStyle: 'molten', ringTint: '#ff4d18',
      ballExtra: 'plasma', spikeStyle: 'obsidian', gemStyle: 'drop', stormStyle: 'flare',
      c: {
        bgInner: '#2a0820', bgOuter: '#10020c', coreGlow: '#ff2d6a', star: '#ff8cc0',
        spike: '#1a0510', spikeHalo: 'rgba(255,45,106,0.35)', spikeTip: '#ffd24a',
        gem: '#ffcf3d', gemCore: '#fff1c0', gemHalo: 'rgba(255,45,106,0.25)',
        pulser: '#ffd24a',
        storm: 'rgb(255,90,140)', slow: 'rgb(120,180,255)',
        spark: '#ffd24a', ringReact: '#ffd24a', vignette: 'rgba(12,1,8,0.55)'
      }
    },

    {
      id: 'vapor', name: 'Vaporwave',
      bg: 'synth', ringStyle: 'chrome', ringTint: '#00e5ff',
      ballExtra: 'none', spikeStyle: 'laser', gemStyle: 'crystal', stormStyle: 'scanlines',
      c: {
        bgInner: '#1a0b3a', bgOuter: '#0b0820', star: '#ffffff',
        sunTop: '#ffe14d', sunMid: '#ff5db0', sunLow: '#00e5ff', grid: '#00e5ff', gridAccent: '#ff5db0',
        spike: '#00e5ff', spikeHalo: 'rgba(0,229,255,0.30)', spikeTip: '#ffffff',
        gem: '#ff5db0', gemCore: '#ffffff', gemHalo: 'rgba(255,93,176,0.25)',
        pulser: '#ffe14d',
        storm: 'rgb(0,229,255)', slow: 'rgb(177,77,255)',
        spark: '#ff5db0', ringReact: '#ff5db0', vignette: 'rgba(6,4,20,0.5)'
      }
    },

    {
      // The Oracle's own world: violet + gold over a deep void — the signature
      // v10 palette. Reuses Cosmic's aurora/ribbon/ice draw branches.
      id: 'oracle', name: 'The Oracle',
      bg: 'aurora', ringStyle: 'ribbon', ringTint: '#b58cff',
      ballExtra: 'comet', spikeStyle: 'iceTip', gemStyle: 'ice', stormStyle: 'ignition',
      c: {
        bgInner: '#1a0e2e', bgOuter: '#0a0518', star: '#c9a8ff',
        nebulaA: 'rgba(181,140,255,0.10)', nebulaB: 'rgba(255,210,74,0.06)',
        ringA: '#b58cff', ringB: '#7a4dd6', ringC: '#ffd24a',
        spike: '#ff5a8a', spikeHalo: 'rgba(255,90,138,0.30)', spikeTip: '#ffd27a',
        gem: '#c9a8ff', gemCore: '#f0e6ff', gemHalo: 'rgba(201,168,255,0.24)',
        pulser: '#ff8cc0',
        storm: 'rgb(181,140,255)', slow: 'rgb(122,77,214)',
        spark: '#ffd27a', ringReact: '#e8d8ff', vignette: 'rgba(4,2,12,0.55)'
      }
    },

    {
      // Frozen world: icy whites + cyan. Reuses Cosmic's aurora/ribbon/ice draws.
      id: 'tundra', name: 'Tundra',
      bg: 'aurora', ringStyle: 'ribbon', ringTint: '#8fe6ff',
      ballExtra: 'comet', spikeStyle: 'iceTip', gemStyle: 'ice', stormStyle: 'ignition',
      c: {
        bgInner: '#0a2030', bgOuter: '#04101a', star: '#cdefff',
        nebulaA: 'rgba(143,230,255,0.08)', nebulaB: 'rgba(122,240,200,0.06)',
        ringA: '#8fe6ff', ringB: '#5fbfe0', ringC: '#bfeeff',
        spike: '#3a7090', spikeHalo: 'rgba(143,230,255,0.30)', spikeTip: '#ffffff',
        gem: '#7af0c8', gemCore: '#eafffb', gemHalo: 'rgba(122,240,200,0.22)',
        pulser: '#9ad9ff',
        storm: 'rgb(143,230,255)', slow: 'rgb(120,180,255)',
        spark: '#ffffff', ringReact: '#cdefff', vignette: 'rgba(0,6,12,0.5)'
      }
    },

    {
      // Accessibility theme: maximum luminance contrast on pure black, with a
      // blue/yellow/cyan palette chosen to stay distinguishable for the common
      // red-green color-vision deficiencies. Reuses Classic's well-supported
      // structural draw branches.
      id: 'contrast', name: 'High Contrast',
      bg: 'space', ringStyle: 'tube', ringTint: '#ffffff',
      ballExtra: 'none', spikeStyle: 'blade', gemStyle: 'diamond', stormStyle: 'wash',
      c: {
        bgInner: '#000000', bgOuter: '#000000', star: '#ffffff',
        spike: '#ffd400', spikeHalo: 'rgba(255,212,0,0.45)', spikeTip: '#ffffff',
        gem: '#00d4ff', gemCore: '#ffffff', gemHalo: 'rgba(0,212,255,0.40)',
        pulser: '#ff8800',
        storm: 'rgb(255,212,0)', slow: 'rgb(0,150,255)',
        spark: '#ffffff', ringReact: '#ffffff', vignette: 'rgba(0,0,0,0.2)'
      }
    }
  ];

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) if (LIST[i].id === id) return LIST[i];
    return LIST[0];
  }

  function current() { return byId(Store.getTheme()); }

  /* All themes are free to select — they're a customization choice, not
   * a grind. (A cost field could gate them later like skins/tracks.) */
  function isOwned() { return true; }
  function select(id) { Store.setTheme(byId(id).id); }

  return { LIST: LIST, byId: byId, current: current, isOwned: isOwned, select: select };
})();
