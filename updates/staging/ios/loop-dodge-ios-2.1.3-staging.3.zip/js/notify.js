/* Streak-saver local notification (@capacitor/local-notifications),
 * wrapped fail-safe: in a browser, without the plugin, without
 * permission, or on any error every call silently no-ops.
 *
 * Discipline (the retention channel must never feel like spam):
 *   - ONE pending notification, ever (fixed id, rescheduling replaces).
 *   - Permission is requested only once, and only at a clear moment of
 *     value: the player claiming a day-2+ streak reward. Never at
 *     first launch.
 *   - Scheduled ~20h after the app backgrounds on a day whose reward
 *     was claimed ("Day N is waiting — keep your streak!"), cancelled
 *     the moment the player comes back or claims.
 *   - Inexact timing only: a daily nudge never justifies the exact-
 *     alarm permission Play restricts. */
var Notify = (function () {

  var NOTIF_ID = 7001;
  var REMIND_AFTER_H = 20;

  function plugin() {
    try {
      if (window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' &&
          window.Capacitor.isNativePlatform() &&
          window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) {
        return window.Capacitor.Plugins.LocalNotifications;
      }
    } catch (e) { /* optional */ }
    return null;
  }

  /* Ask for notification permission, once per install. Called from
   * the daily-streak claim flow at day 2+ (the moment the streak has
   * demonstrated value), never at first launch. */
  function requestPermissionOnce() {
    var p = plugin();
    if (!p || Store.getNotifAsked()) return;
    Store.setNotifAsked(true);
    try { p.requestPermissions().catch(function () {}); } catch (e) { /* optional */ }
  }

  /* App going to the background: if today's streak reward is already
   * claimed, line up tomorrow's nudge. (If it isn't claimed, the
   * player already has something waiting — stay quiet.) */
  function scheduleStreakReminder() {
    var p = plugin();
    if (!p || !Store.getNotifAsked()) return;
    try {
      if (Store.getStreakLast() !== Daily.todayStr()) return;
      var day = Math.min(Store.getStreakDay() + 1, 7);
      var gems = Daily.STREAK_GEMS[day - 1];
      /* Fire ~20h out, but never before the next local midnight —
       * the reward only becomes claimable when the calendar day
       * flips, and a post-midnight session would otherwise get a
       * same-day "reward is waiting" that is simply false. */
      var at = Date.now() + REMIND_AFTER_H * 3600 * 1000;
      var nextMid = new Date();
      nextMid.setHours(24, 0, 0, 0);
      var earliest = nextMid.getTime() + 10 * 3600 * 1000; // ≥10:00 next day
      if (at < earliest) at = earliest;
      p.checkPermissions().then(function (s) {
        if (!s || s.display !== 'granted') return;
        p.schedule({
          notifications: [{
            id: NOTIF_ID,
            title: 'Loop Dodge',
            body: 'Day ' + day + ' reward is waiting — ' + gems + ' gems. Keep your streak!',
            schedule: { at: new Date(at) }
          }]
        }).catch(function () {});
      }).catch(function () {});
    } catch (e) { /* notifications are optional */ }
  }

  /* Player is back (or just claimed): no reminder needed. */
  function cancel() {
    var p = plugin();
    if (!p) return;
    try { p.cancel({ notifications: [{ id: NOTIF_ID }] }).catch(function () {}); }
    catch (e) { /* optional */ }
  }

  return {
    requestPermissionOnce: requestPermissionOnce,
    scheduleStreakReminder: scheduleStreakReminder,
    cancel: cancel
  };
})();
