/* Localization. English strings ARE the keys (and the fallback), so any
 * untranslated or brand string simply renders as authored.
 *
 * Resolution order: the player's saved override (Settings > Language),
 * else the device language (navigator.languages / navigator.language),
 * else English. The device language is the closest signal to "the store
 * they downloaded from" that actually exists — storefront is not exposed.
 *
 * Contract:
 * - Pure data + string lookup; touches the DOM only inside applyDom()
 *   (guarded), so the module loads clean in the Node test harness.
 * - NEVER used by the engine (game.js) — localization must not be able
 *   to affect the deterministic sim.
 * - {gem}/{soul} expand to the currency glyph spans; {any} params come
 *   from the caller. Translations are authored, not user input.
 * - Content proper nouns (Loop Dodge, track/skin/theme/relic/warden
 *   names) stay untranslated by design. */
var I18n = (function () {
  var SUPPORTED = ['en', 'es', 'pt', 'fr', 'de', 'it', 'ru', 'ja', 'ko'];
  var NATIVE = {
    en: 'ENGLISH', es: 'ESPAÑOL', pt: 'PORTUGUÊS', fr: 'FRANÇAIS',
    de: 'DEUTSCH', it: 'ITALIANO', ru: 'РУССКИЙ', ja: '日本語', ko: '한국어'
  };

  var D = {};

  D.es = {
    'HOME': 'INICIO', 'GEAR': 'EQUIPO', 'SHOP': 'TIENDA', 'MORE': 'MÁS',
    'TRACKS': 'PISTAS', 'THEMES': 'TEMAS', 'SKINS': 'SKINS', 'TRAILS': 'ESTELAS', 'RELICS': 'RELIQUIAS',
    'PLAY': 'JUGAR', 'DAILY RUN': 'RETO DIARIO',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'infinito · sin perder',
    'beat {n}s · win 100 {gem}': 'supera {n}s · gana 100 {gem}',
    'BEST': 'RÉCORD', 'LV': 'NV', 'MISSIONS': 'MISIONES', 'WIN {gem}{n}': 'GANA {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} GRATIS',
    'watch ad · once a day': 'mira un anuncio · una vez al día',
    'tap to switch lanes · dodge the spikes': 'toca para cambiar de carril · esquiva los pinchos',
    'higher multiplier · more {gem} every run': 'más multiplicador · más {gem} por partida',
    'world colors · free to switch': 'colores del mundo · cambia gratis',
    'unlock with {gem} · sets your glow': 'desbloquea con {gem} · define tu brillo',
    'unlock with {gem} gems': 'desbloquea con gemas {gem}',
    'found in the Descent · attune with {soul}': 'del Descenso · sintoniza con {soul}',
    '{n} worlds': '{n} mundos', '{x}/{y} found': '{x}/{y} halladas',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'Las PISTAS multiplican las {gem} que ganas. TEMAS, SKINS y ESTELAS son solo estilo. Las RELIQUIAS salen de las partidas profundas: el Descenso.',
    'GOT IT': 'VALE', 'SOULS': 'ALMAS', 'SEED': 'SEMILLA',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Las reliquias caen en el DESCENSO: sobrevive hasta lo profundo y elígelas en plena partida. La profundidad también paga las Almas para sintonizarlas.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Toca una reliquia para leer qué hace; toca otra vez para sintonizarla en tu Pacto inicial.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Reliquia sin descubrir (nivel {n}): elígela durante una partida para desbloquearla.',
    'Seeded into your opening Pact — tap again to remove.': 'Sembrada en tu Pacto inicial; toca otra vez para quitarla.',
    'Attuned — tap again to seed it into your Pact.': 'Sintonizada; toca otra vez para sembrarla en tu Pacto.',
    'Tap again to attune for {n} Souls.': 'Toca otra vez para sintonizar por {n} Almas.',
    'Costs {n} Souls to attune (you have {x}).': 'Sintonizar cuesta {n} Almas (tienes {x}).',
    'SEEDED': 'SEMBRADA',
    'classic': 'clásica', '+gems': '+gemas', '+power-ups': '+potenciadores', 'magnets': 'imanes',
    'feasts': 'festines', '+1 ◆/gem': '+1 ◆/gema', '+2 ◆/gem': '+2 ◆/gema', 'magnets+': 'imanes+', 'rich gems': 'gemas ricas',
    'YOU HAVE': 'TIENES',
    '×3 gems from every run — forever': '×3 gemas en cada partida, para siempre',
    '+500 {gem} gift every day': '+500 {gem} de regalo cada día',
    'POPULAR': 'POPULAR', 'BEST VALUE': 'MEJOR PRECIO', 'OWNED': 'TUYO', 'ACTIVE ×3': 'ACTIVO ×3',
    'REMOVE ADS': 'SIN ANUNCIOS',
    'gems are earned every run — plus a free bonus daily': 'ganas gemas en cada partida, más un bono diario gratis',
    'purchases support development': 'las compras apoyan el desarrollo',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass activo: ×3 en todas las gemas ganadas',
    'store unavailable — try again later': 'tienda no disponible; inténtalo más tarde',
    'RESTORE PURCHASES': 'RESTAURAR COMPRAS', 'restoring…': 'restaurando…',
    'restore failed — check your connection and try again': 'falló la restauración: revisa tu conexión e inténtalo de nuevo',
    'purchases restored — thank you!': 'compras restauradas, ¡gracias!',
    'nothing to restore on this account': 'no hay nada que restaurar en esta cuenta',
    'HOW TO PLAY': 'CÓMO JUGAR', 'the run · gems · the Descent': 'la partida · gemas · el Descenso',
    'descent records · seed race': 'récords del Descenso · carrera de semillas',
    'STATS': 'ESTADÍSTICAS', 'lifetime records': 'récords históricos',
    'LEADERBOARD': 'CLASIFICACIÓN', 'compare with the world': 'compárate con el mundo',
    'SETTINGS': 'AJUSTES', 'sound · haptics · accessibility': 'sonido · vibración · accesibilidad',
    'Sound effects': 'Efectos de sonido', 'Music': 'Música', 'Reduce flashing': 'Reducir destellos',
    'Haptics': 'Vibración', 'Reduce motion': 'Reducir movimiento', 'Ghost racer': 'Fantasma rival',
    'Ad privacy options': 'Privacidad de anuncios', 'Delete custom photo': 'Borrar foto propia',
    'Reset all progress': 'Borrar todo el progreso', 'Tap again to ERASE everything': 'Toca otra vez para BORRARLO todo',
    'Language': 'Idioma', 'AUTO': 'AUTO', 'ON': 'SÍ', 'OFF': 'NO', 'FULL': 'FUERTE', 'LIGHT': 'SUAVE',
    'DAILY REWARD': 'PREMIO DIARIO', 'DAY {n}': 'DÍA {n}', 'CLAIM': 'RECLAMAR',
    '▶︎  KEEP STREAK': '▶︎  SALVAR RACHA', 'watch ad': 'mira un anuncio',
    'CUSTOM SKIN': 'SKIN PROPIA', 'turn any photo into your ball': 'convierte cualquier foto en tu bola',
    'UNLOCK {gem}600': 'DESBLOQUEA {gem}600', '▶︎  WATCH AD': '▶︎  VER ANUNCIO',
    'free unlock': 'desbloqueo gratis', 'CANCEL': 'CANCELAR', 'CLOSE': 'CERRAR',
    'SCORE': 'PUNTOS', 'NEW BEST!': '¡NUEVO RÉCORD!',
    'NEAR MISSES': 'ROCES', 'BEST COMBO': 'MEJOR COMBO',
    'DESCENT · SPHERE': 'DESCENSO · ESFERA', 'souls earned': 'almas ganadas',
    'PLAY AGAIN': 'OTRA VEZ', 'MENU': 'MENÚ', '▶︎ REVIVE': '▶︎ REVIVIR', '×2 GEMS': '×2 GEMAS',
    'NEXT: {name} {gem} {x}/{y}': 'SIGUIENTE: {name} {gem} {x}/{y}',
    'PAUSED': 'PAUSA', 'tap to resume': 'toca para seguir', 'LEVEL UP!': '¡SUBES DE NIVEL!',
    'BEST SCORE': 'MEJOR PUNTUACIÓN', 'BEST SURVIVAL': 'MEJOR SUPERVIVENCIA', 'PLAYER LEVEL': 'NIVEL DE JUGADOR',
    'RUNS': 'PARTIDAS', 'TIME PLAYED': 'TIEMPO JUGADO', 'GEMS COLLECTED': 'GEMAS RECOGIDAS',
    'STORMS WEATHERED': 'TORMENTAS SUPERADAS', 'MISSIONS DONE': 'MISIONES HECHAS',
    'DEEPEST SPHERE': 'ESFERA MÁS PROFUNDA', 'SOULS EARNED': 'ALMAS GANADAS',
    'RELICS FOUND': 'RELIQUIAS HALLADAS', 'WARDENS FELLED': 'GUARDIANES CAÍDOS',
    'DEEPEST · SPHERE': 'MÁS PROFUNDO · ESFERA', 'BEST DAILY': 'MEJOR DIARIO',
    "TODAY'S SEED": 'SEMILLA DE HOY',
    "race a friend's run — enter their seed code": 'compite contra la partida de un amigo: escribe su código',
    'RACE THIS SEED': 'CORRER ESTA SEMILLA',
    'TAP TO SWITCH LANES': 'TOCA PARA CAMBIAR DE CARRIL',
    'NEAR MISS': 'POR POCO', 'NEAR MISS ×{n}': 'POR POCO ×{n}', 'STORM': 'TORMENTA',
    'POT': 'BOTE', 'RIDING': 'EN JUEGO', 'BEST!': '¡RÉCORD!', 'PASSED YOUR GHOST': 'SUPERASTE A TU FANTASMA',
    'SPHERE {r}': 'ESFERA {r}', '✔ WARDEN FELLED': '✔ GUARDIÁN CAÍDO', '× EXIT': '× SALIR',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'CONSEJO: gasta tus ◆ en EQUIPO; las pistas multiplican lo que ganas',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ALMAS GANADAS: sintoniza Reliquias en EQUIPO › RELIQUIAS',
    'Daily challenge beaten': 'Reto diario superado',
    'Survive {n}s in one run': 'Sobrevive {n}s en una partida',
    'Collect {n} ◆ in one run': 'Recoge {n} ◆ en una partida',
    'Collect {n} ◆ in total': 'Recoge {n} ◆ en total',
    'Finish {n} runs': 'Termina {n} partidas',
    'Finish a run on {track}': 'Termina una partida en {track}',
    'Switch lanes {n}× in one run': 'Cambia de carril {n} veces en una partida',
    'Near-miss {n} spikes in one run': 'Roza {n} pinchos en una partida',
    'Reach player level {n}': 'Llega al nivel de jugador {n}',
    'THE RUN': 'LA PARTIDA', 'GEMS': 'GEMAS', 'THE DESCENT': 'EL DESCENSO',
    'RELICS & THE FORGE': 'RELIQUIAS Y LA FORJA', 'MISSIONS & LEVEL': 'MISIONES Y NIVEL',
    'g.run': 'Toca en cualquier parte para cambiar de carril. Esquiva los pinchos: un golpe acaba la partida. Pasa rozando un pincho para un <b>ROCE</b>; encadenarlos multiplica tu puntuación. Cuando la pantalla muestre <b class="g-red">TORMENTA</b>, sobrevívela: las gemas pagan doble.',
    'g.gems': 'Cada partida paga gemas, multiplicadas por tu pista: de Loop ×1 hasta Prism ×20. Gástalas en <b>EQUIPO</b> en pistas, skins y estelas. Cada día te espera un bono gratis donde veas <b class="g-gem">50 GRATIS</b>.',
    'g.descent': 'Sobrevive lo suficiente y la partida <b>desciende</b> a Esferas más profundas. Lo profundo es más rico: eliges <b>RELIQUIAS</b> en plena partida (pactos poderosos, algunos malditos), te bates con <b class="g-red">GUARDIANES</b> y ganas <span class="soul">◇</span> <b>ALMAS</b> según la profundidad.',
    'g.forge': 'Cada reliquia que eliges queda registrada en <b>EQUIPO › RELIQUIAS</b>. Gasta Almas para <b>sintonizar</b> una y sembrarla en tu Pacto inicial: arrancará activa en cada partida personal.',
    'g.daily': 'Un intento clasificado al día: la misma partida exacta para todos los jugadores. Supera 30s y gana 100 <span class="gem">◆</span>. Reclamar tu premio diario cada día hace crecer la racha hasta 150 <span class="gem">◆</span> al día.',
    'g.missions': 'Las misiones pagan gemas y se reemplazan al momento de completarlas. Las partidas también suben tu nivel de jugador, y cada nivel paga un bono de gemas.',
    'g.shop': 'Packs de gemas si quieres desbloquear más rápido, y el <b class="g-gold">ULTRA PASS</b>: ×3 gemas en cada partida para siempre, más un regalo diario de 500 gemas.'
  };

  D.pt = {
    'HOME': 'INÍCIO', 'GEAR': 'ITENS', 'SHOP': 'LOJA', 'MORE': 'MAIS',
    'TRACKS': 'PISTAS', 'THEMES': 'TEMAS', 'SKINS': 'SKINS', 'TRAILS': 'RASTROS', 'RELICS': 'RELÍQUIAS',
    'PLAY': 'JOGAR', 'DAILY RUN': 'DESAFIO DIÁRIO',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'infinito · sem perder',
    'beat {n}s · win 100 {gem}': 'passe de {n}s · ganhe 100 {gem}',
    'BEST': 'RECORDE', 'LV': 'NV', 'MISSIONS': 'MISSÕES', 'WIN {gem}{n}': 'GANHE {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} GRÁTIS',
    'watch ad · once a day': 'assista a um anúncio · uma vez por dia',
    'tap to switch lanes · dodge the spikes': 'toque para trocar de pista · desvie dos espinhos',
    'higher multiplier · more {gem} every run': 'multiplicador maior · mais {gem} por corrida',
    'world colors · free to switch': 'cores do mundo · troque de graça',
    'unlock with {gem} · sets your glow': 'desbloqueie com {gem} · define seu brilho',
    'unlock with {gem} gems': 'desbloqueie com gemas {gem}',
    'found in the Descent · attune with {soul}': 'da Descida · sintonize com {soul}',
    '{n} worlds': '{n} mundos', '{x}/{y} found': '{x}/{y} achadas',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'As PISTAS multiplicam as {gem} que você ganha. TEMAS, SKINS e RASTROS são só estilo. RELÍQUIAS vêm das corridas profundas: a Descida.',
    'GOT IT': 'ENTENDI', 'SOULS': 'ALMAS', 'SEED': 'SEMENTE',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Relíquias caem na DESCIDA: sobreviva fundo na corrida e escolha-as no meio dela. A profundidade também paga as Almas que as sintonizam.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Toque numa relíquia para ler o que ela faz; toque de novo para sintonizá-la no seu Pacto inicial.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Relíquia não descoberta (nível {n}): escolha-a durante uma corrida para desbloquear.',
    'Seeded into your opening Pact — tap again to remove.': 'Semeada no seu Pacto inicial; toque de novo para remover.',
    'Attuned — tap again to seed it into your Pact.': 'Sintonizada; toque de novo para semeá-la no seu Pacto.',
    'Tap again to attune for {n} Souls.': 'Toque de novo para sintonizar por {n} Almas.',
    'Costs {n} Souls to attune (you have {x}).': 'Sintonizar custa {n} Almas (você tem {x}).',
    'SEEDED': 'SEMEADA',
    'classic': 'clássica', '+gems': '+gemas', '+power-ups': '+power-ups', 'magnets': 'ímãs',
    'feasts': 'banquetes', '+1 ◆/gem': '+1 ◆/gema', '+2 ◆/gem': '+2 ◆/gema', 'magnets+': 'ímãs+', 'rich gems': 'gemas ricas',
    'YOU HAVE': 'VOCÊ TEM',
    '×3 gems from every run — forever': '×3 gemas em toda corrida, para sempre',
    '+500 {gem} gift every day': '+500 {gem} de presente todo dia',
    'POPULAR': 'POPULAR', 'BEST VALUE': 'MELHOR OFERTA', 'OWNED': 'SEU', 'ACTIVE ×3': 'ATIVO ×3',
    'REMOVE ADS': 'SEM ANÚNCIOS',
    'gems are earned every run — plus a free bonus daily': 'você ganha gemas em toda corrida, mais um bônus grátis diário',
    'purchases support development': 'as compras apoiam o desenvolvimento',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass ativo: ×3 em todas as gemas ganhas',
    'store unavailable — try again later': 'loja indisponível; tente de novo mais tarde',
    'RESTORE PURCHASES': 'RESTAURAR COMPRAS', 'restoring…': 'restaurando…',
    'restore failed — check your connection and try again': 'falha ao restaurar: verifique sua conexão e tente de novo',
    'purchases restored — thank you!': 'compras restauradas, obrigado!',
    'nothing to restore on this account': 'nada para restaurar nesta conta',
    'HOW TO PLAY': 'COMO JOGAR', 'the run · gems · the Descent': 'a corrida · gemas · a Descida',
    'descent records · seed race': 'recordes da Descida · corrida de sementes',
    'STATS': 'ESTATÍSTICAS', 'lifetime records': 'recordes de sempre',
    'LEADERBOARD': 'RANKING', 'compare with the world': 'compare com o mundo',
    'SETTINGS': 'OPÇÕES', 'sound · haptics · accessibility': 'som · vibração · acessibilidade',
    'Sound effects': 'Efeitos sonoros', 'Music': 'Música', 'Reduce flashing': 'Reduzir flashes',
    'Haptics': 'Vibração', 'Reduce motion': 'Reduzir movimento', 'Ghost racer': 'Fantasma rival',
    'Ad privacy options': 'Privacidade de anúncios', 'Delete custom photo': 'Apagar foto própria',
    'Reset all progress': 'Apagar todo o progresso', 'Tap again to ERASE everything': 'Toque de novo para APAGAR tudo',
    'Language': 'Idioma', 'AUTO': 'AUTO', 'ON': 'SIM', 'OFF': 'NÃO', 'FULL': 'FORTE', 'LIGHT': 'LEVE',
    'DAILY REWARD': 'PRÊMIO DIÁRIO', 'DAY {n}': 'DIA {n}', 'CLAIM': 'RESGATAR',
    '▶︎  KEEP STREAK': '▶︎  MANTER SEQUÊNCIA', 'watch ad': 'assista a um anúncio',
    'CUSTOM SKIN': 'SKIN PRÓPRIA', 'turn any photo into your ball': 'transforme qualquer foto na sua bola',
    'UNLOCK {gem}600': 'DESBLOQUEAR {gem}600', '▶︎  WATCH AD': '▶︎  VER ANÚNCIO',
    'free unlock': 'desbloqueio grátis', 'CANCEL': 'CANCELAR', 'CLOSE': 'FECHAR',
    'SCORE': 'PONTOS', 'NEW BEST!': 'NOVO RECORDE!',
    'NEAR MISSES': 'RASPÕES', 'BEST COMBO': 'MELHOR COMBO',
    'DESCENT · SPHERE': 'DESCIDA · ESFERA', 'souls earned': 'almas ganhas',
    'PLAY AGAIN': 'DE NOVO', 'MENU': 'MENU', '▶︎ REVIVE': '▶︎ REVIVER', '×2 GEMS': '×2 GEMAS',
    'NEXT: {name} {gem} {x}/{y}': 'PRÓXIMO: {name} {gem} {x}/{y}',
    'PAUSED': 'PAUSADO', 'tap to resume': 'toque para continuar', 'LEVEL UP!': 'SUBIU DE NÍVEL!',
    'BEST SCORE': 'MELHOR PONTUAÇÃO', 'BEST SURVIVAL': 'MELHOR SOBREVIVÊNCIA', 'PLAYER LEVEL': 'NÍVEL DE JOGADOR',
    'RUNS': 'CORRIDAS', 'TIME PLAYED': 'TEMPO JOGADO', 'GEMS COLLECTED': 'GEMAS COLETADAS',
    'STORMS WEATHERED': 'TEMPESTADES VENCIDAS', 'MISSIONS DONE': 'MISSÕES FEITAS',
    'DEEPEST SPHERE': 'ESFERA MAIS FUNDA', 'SOULS EARNED': 'ALMAS GANHAS',
    'RELICS FOUND': 'RELÍQUIAS ACHADAS', 'WARDENS FELLED': 'GUARDIÕES DERRUBADOS',
    'DEEPEST · SPHERE': 'MAIS FUNDO · ESFERA', 'BEST DAILY': 'MELHOR DIÁRIO',
    "TODAY'S SEED": 'SEMENTE DE HOJE',
    "race a friend's run — enter their seed code": 'corra contra um amigo: digite o código da semente dele',
    'RACE THIS SEED': 'CORRER ESTA SEMENTE',
    'TAP TO SWITCH LANES': 'TOQUE PARA TROCAR DE PISTA',
    'NEAR MISS': 'POR POUCO', 'NEAR MISS ×{n}': 'POR POUCO ×{n}', 'STORM': 'TEMPESTADE',
    'POT': 'BOLADA', 'RIDING': 'EM JOGO', 'BEST!': 'RECORDE!', 'PASSED YOUR GHOST': 'PASSOU SEU FANTASMA',
    'SPHERE {r}': 'ESFERA {r}', '✔ WARDEN FELLED': '✔ GUARDIÃO DERRUBADO', '× EXIT': '× SAIR',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'DICA: gaste suas ◆ em ITENS; pistas multiplicam seus ganhos',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ALMAS GANHAS: sintonize Relíquias em ITENS › RELÍQUIAS',
    'Daily challenge beaten': 'Desafio diário vencido',
    'Survive {n}s in one run': 'Sobreviva {n}s em uma corrida',
    'Collect {n} ◆ in one run': 'Colete {n} ◆ em uma corrida',
    'Collect {n} ◆ in total': 'Colete {n} ◆ no total',
    'Finish {n} runs': 'Termine {n} corridas',
    'Finish a run on {track}': 'Termine uma corrida em {track}',
    'Switch lanes {n}× in one run': 'Troque de pista {n}× em uma corrida',
    'Near-miss {n} spikes in one run': 'Raspe em {n} espinhos em uma corrida',
    'Reach player level {n}': 'Alcance o nível de jogador {n}',
    'THE RUN': 'A CORRIDA', 'GEMS': 'GEMAS', 'THE DESCENT': 'A DESCIDA',
    'RELICS & THE FORGE': 'RELÍQUIAS E A FORJA', 'MISSIONS & LEVEL': 'MISSÕES E NÍVEL',
    'g.run': 'Toque em qualquer lugar para trocar de pista. Desvie dos espinhos: um toque encerra a corrida. Passe raspando num espinho para um <b>RASPÃO</b>; correntes multiplicam sua pontuação. Quando a tela piscar <b class="g-red">TEMPESTADE</b>, sobreviva: as gemas pagam em dobro.',
    'g.gems': 'Toda corrida paga gemas, multiplicadas pela sua pista: de Loop ×1 até Prism ×20. Gaste em <b>ITENS</b> com pistas, skins e rastros. Um bônus grátis espera todo dia onde você vir <b class="g-gem">50 GRÁTIS</b>.',
    'g.descent': 'Sobreviva o bastante e a corrida <b>desce</b> para Esferas mais profundas. O fundo é mais rico: você escolhe <b>RELÍQUIAS</b> no meio da corrida (pactos poderosos, alguns amaldiçoados), enfrenta <b class="g-red">GUARDIÕES</b> e ganha <span class="soul">◇</span> <b>ALMAS</b> pela profundidade.',
    'g.forge': 'Toda relíquia escolhida fica registrada em <b>ITENS › RELÍQUIAS</b>. Gaste Almas para <b>sintonizar</b> uma e semeá-la no seu Pacto inicial: ela começa ativa em toda corrida pessoal.',
    'g.daily': 'Uma tentativa ranqueada por dia: a mesma corrida exata para todos os jogadores. Passe de 30s e ganhe 100 <span class="gem">◆</span>. Resgatar o prêmio diário todo dia faz a sequência crescer até 150 <span class="gem">◆</span> por dia.',
    'g.missions': 'Missões pagam gemas e são trocadas assim que você as completa. Corridas também sobem seu nível de jogador, e cada nível paga um bônus de gemas.',
    'g.shop': 'Pacotes de gemas se quiser desbloquear mais rápido, e o <b class="g-gold">ULTRA PASS</b>: ×3 gemas em toda corrida para sempre, mais um presente diário de 500 gemas.'
  };

  D.fr = {
    'HOME': 'ACCUEIL', 'GEAR': 'STYLE', 'SHOP': 'SHOP', 'MORE': 'PLUS',
    'TRACKS': 'PISTES', 'THEMES': 'THÈMES', 'SKINS': 'SKINS', 'TRAILS': 'TRACES', 'RELICS': 'RELIQUES',
    'PLAY': 'JOUER', 'DAILY RUN': 'DÉFI DU JOUR',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'infini · sans échec',
    'beat {n}s · win 100 {gem}': 'tenez {n}s · gagnez 100 {gem}',
    'BEST': 'RECORD', 'LV': 'NV', 'MISSIONS': 'MISSIONS', 'WIN {gem}{n}': 'GAGNEZ {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} GRATUITES',
    'watch ad · once a day': 'regardez une pub · une fois par jour',
    'tap to switch lanes · dodge the spikes': 'touchez pour changer de voie · évitez les pointes',
    'higher multiplier · more {gem} every run': 'multiplicateur plus élevé · plus de {gem} par course',
    'world colors · free to switch': 'couleurs du monde · changement gratuit',
    'unlock with {gem} · sets your glow': 'débloquez avec {gem} · définit votre halo',
    'unlock with {gem} gems': 'débloquez avec des gemmes {gem}',
    'found in the Descent · attune with {soul}': 'issues de la Descente · accordez avec {soul}',
    '{n} worlds': '{n} mondes', '{x}/{y} found': '{x}/{y} trouvées',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'Les PISTES multiplient les {gem} gagnées. THÈMES, SKINS et TRACES sont purement esthétiques. Les RELIQUES viennent des courses profondes : la Descente.',
    'GOT IT': 'COMPRIS', 'SOULS': 'ÂMES', 'SEED': 'GRAINE',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Les reliques tombent dans la DESCENTE : survivez profondément et choisissez-les en pleine course. La profondeur paie aussi les Âmes qui les accordent.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Touchez une relique pour lire son effet ; touchez encore pour l’accorder dans votre Pacte de départ.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Relique inconnue (rang {n}) : choisissez-la en course pour la débloquer.',
    'Seeded into your opening Pact — tap again to remove.': 'Semée dans votre Pacte de départ ; touchez encore pour la retirer.',
    'Attuned — tap again to seed it into your Pact.': 'Accordée ; touchez encore pour la semer dans votre Pacte.',
    'Tap again to attune for {n} Souls.': 'Touchez encore pour accorder contre {n} Âmes.',
    'Costs {n} Souls to attune (you have {x}).': 'L’accord coûte {n} Âmes (vous en avez {x}).',
    'SEEDED': 'SEMÉE',
    'classic': 'classique', '+gems': '+gemmes', '+power-ups': '+bonus', 'magnets': 'aimants',
    'feasts': 'festins', '+1 ◆/gem': '+1 ◆/gemme', '+2 ◆/gem': '+2 ◆/gemme', 'magnets+': 'aimants+', 'rich gems': 'gemmes riches',
    'YOU HAVE': 'VOUS AVEZ',
    '×3 gems from every run — forever': '×3 gemmes à chaque course, pour toujours',
    '+500 {gem} gift every day': '+500 {gem} offertes chaque jour',
    'POPULAR': 'POPULAIRE', 'BEST VALUE': 'MEILLEURE OFFRE', 'OWNED': 'ACQUIS', 'ACTIVE ×3': 'ACTIF ×3',
    'REMOVE ADS': 'SANS PUBS',
    'gems are earned every run — plus a free bonus daily': 'chaque course rapporte des gemmes, plus un bonus gratuit quotidien',
    'purchases support development': 'les achats soutiennent le développement',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass actif : ×3 sur toutes les gemmes gagnées',
    'store unavailable — try again later': 'boutique indisponible ; réessayez plus tard',
    'RESTORE PURCHASES': 'RESTAURER LES ACHATS', 'restoring…': 'restauration…',
    'restore failed — check your connection and try again': 'échec de la restauration : vérifiez votre connexion et réessayez',
    'purchases restored — thank you!': 'achats restaurés, merci !',
    'nothing to restore on this account': 'rien à restaurer sur ce compte',
    'HOW TO PLAY': 'COMMENT JOUER', 'the run · gems · the Descent': 'la course · gemmes · la Descente',
    'descent records · seed race': 'records de Descente · course de graines',
    'STATS': 'STATS', 'lifetime records': 'records à vie',
    'LEADERBOARD': 'CLASSEMENT', 'compare with the world': 'comparez-vous au monde',
    'SETTINGS': 'RÉGLAGES', 'sound · haptics · accessibility': 'son · vibrations · accessibilité',
    'Sound effects': 'Effets sonores', 'Music': 'Musique', 'Reduce flashing': 'Réduire les flashs',
    'Haptics': 'Vibrations', 'Reduce motion': 'Réduire les animations', 'Ghost racer': 'Fantôme rival',
    'Ad privacy options': 'Confidentialité des pubs', 'Delete custom photo': 'Supprimer la photo perso',
    'Reset all progress': 'Effacer toute la progression', 'Tap again to ERASE everything': 'Touchez encore pour TOUT effacer',
    'Language': 'Langue', 'AUTO': 'AUTO', 'ON': 'OUI', 'OFF': 'NON', 'FULL': 'FORT', 'LIGHT': 'LÉGER',
    'DAILY REWARD': 'RÉCOMPENSE DU JOUR', 'DAY {n}': 'JOUR {n}', 'CLAIM': 'RÉCUPÉRER',
    '▶︎  KEEP STREAK': '▶︎  SAUVER LA SÉRIE', 'watch ad': 'regardez une pub',
    'CUSTOM SKIN': 'SKIN PERSO', 'turn any photo into your ball': 'faites de n’importe quelle photo votre balle',
    'UNLOCK {gem}600': 'DÉBLOQUER {gem}600', '▶︎  WATCH AD': '▶︎  VOIR UNE PUB',
    'free unlock': 'déblocage gratuit', 'CANCEL': 'ANNULER', 'CLOSE': 'FERMER',
    'SCORE': 'SCORE', 'NEW BEST!': 'NOUVEAU RECORD !',
    'NEAR MISSES': 'FRÔLEMENTS', 'BEST COMBO': 'MEILLEUR COMBO',
    'DESCENT · SPHERE': 'DESCENTE · SPHÈRE', 'souls earned': 'âmes gagnées',
    'PLAY AGAIN': 'REJOUER', 'MENU': 'MENU', '▶︎ REVIVE': '▶︎ REVIVRE', '×2 GEMS': '×2 GEMMES',
    'NEXT: {name} {gem} {x}/{y}': 'SUIVANT : {name} {gem} {x}/{y}',
    'PAUSED': 'PAUSE', 'tap to resume': 'touchez pour reprendre', 'LEVEL UP!': 'NIVEAU SUPÉRIEUR !',
    'BEST SCORE': 'MEILLEUR SCORE', 'BEST SURVIVAL': 'MEILLEURE SURVIE', 'PLAYER LEVEL': 'NIVEAU DE JOUEUR',
    'RUNS': 'COURSES', 'TIME PLAYED': 'TEMPS DE JEU', 'GEMS COLLECTED': 'GEMMES RÉCOLTÉES',
    'STORMS WEATHERED': 'TEMPÊTES SURMONTÉES', 'MISSIONS DONE': 'MISSIONS FAITES',
    'DEEPEST SPHERE': 'SPHÈRE LA PLUS PROFONDE', 'SOULS EARNED': 'ÂMES GAGNÉES',
    'RELICS FOUND': 'RELIQUES TROUVÉES', 'WARDENS FELLED': 'GARDIENS VAINCUS',
    'DEEPEST · SPHERE': 'PLUS PROFOND · SPHÈRE', 'BEST DAILY': 'MEILLEUR DÉFI',
    "TODAY'S SEED": 'GRAINE DU JOUR',
    "race a friend's run — enter their seed code": 'affrontez la course d’un ami : saisissez son code graine',
    'RACE THIS SEED': 'COURIR CETTE GRAINE',
    'TAP TO SWITCH LANES': 'TOUCHEZ POUR CHANGER DE VOIE',
    'NEAR MISS': 'FRÔLÉ', 'NEAR MISS ×{n}': 'FRÔLÉ ×{n}', 'STORM': 'TEMPÊTE',
    'POT': 'CAGNOTTE', 'RIDING': 'EN JEU', 'BEST!': 'RECORD !', 'PASSED YOUR GHOST': 'FANTÔME DÉPASSÉ',
    'SPHERE {r}': 'SPHÈRE {r}', '✔ WARDEN FELLED': '✔ GARDIEN VAINCU', '× EXIT': '× QUITTER',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'ASTUCE : dépensez vos ◆ dans STYLE ; les pistes multiplient vos gains',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ÂMES GAGNÉES : accordez des Reliques dans STYLE › RELIQUES',
    'Daily challenge beaten': 'Défi du jour réussi',
    'Survive {n}s in one run': 'Survivez {n}s en une course',
    'Collect {n} ◆ in one run': 'Récoltez {n} ◆ en une course',
    'Collect {n} ◆ in total': 'Récoltez {n} ◆ au total',
    'Finish {n} runs': 'Terminez {n} courses',
    'Finish a run on {track}': 'Terminez une course sur {track}',
    'Switch lanes {n}× in one run': 'Changez de voie {n}× en une course',
    'Near-miss {n} spikes in one run': 'Frôlez {n} pointes en une course',
    'Reach player level {n}': 'Atteignez le niveau de joueur {n}',
    'THE RUN': 'LA COURSE', 'GEMS': 'GEMMES', 'THE DESCENT': 'LA DESCENTE',
    'RELICS & THE FORGE': 'RELIQUES ET LA FORGE', 'MISSIONS & LEVEL': 'MISSIONS ET NIVEAU',
    'g.run': 'Touchez n’importe où pour changer de voie. Évitez les pointes : un seul contact met fin à la course. Frôlez une pointe pour un <b>FRÔLEMENT</b> ; les enchaîner multiplie votre score. Quand l’écran affiche <b class="g-red">TEMPÊTE</b>, survivez : les gemmes paient double.',
    'g.gems': 'Chaque course rapporte des gemmes, multipliées par votre piste : de Loop ×1 à Prism ×20. Dépensez-les dans <b>STYLE</b> en pistes, skins et traces. Un bonus gratuit vous attend chaque jour là où vous voyez <b class="g-gem">50 GRATUITES</b>.',
    'g.descent': 'Survivez assez longtemps et la course <b>descend</b> vers des Sphères plus profondes. Les profondeurs sont plus riches : vous choisissez des <b>RELIQUES</b> en pleine course (pactes puissants, parfois maudits), affrontez des <b class="g-red">GARDIENS</b> et gagnez des <span class="soul">◇</span> <b>ÂMES</b> selon la profondeur.',
    'g.forge': 'Chaque relique choisie est consignée dans <b>STYLE › RELIQUES</b>. Dépensez des Âmes pour en <b>accorder</b> une et la semer dans votre Pacte de départ : elle démarre active à chaque course personnelle.',
    'g.daily': 'Une tentative classée par jour : exactement la même course pour tous les joueurs. Tenez 30s pour gagner 100 <span class="gem">◆</span>. Récupérer votre récompense chaque jour fait grimper la série jusqu’à 150 <span class="gem">◆</span> par jour.',
    'g.missions': 'Les missions paient des gemmes et sont remplacées dès qu’elles sont accomplies. Les courses font aussi monter votre niveau de joueur : chaque niveau paie un bonus de gemmes.',
    'g.shop': 'Des packs de gemmes pour débloquer plus vite, et l’<b class="g-gold">ULTRA PASS</b> : ×3 gemmes à chaque course pour toujours, plus un cadeau quotidien de 500 gemmes.'
  };

  D.de = {
    'HOME': 'START', 'GEAR': 'ITEMS', 'SHOP': 'SHOP', 'MORE': 'MEHR',
    'TRACKS': 'BAHNEN', 'THEMES': 'WELTEN', 'SKINS': 'SKINS', 'TRAILS': 'SPUREN', 'RELICS': 'RELIKTE',
    'PLAY': 'SPIELEN', 'DAILY RUN': 'TAGESLAUF',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'endlos · ohne Scheitern',
    'beat {n}s · win 100 {gem}': 'schaffe {n}s · gewinne 100 {gem}',
    'BEST': 'REKORD', 'LV': 'LV', 'MISSIONS': 'MISSIONEN', 'WIN {gem}{n}': 'HOL {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} GRATIS',
    'watch ad · once a day': 'Werbung ansehen · einmal täglich',
    'tap to switch lanes · dodge the spikes': 'tippe für den Spurwechsel · weiche den Stacheln aus',
    'higher multiplier · more {gem} every run': 'höherer Multiplikator · mehr {gem} pro Lauf',
    'world colors · free to switch': 'Weltfarben · gratis wechselbar',
    'unlock with {gem} · sets your glow': 'mit {gem} freischalten · bestimmt dein Leuchten',
    'unlock with {gem} gems': 'mit {gem}-Edelsteinen freischalten',
    'found in the Descent · attune with {soul}': 'aus dem Abstieg · mit {soul} einstimmen',
    '{n} worlds': '{n} Welten', '{x}/{y} found': '{x}/{y} gefunden',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'BAHNEN multiplizieren deine {gem}. WELTEN, SKINS und SPUREN sind reiner Stil. RELIKTE stammen aus tiefen Läufen — dem Abstieg.',
    'GOT IT': 'ALLES KLAR', 'SOULS': 'SEELEN', 'SEED': 'SAAT',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Relikte fallen im ABSTIEG: Überlebe tief in einem Lauf und wähle sie mittendrin. Die Tiefe zahlt auch die Seelen, die sie einstimmen.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Tippe ein Relikt an, um seine Wirkung zu lesen; tippe erneut, um es in deinen Start-Pakt einzustimmen.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Unentdecktes Relikt (Stufe {n}) — wähle es in einem Lauf, um es freizuschalten.',
    'Seeded into your opening Pact — tap again to remove.': 'In deinen Start-Pakt gesät; erneut tippen zum Entfernen.',
    'Attuned — tap again to seed it into your Pact.': 'Eingestimmt; erneut tippen, um es in deinen Pakt zu säen.',
    'Tap again to attune for {n} Souls.': 'Erneut tippen: Einstimmen für {n} Seelen.',
    'Costs {n} Souls to attune (you have {x}).': 'Einstimmen kostet {n} Seelen (du hast {x}).',
    'SEEDED': 'GESÄT',
    'classic': 'klassisch', '+gems': '+Edelsteine', '+power-ups': '+Power-ups', 'magnets': 'Magnete',
    'feasts': 'Festmähler', '+1 ◆/gem': '+1 ◆/Stein', '+2 ◆/gem': '+2 ◆/Stein', 'magnets+': 'Magnete+', 'rich gems': 'reiche Steine',
    'YOU HAVE': 'DU HAST',
    '×3 gems from every run — forever': '×3 Edelsteine aus jedem Lauf — für immer',
    '+500 {gem} gift every day': '+500 {gem} Geschenk jeden Tag',
    'POPULAR': 'BELIEBT', 'BEST VALUE': 'BESTER DEAL', 'OWNED': 'GEKAUFT', 'ACTIVE ×3': 'AKTIV ×3',
    'REMOVE ADS': 'WERBUNG WEG',
    'gems are earned every run — plus a free bonus daily': 'Edelsteine gibt es in jedem Lauf — plus täglich ein Gratis-Bonus',
    'purchases support development': 'Käufe unterstützen die Entwicklung',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass aktiv: ×3 auf alle verdienten Edelsteine',
    'store unavailable — try again later': 'Store nicht erreichbar — versuch es später erneut',
    'RESTORE PURCHASES': 'KÄUFE WIEDERHERSTELLEN', 'restoring…': 'stelle wieder her…',
    'restore failed — check your connection and try again': 'Wiederherstellen fehlgeschlagen: Prüfe deine Verbindung und versuch es erneut',
    'purchases restored — thank you!': 'Käufe wiederhergestellt — danke!',
    'nothing to restore on this account': 'auf diesem Konto gibt es nichts wiederherzustellen',
    'HOW TO PLAY': 'SPIELANLEITUNG', 'the run · gems · the Descent': 'der Lauf · Edelsteine · der Abstieg',
    'descent records · seed race': 'Abstiegs-Rekorde · Saat-Rennen',
    'STATS': 'STATISTIK', 'lifetime records': 'ewige Rekorde',
    'LEADERBOARD': 'RANGLISTE', 'compare with the world': 'vergleich dich mit der Welt',
    'SETTINGS': 'OPTIONEN', 'sound · haptics · accessibility': 'Sound · Vibration · Bedienungshilfen',
    'Sound effects': 'Soundeffekte', 'Music': 'Musik', 'Reduce flashing': 'Blitzen reduzieren',
    'Haptics': 'Vibration', 'Reduce motion': 'Bewegung reduzieren', 'Ghost racer': 'Geister-Rivale',
    'Ad privacy options': 'Werbe-Datenschutz', 'Delete custom photo': 'Eigenes Foto löschen',
    'Reset all progress': 'Gesamten Fortschritt löschen', 'Tap again to ERASE everything': 'Erneut tippen, um ALLES zu löschen',
    'Language': 'Sprache', 'AUTO': 'AUTO', 'ON': 'AN', 'OFF': 'AUS', 'FULL': 'VOLL', 'LIGHT': 'LEICHT',
    'DAILY REWARD': 'TAGESBONUS', 'DAY {n}': 'TAG {n}', 'CLAIM': 'ABHOLEN',
    '▶︎  KEEP STREAK': '▶︎  SERIE RETTEN', 'watch ad': 'Werbung ansehen',
    'CUSTOM SKIN': 'EIGENER SKIN', 'turn any photo into your ball': 'mach jedes Foto zu deinem Ball',
    'UNLOCK {gem}600': 'FREISCHALTEN {gem}600', '▶︎  WATCH AD': '▶︎  WERBUNG ANSEHEN',
    'free unlock': 'gratis freischalten', 'CANCEL': 'ABBRECHEN', 'CLOSE': 'SCHLIESSEN',
    'SCORE': 'PUNKTE', 'NEW BEST!': 'NEUER REKORD!',
    'NEAR MISSES': 'BEINAHE-TREFFER', 'BEST COMBO': 'BESTE KOMBO',
    'DESCENT · SPHERE': 'ABSTIEG · SPHÄRE', 'souls earned': 'Seelen verdient',
    'PLAY AGAIN': 'NOCHMAL', 'MENU': 'MENÜ', '▶︎ REVIVE': '▶︎ WEITERLEBEN', '×2 GEMS': '×2 STEINE',
    'NEXT: {name} {gem} {x}/{y}': 'NÄCHSTES: {name} {gem} {x}/{y}',
    'PAUSED': 'PAUSE', 'tap to resume': 'tippen zum Fortsetzen', 'LEVEL UP!': 'LEVEL-UP!',
    'BEST SCORE': 'BESTE PUNKTZAHL', 'BEST SURVIVAL': 'LÄNGSTES ÜBERLEBEN', 'PLAYER LEVEL': 'SPIELERLEVEL',
    'RUNS': 'LÄUFE', 'TIME PLAYED': 'SPIELZEIT', 'GEMS COLLECTED': 'EDELSTEINE GESAMMELT',
    'STORMS WEATHERED': 'STÜRME ÜBERSTANDEN', 'MISSIONS DONE': 'MISSIONEN GESCHAFFT',
    'DEEPEST SPHERE': 'TIEFSTE SPHÄRE', 'SOULS EARNED': 'SEELEN VERDIENT',
    'RELICS FOUND': 'RELIKTE GEFUNDEN', 'WARDENS FELLED': 'WÄCHTER BESIEGT',
    'DEEPEST · SPHERE': 'TIEFSTER PUNKT · SPHÄRE', 'BEST DAILY': 'BESTER TAGESLAUF',
    "TODAY'S SEED": 'HEUTIGE SAAT',
    "race a friend's run — enter their seed code": 'tritt gegen den Lauf eines Freundes an: gib seinen Saat-Code ein',
    'RACE THIS SEED': 'DIESE SAAT FAHREN',
    'TAP TO SWITCH LANES': 'TIPPE FÜR DEN SPURWECHSEL',
    'NEAR MISS': 'KNAPP VORBEI', 'NEAR MISS ×{n}': 'KNAPP VORBEI ×{n}', 'STORM': 'STURM',
    'POT': 'TOPF', 'RIDING': 'IM SPIEL', 'BEST!': 'REKORD!', 'PASSED YOUR GHOST': 'GEIST ÜBERHOLT',
    'SPHERE {r}': 'SPHÄRE {r}', '✔ WARDEN FELLED': '✔ WÄCHTER BESIEGT', '× EXIT': '× RAUS',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'TIPP: Gib deine ◆ unter ITEMS aus — Bahnen multiplizieren deinen Verdienst',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ SEELEN VERDIENT: Stimme Relikte unter ITEMS › RELIKTE ein',
    'Daily challenge beaten': 'Tageslauf geschafft',
    'Survive {n}s in one run': 'Überlebe {n}s in einem Lauf',
    'Collect {n} ◆ in one run': 'Sammle {n} ◆ in einem Lauf',
    'Collect {n} ◆ in total': 'Sammle {n} ◆ insgesamt',
    'Finish {n} runs': 'Beende {n} Läufe',
    'Finish a run on {track}': 'Beende einen Lauf auf {track}',
    'Switch lanes {n}× in one run': 'Wechsle {n}× die Spur in einem Lauf',
    'Near-miss {n} spikes in one run': 'Streife {n} Stacheln in einem Lauf',
    'Reach player level {n}': 'Erreiche Spielerlevel {n}',
    'THE RUN': 'DER LAUF', 'GEMS': 'EDELSTEINE', 'THE DESCENT': 'DER ABSTIEG',
    'RELICS & THE FORGE': 'RELIKTE & DIE SCHMIEDE', 'MISSIONS & LEVEL': 'MISSIONEN & LEVEL',
    'g.run': 'Tippe irgendwo, um die Spur zu wechseln. Weiche den Stacheln aus — ein Treffer beendet den Lauf. Streife knapp an einem Stachel vorbei für einen <b>BEINAHE-TREFFER</b>; Ketten multiplizieren deine Punkte. Blinkt <b class="g-red">STURM</b> auf, überlebe ihn: Edelsteine zahlen doppelt.',
    'g.gems': 'Jeder Lauf zahlt Edelsteine, multipliziert mit deiner Bahn: von Loop ×1 bis Prism ×20. Gib sie unter <b>ITEMS</b> für Bahnen, Skins und Spuren aus. Täglich wartet ein Gratis-Bonus, wo du <b class="g-gem">50 GRATIS</b> siehst.',
    'g.descent': 'Überlebst du lange genug, <b>steigt</b> der Lauf in tiefere Sphären <b>ab</b>. Die Tiefe ist reicher: Du wählst mitten im Lauf <b>RELIKTE</b> (mächtige Pakte, manche verflucht), duellierst dich mit <b class="g-red">WÄCHTERN</b> und verdienst <span class="soul">◇</span> <b>SEELEN</b> für die Tiefe.',
    'g.forge': 'Jedes gewählte Relikt landet unter <b>ITEMS › RELIKTE</b>. Gib Seelen aus, um eines <b>einzustimmen</b> und in deinen Start-Pakt zu säen — es startet dann in jedem persönlichen Lauf aktiv.',
    'g.daily': 'Ein gewerteter Versuch pro Tag — exakt derselbe Lauf für alle Spieler. Schaffe 30s und gewinne 100 <span class="gem">◆</span>. Holst du deinen Tagesbonus jeden Tag ab, wächst die Serie auf bis zu 150 <span class="gem">◆</span> täglich.',
    'g.missions': 'Missionen zahlen Edelsteine und werden sofort ersetzt, sobald du sie schaffst. Läufe erhöhen außerdem dein Spielerlevel — jedes Level zahlt einen Edelstein-Bonus.',
    'g.shop': 'Edelstein-Pakete, wenn du schneller freischalten willst, und der <b class="g-gold">ULTRA PASS</b>: ×3 Edelsteine aus jedem Lauf für immer, plus täglich 500 Edelsteine geschenkt.'
  };

  D.it = {
    'HOME': 'HOME', 'GEAR': 'STILE', 'SHOP': 'NEGOZIO', 'MORE': 'ALTRO',
    'TRACKS': 'PISTE', 'THEMES': 'TEMI', 'SKINS': 'SKIN', 'TRAILS': 'SCIE', 'RELICS': 'RELIQUIE',
    'PLAY': 'GIOCA', 'DAILY RUN': 'SFIDA DEL GIORNO',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'infinito · senza sconfitta',
    'beat {n}s · win 100 {gem}': 'supera {n}s · vinci 100 {gem}',
    'BEST': 'RECORD', 'LV': 'LV', 'MISSIONS': 'MISSIONI', 'WIN {gem}{n}': 'VINCI {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} GRATIS',
    'watch ad · once a day': 'guarda un annuncio · una volta al giorno',
    'tap to switch lanes · dodge the spikes': 'tocca per cambiare corsia · schiva le punte',
    'higher multiplier · more {gem} every run': 'moltiplicatore più alto · più {gem} a partita',
    'world colors · free to switch': 'colori del mondo · cambio gratuito',
    'unlock with {gem} · sets your glow': 'sblocca con {gem} · definisce il tuo bagliore',
    'unlock with {gem} gems': 'sblocca con gemme {gem}',
    'found in the Descent · attune with {soul}': 'dalla Discesa · sintonizza con {soul}',
    '{n} worlds': '{n} mondi', '{x}/{y} found': '{x}/{y} trovate',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'Le PISTE moltiplicano le {gem} che guadagni. TEMI, SKIN e SCIE sono puro stile. Le RELIQUIE arrivano dalle partite profonde: la Discesa.',
    'GOT IT': 'CAPITO', 'SOULS': 'ANIME', 'SEED': 'SEME',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Le reliquie cadono nella DISCESA: sopravvivi in profondità e scéglile a metà partita. La profondità paga anche le Anime che le sintonizzano.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Tocca una reliquia per leggerne l’effetto; tocca di nuovo per sintonizzarla nel tuo Patto iniziale.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Reliquia sconosciuta (grado {n}): sceglila durante una partita per sbloccarla.',
    'Seeded into your opening Pact — tap again to remove.': 'Seminata nel tuo Patto iniziale; tocca di nuovo per rimuoverla.',
    'Attuned — tap again to seed it into your Pact.': 'Sintonizzata; tocca di nuovo per seminarla nel tuo Patto.',
    'Tap again to attune for {n} Souls.': 'Tocca di nuovo per sintonizzarla per {n} Anime.',
    'Costs {n} Souls to attune (you have {x}).': 'Sintonizzarla costa {n} Anime (ne hai {x}).',
    'SEEDED': 'SEMINATA',
    'classic': 'classica', '+gems': '+gemme', '+power-ups': '+potenziamenti', 'magnets': 'magneti',
    'feasts': 'banchetti', '+1 ◆/gem': '+1 ◆/gemma', '+2 ◆/gem': '+2 ◆/gemma', 'magnets+': 'magneti+', 'rich gems': 'gemme ricche',
    'YOU HAVE': 'HAI',
    '×3 gems from every run — forever': '×3 gemme da ogni partita, per sempre',
    '+500 {gem} gift every day': '+500 {gem} in regalo ogni giorno',
    'POPULAR': 'POPOLARE', 'BEST VALUE': 'PIÙ CONVENIENTE', 'OWNED': 'TUO', 'ACTIVE ×3': 'ATTIVO ×3',
    'REMOVE ADS': 'NIENTE PUBBLICITÀ',
    'gems are earned every run — plus a free bonus daily': 'guadagni gemme a ogni partita, più un bonus gratis ogni giorno',
    'purchases support development': 'gli acquisti sostengono lo sviluppo',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass attivo: ×3 su tutte le gemme guadagnate',
    'store unavailable — try again later': 'negozio non disponibile; riprova più tardi',
    'RESTORE PURCHASES': 'RIPRISTINA ACQUISTI', 'restoring…': 'ripristino…',
    'restore failed — check your connection and try again': 'ripristino non riuscito: controlla la connessione e riprova',
    'purchases restored — thank you!': 'acquisti ripristinati, grazie!',
    'nothing to restore on this account': 'niente da ripristinare su questo account',
    'HOW TO PLAY': 'COME SI GIOCA', 'the run · gems · the Descent': 'la partita · gemme · la Discesa',
    'descent records · seed race': 'record della Discesa · gara dei semi',
    'STATS': 'STATISTICHE', 'lifetime records': 'record di sempre',
    'LEADERBOARD': 'CLASSIFICA', 'compare with the world': 'confrontati col mondo',
    'SETTINGS': 'IMPOSTAZIONI', 'sound · haptics · accessibility': 'audio · vibrazione · accessibilità',
    'Sound effects': 'Effetti sonori', 'Music': 'Musica', 'Reduce flashing': 'Riduci lampeggi',
    'Haptics': 'Vibrazione', 'Reduce motion': 'Riduci animazioni', 'Ghost racer': 'Fantasma rivale',
    'Ad privacy options': 'Privacy annunci', 'Delete custom photo': 'Elimina foto personale',
    'Reset all progress': 'Cancella tutti i progressi', 'Tap again to ERASE everything': 'Tocca di nuovo per CANCELLARE tutto',
    'Language': 'Lingua', 'AUTO': 'AUTO', 'ON': 'SÌ', 'OFF': 'NO', 'FULL': 'FORTE', 'LIGHT': 'LEGGERA',
    'DAILY REWARD': 'PREMIO GIORNALIERO', 'DAY {n}': 'GIORNO {n}', 'CLAIM': 'RITIRA',
    '▶︎  KEEP STREAK': '▶︎  SALVA LA SERIE', 'watch ad': 'guarda un annuncio',
    'CUSTOM SKIN': 'SKIN PERSONALE', 'turn any photo into your ball': 'trasforma qualsiasi foto nella tua palla',
    'UNLOCK {gem}600': 'SBLOCCA {gem}600', '▶︎  WATCH AD': '▶︎  GUARDA ANNUNCIO',
    'free unlock': 'sblocco gratuito', 'CANCEL': 'ANNULLA', 'CLOSE': 'CHIUDI',
    'SCORE': 'PUNTI', 'NEW BEST!': 'NUOVO RECORD!',
    'NEAR MISSES': 'SFIORATE', 'BEST COMBO': 'COMBO MIGLIORE',
    'DESCENT · SPHERE': 'DISCESA · SFERA', 'souls earned': 'anime guadagnate',
    'PLAY AGAIN': 'RIGIOCA', 'MENU': 'MENU', '▶︎ REVIVE': '▶︎ RIVIVI', '×2 GEMS': '×2 GEMME',
    'NEXT: {name} {gem} {x}/{y}': 'PROSSIMO: {name} {gem} {x}/{y}',
    'PAUSED': 'PAUSA', 'tap to resume': 'tocca per riprendere', 'LEVEL UP!': 'LIVELLO SU!',
    'BEST SCORE': 'PUNTEGGIO MIGLIORE', 'BEST SURVIVAL': 'SOPRAVVIVENZA MIGLIORE', 'PLAYER LEVEL': 'LIVELLO GIOCATORE',
    'RUNS': 'PARTITE', 'TIME PLAYED': 'TEMPO DI GIOCO', 'GEMS COLLECTED': 'GEMME RACCOLTE',
    'STORMS WEATHERED': 'TEMPESTE SUPERATE', 'MISSIONS DONE': 'MISSIONI COMPLETATE',
    'DEEPEST SPHERE': 'SFERA PIÙ PROFONDA', 'SOULS EARNED': 'ANIME GUADAGNATE',
    'RELICS FOUND': 'RELIQUIE TROVATE', 'WARDENS FELLED': 'GUARDIANI ABBATTUTI',
    'DEEPEST · SPHERE': 'PIÙ IN FONDO · SFERA', 'BEST DAILY': 'MIGLIOR SFIDA',
    "TODAY'S SEED": 'SEME DI OGGI',
    "race a friend's run — enter their seed code": 'sfida la partita di un amico: inserisci il suo codice seme',
    'RACE THIS SEED': 'CORRI QUESTO SEME',
    'TAP TO SWITCH LANES': 'TOCCA PER CAMBIARE CORSIA',
    'NEAR MISS': 'SFIORATA', 'NEAR MISS ×{n}': 'SFIORATA ×{n}', 'STORM': 'TEMPESTA',
    'POT': 'MONTEPREMI', 'RIDING': 'IN GIOCO', 'BEST!': 'RECORD!', 'PASSED YOUR GHOST': 'FANTASMA SUPERATO',
    'SPHERE {r}': 'SFERA {r}', '✔ WARDEN FELLED': '✔ GUARDIANO ABBATTUTO', '× EXIT': '× ESCI',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'CONSIGLIO: spendi le tue ◆ in STILE; le piste moltiplicano i guadagni',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ANIME GUADAGNATE: sintonizza le Reliquie in STILE › RELIQUIE',
    'Daily challenge beaten': 'Sfida del giorno superata',
    'Survive {n}s in one run': 'Sopravvivi {n}s in una partita',
    'Collect {n} ◆ in one run': 'Raccogli {n} ◆ in una partita',
    'Collect {n} ◆ in total': 'Raccogli {n} ◆ in totale',
    'Finish {n} runs': 'Completa {n} partite',
    'Finish a run on {track}': 'Completa una partita su {track}',
    'Switch lanes {n}× in one run': 'Cambia corsia {n} volte in una partita',
    'Near-miss {n} spikes in one run': 'Sfiora {n} punte in una partita',
    'Reach player level {n}': 'Raggiungi il livello giocatore {n}',
    'THE RUN': 'LA PARTITA', 'GEMS': 'GEMME', 'THE DESCENT': 'LA DISCESA',
    'RELICS & THE FORGE': 'RELIQUIE E LA FORGIA', 'MISSIONS & LEVEL': 'MISSIONI E LIVELLO',
    'g.run': 'Tocca ovunque per cambiare corsia. Schiva le punte: un colpo chiude la partita. Sfiora una punta per una <b>SFIORATA</b>; le catene moltiplicano il punteggio. Quando lo schermo lampeggia <b class="g-red">TEMPESTA</b>, sopravvivi: le gemme pagano doppio.',
    'g.gems': 'Ogni partita paga gemme, moltiplicate dalla tua pista: da Loop ×1 fino a Prism ×20. Spendile in <b>STILE</b> per piste, skin e scie. Ogni giorno ti aspetta un bonus gratis dove vedi <b class="g-gem">50 GRATIS</b>.',
    'g.descent': 'Sopravvivi abbastanza e la partita <b>scende</b> in Sfere più profonde. Il profondo è più ricco: scegli <b>RELIQUIE</b> a metà partita (patti potenti, alcuni maledetti), duelli con i <b class="g-red">GUARDIANI</b> e guadagni <span class="soul">◇</span> <b>ANIME</b> in base alla profondità.',
    'g.forge': 'Ogni reliquia scelta viene registrata in <b>STILE › RELIQUIE</b>. Spendi Anime per <b>sintonizzarne</b> una e seminarla nel tuo Patto iniziale: partirà attiva in ogni partita personale.',
    'g.daily': 'Un tentativo classificato al giorno: la stessa identica partita per tutti i giocatori. Supera i 30s e vinci 100 <span class="gem">◆</span>. Ritirare il premio ogni giorno fa crescere la serie fino a 150 <span class="gem">◆</span> al giorno.',
    'g.missions': 'Le missioni pagano gemme e vengono sostituite appena le completi. Le partite fanno salire anche il tuo livello giocatore: ogni livello paga un bonus di gemme.',
    'g.shop': 'Pacchetti di gemme se vuoi sbloccare più in fretta, e l’<b class="g-gold">ULTRA PASS</b>: ×3 gemme da ogni partita per sempre, più un regalo giornaliero di 500 gemme.'
  };

  D.ru = {
    'HOME': 'ГЛАВНАЯ', 'GEAR': 'ВЕЩИ', 'SHOP': 'МАГАЗИН', 'MORE': 'ЕЩЁ',
    'TRACKS': 'ТРАССЫ', 'THEMES': 'ТЕМЫ', 'SKINS': 'СКИНЫ', 'TRAILS': 'СЛЕДЫ', 'RELICS': 'РЕЛИКВИИ',
    'PLAY': 'ИГРАТЬ', 'DAILY RUN': 'ЗАБЕГ ДНЯ',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'бесконечно · без поражений',
    'beat {n}s · win 100 {gem}': 'продержись {n}с · получи 100 {gem}',
    'BEST': 'РЕКОРД', 'LV': 'УР', 'MISSIONS': 'ЗАДАНИЯ', 'WIN {gem}{n}': 'ПРИЗ {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  50 {gem} БЕСПЛАТНО',
    'watch ad · once a day': 'посмотри рекламу · раз в день',
    'tap to switch lanes · dodge the spikes': 'тапай, чтобы менять полосу · уклоняйся от шипов',
    'higher multiplier · more {gem} every run': 'выше множитель · больше {gem} за забег',
    'world colors · free to switch': 'цвета мира · переключай бесплатно',
    'unlock with {gem} · sets your glow': 'открой за {gem} · задаёт твоё свечение',
    'unlock with {gem} gems': 'открой за кристаллы {gem}',
    'found in the Descent · attune with {soul}': 'из Спуска · настраивай за {soul}',
    '{n} worlds': 'миров: {n}', '{x}/{y} found': 'найдено {x}/{y}',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'ТРАССЫ умножают твои {gem}. ТЕМЫ, СКИНЫ и СЛЕДЫ — чистый стиль. РЕЛИКВИИ приходят из глубоких забегов — из Спуска.',
    'GOT IT': 'ПОНЯТНО', 'SOULS': 'ДУШИ', 'SEED': 'СЕМЯ',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'Реликвии выпадают в СПУСКЕ: продержись подольше и выбирай их прямо в забеге. Глубина же платит Души, которыми их настраивают.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'Тапни реликвию, чтобы прочитать её эффект; тапни ещё раз, чтобы настроить её в стартовый Пакт.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      'Неоткрытая реликвия (ранг {n}) — выбери её в забеге, чтобы открыть.',
    'Seeded into your opening Pact — tap again to remove.': 'Посеяна в стартовый Пакт; тапни ещё раз, чтобы убрать.',
    'Attuned — tap again to seed it into your Pact.': 'Настроена; тапни ещё раз, чтобы посеять её в Пакт.',
    'Tap again to attune for {n} Souls.': 'Тапни ещё раз: настройка за {n} Душ.',
    'Costs {n} Souls to attune (you have {x}).': 'Настройка стоит {n} Душ (у тебя {x}).',
    'SEEDED': 'ПОСЕЯНА',
    'classic': 'классика', '+gems': '+кристаллы', '+power-ups': '+бонусы', 'magnets': 'магниты',
    'feasts': 'пиры', '+1 ◆/gem': '+1 ◆/кристалл', '+2 ◆/gem': '+2 ◆/кристалл', 'magnets+': 'магниты+', 'rich gems': 'богатые россыпи',
    'YOU HAVE': 'У ТЕБЯ',
    '×3 gems from every run — forever': '×3 кристалла с каждого забега — навсегда',
    '+500 {gem} gift every day': '+500 {gem} в подарок каждый день',
    'POPULAR': 'ПОПУЛЯРНО', 'BEST VALUE': 'ВЫГОДНЕЕ ВСЕГО', 'OWNED': 'КУПЛЕНО', 'ACTIVE ×3': 'АКТИВЕН ×3',
    'REMOVE ADS': 'УБРАТЬ РЕКЛАМУ',
    'gems are earned every run — plus a free bonus daily': 'кристаллы приносит каждый забег, плюс ежедневный бесплатный бонус',
    'purchases support development': 'покупки поддерживают разработку',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass активен: ×3 на все заработанные кристаллы',
    'store unavailable — try again later': 'магазин недоступен — попробуй позже',
    'RESTORE PURCHASES': 'ВОССТАНОВИТЬ ПОКУПКИ', 'restoring…': 'восстановление…',
    'restore failed — check your connection and try again': 'не удалось восстановить: проверь соединение и попробуй ещё раз',
    'purchases restored — thank you!': 'покупки восстановлены — спасибо!',
    'nothing to restore on this account': 'на этом аккаунте нечего восстанавливать',
    'HOW TO PLAY': 'КАК ИГРАТЬ', 'the run · gems · the Descent': 'забег · кристаллы · Спуск',
    'descent records · seed race': 'рекорды Спуска · гонка семян',
    'STATS': 'СТАТИСТИКА', 'lifetime records': 'рекорды за всё время',
    'LEADERBOARD': 'РЕЙТИНГ', 'compare with the world': 'сравни себя с миром',
    'SETTINGS': 'НАСТРОЙКИ', 'sound · haptics · accessibility': 'звук · вибрация · доступность',
    'Sound effects': 'Звуковые эффекты', 'Music': 'Музыка', 'Reduce flashing': 'Меньше вспышек',
    'Haptics': 'Вибрация', 'Reduce motion': 'Меньше движения', 'Ghost racer': 'Призрак-соперник',
    'Ad privacy options': 'Приватность рекламы', 'Delete custom photo': 'Удалить своё фото',
    'Reset all progress': 'Сбросить весь прогресс', 'Tap again to ERASE everything': 'Тапни ещё раз, чтобы СТЕРЕТЬ всё',
    'Language': 'Язык', 'AUTO': 'АВТО', 'ON': 'ВКЛ', 'OFF': 'ВЫКЛ', 'FULL': 'СИЛЬНАЯ', 'LIGHT': 'ЛЁГКАЯ',
    'DAILY REWARD': 'НАГРАДА ДНЯ', 'DAY {n}': 'ДЕНЬ {n}', 'CLAIM': 'ЗАБРАТЬ',
    '▶︎  KEEP STREAK': '▶︎  СПАСТИ СЕРИЮ', 'watch ad': 'посмотри рекламу',
    'CUSTOM SKIN': 'СВОЙ СКИН', 'turn any photo into your ball': 'преврати любое фото в свой шар',
    'UNLOCK {gem}600': 'ОТКРЫТЬ {gem}600', '▶︎  WATCH AD': '▶︎  СМОТРЕТЬ РЕКЛАМУ',
    'free unlock': 'бесплатная разблокировка', 'CANCEL': 'ОТМЕНА', 'CLOSE': 'ЗАКРЫТЬ',
    'SCORE': 'СЧЁТ', 'NEW BEST!': 'НОВЫЙ РЕКОРД!',
    'NEAR MISSES': 'ВПРИТИРКУ', 'BEST COMBO': 'ЛУЧШЕЕ КОМБО',
    'DESCENT · SPHERE': 'СПУСК · СФЕРА', 'souls earned': 'душ заработано',
    'PLAY AGAIN': 'ЕЩЁ РАЗ', 'MENU': 'МЕНЮ', '▶︎ REVIVE': '▶︎ ВОЗРОДИТЬСЯ', '×2 GEMS': '×2 КРИСТАЛЛЫ',
    'NEXT: {name} {gem} {x}/{y}': 'ДАЛЬШЕ: {name} {gem} {x}/{y}',
    'PAUSED': 'ПАУЗА', 'tap to resume': 'тапни, чтобы продолжить', 'LEVEL UP!': 'НОВЫЙ УРОВЕНЬ!',
    'BEST SCORE': 'ЛУЧШИЙ СЧЁТ', 'BEST SURVIVAL': 'ДОЛЬШЕ ВСЕГО ПРОДЕРЖАЛСЯ', 'PLAYER LEVEL': 'УРОВЕНЬ ИГРОКА',
    'RUNS': 'ЗАБЕГИ', 'TIME PLAYED': 'ВРЕМЯ В ИГРЕ', 'GEMS COLLECTED': 'КРИСТАЛЛОВ СОБРАНО',
    'STORMS WEATHERED': 'БУРЬ ПЕРЕЖИТО', 'MISSIONS DONE': 'ЗАДАНИЙ ВЫПОЛНЕНО',
    'DEEPEST SPHERE': 'ГЛУБОЧАЙШАЯ СФЕРА', 'SOULS EARNED': 'ДУШ ЗАРАБОТАНО',
    'RELICS FOUND': 'РЕЛИКВИЙ НАЙДЕНО', 'WARDENS FELLED': 'СТРАЖЕЙ ПОВЕРЖЕНО',
    'DEEPEST · SPHERE': 'ГЛУБИНА · СФЕРА', 'BEST DAILY': 'ЛУЧШИЙ ЗАБЕГ ДНЯ',
    "TODAY'S SEED": 'СЕМЯ ДНЯ',
    "race a friend's run — enter their seed code": 'посоревнуйся с забегом друга: введи его код семени',
    'RACE THIS SEED': 'БЕЖАТЬ ЭТО СЕМЯ',
    'TAP TO SWITCH LANES': 'ТАПАЙ, ЧТОБЫ МЕНЯТЬ ПОЛОСУ',
    'NEAR MISS': 'ВПРИТИРКУ', 'NEAR MISS ×{n}': 'ВПРИТИРКУ ×{n}', 'STORM': 'БУРЯ',
    'POT': 'БАНК', 'RIDING': 'НА КОНУ', 'BEST!': 'РЕКОРД!', 'PASSED YOUR GHOST': 'ПРИЗРАК ПОЗАДИ',
    'SPHERE {r}': 'СФЕРА {r}', '✔ WARDEN FELLED': '✔ СТРАЖ ПОВЕРЖЕН', '× EXIT': '× ВЫЙТИ',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'СОВЕТ: трать ◆ в разделе ВЕЩИ — трассы умножают заработок',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ДУШИ ПОЛУЧЕНЫ: настрой Реликвии в ВЕЩИ › РЕЛИКВИИ',
    'Daily challenge beaten': 'Забег дня пройден',
    'Survive {n}s in one run': 'Продержись {n}с за один забег',
    'Collect {n} ◆ in one run': 'Собери {n} ◆ за один забег',
    'Collect {n} ◆ in total': 'Собери {n} ◆ всего',
    'Finish {n} runs': 'Заверши {n} забегов',
    'Finish a run on {track}': 'Заверши забег на трассе {track}',
    'Switch lanes {n}× in one run': 'Смени полосу {n} раз за один забег',
    'Near-miss {n} spikes in one run': 'Пройди впритирку {n} шипов за забег',
    'Reach player level {n}': 'Достигни уровня игрока {n}',
    'THE RUN': 'ЗАБЕГ', 'GEMS': 'КРИСТАЛЛЫ', 'THE DESCENT': 'СПУСК',
    'RELICS & THE FORGE': 'РЕЛИКВИИ И КУЗНИЦА', 'MISSIONS & LEVEL': 'ЗАДАНИЯ И УРОВЕНЬ',
    'g.run': 'Тапай в любом месте, чтобы сменить полосу. Уклоняйся от шипов — одно касание завершает забег. Пройди впритирку к шипу — это <b>ВПРИТИРКУ</b>; цепочки умножают счёт. Когда экран мигает <b class="g-red">БУРЯ</b>, переживи её: кристаллы платят вдвойне.',
    'g.gems': 'Каждый забег приносит кристаллы, умноженные на твою трассу: от Loop ×1 до Prism ×20. Трать их в разделе <b>ВЕЩИ</b> на трассы, скины и следы. Каждый день ждёт бесплатный бонус там, где видишь <b class="g-gem">50 БЕСПЛАТНО</b>.',
    'g.descent': 'Продержись достаточно долго — и забег <b>спускается</b> в более глубокие Сферы. Глубина щедрее: прямо в забеге выбираешь <b>РЕЛИКВИИ</b> (мощные пакты, есть и проклятые), сражаешься со <b class="g-red">СТРАЖАМИ</b> и получаешь <span class="soul">◇</span> <b>ДУШИ</b> за глубину.',
    'g.forge': 'Каждая выбранная реликвия записывается в <b>ВЕЩИ › РЕЛИКВИИ</b>. Трать Души, чтобы <b>настроить</b> одну и посеять её в стартовый Пакт — она будет активна в каждом личном забеге.',
    'g.daily': 'Одна рейтинговая попытка в день — абсолютно тот же забег у всех игроков планеты. Продержись 30с и получи 100 <span class="gem">◆</span>. Забирай награду каждый день — серия растёт до 150 <span class="gem">◆</span> в день.',
    'g.missions': 'Задания платят кристаллы и сразу заменяются новыми после выполнения. Забеги также растят уровень игрока — каждый уровень платит бонус кристаллов.',
    'g.shop': 'Наборы кристаллов, если хочешь открывать быстрее, и <b class="g-gold">ULTRA PASS</b>: ×3 кристалла с каждого забега навсегда, плюс ежедневный подарок в 500 кристаллов.'
  };

  D.ja = {
    'HOME': 'ホーム', 'GEAR': 'ギア', 'SHOP': 'ショップ', 'MORE': 'その他',
    'TRACKS': 'コース', 'THEMES': 'テーマ', 'SKINS': 'スキン', 'TRAILS': '軌跡', 'RELICS': 'レリック',
    'PLAY': 'プレイ', 'DAILY RUN': 'デイリーラン',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': 'エンドレス · 失敗なし',
    'beat {n}s · win 100 {gem}': '{n}秒突破で100 {gem}獲得',
    'BEST': 'ベスト', 'LV': 'LV', 'MISSIONS': 'ミッション', 'WIN {gem}{n}': '報酬 {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  無料で50 {gem}',
    'watch ad · once a day': '広告を見る · 1日1回',
    'tap to switch lanes · dodge the spikes': 'タップでレーン切替 · トゲをよけろ',
    'higher multiplier · more {gem} every run': '倍率アップで毎回の{gem}が増える',
    'world colors · free to switch': 'ワールドの配色 · 無料で切替',
    'unlock with {gem} · sets your glow': '{gem}で解放 · 光の色が変わる',
    'unlock with {gem} gems': '{gem}ジェムで解放',
    'found in the Descent · attune with {soul}': 'ディセントで発見 · {soul}で同調',
    '{n} worlds': '{n}ワールド', '{x}/{y} found': '発見 {x}/{y}',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      'コースは獲得{gem}を倍増させる。テーマ・スキン・軌跡は見た目だけ。レリックは深層ラン「ディセント」で手に入る。',
    'GOT IT': 'OK', 'SOULS': 'ソウル', 'SEED': 'シード',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      'レリックはディセントでドロップ。深くまで生き延びてラン中に獲得しよう。深度に応じて同調用のソウルも手に入る。',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      'レリックをタップで効果を確認。もう一度タップで開始パクトに同調。',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      '未発見のレリック（ティア{n}）。ラン中に獲得して解放しよう。',
    'Seeded into your opening Pact — tap again to remove.': '開始パクトにセット済み。もう一度タップで外す。',
    'Attuned — tap again to seed it into your Pact.': '同調済み。もう一度タップでパクトにセット。',
    'Tap again to attune for {n} Souls.': 'もう一度タップでソウル{n}で同調。',
    'Costs {n} Souls to attune (you have {x}).': '同調にはソウル{n}が必要（所持: {x}）。',
    'SEEDED': 'セット中',
    'classic': 'クラシック', '+gems': '+ジェム', '+power-ups': '+パワーアップ', 'magnets': 'マグネット',
    'feasts': 'フィースト', '+1 ◆/gem': '+1 ◆/個', '+2 ◆/gem': '+2 ◆/個', 'magnets+': 'マグネット+', 'rich gems': '高級ジェム',
    'YOU HAVE': '所持',
    '×3 gems from every run — forever': '毎回のジェムが永久に×3',
    '+500 {gem} gift every day': '毎日+500 {gem}プレゼント',
    'POPULAR': '人気', 'BEST VALUE': '一番お得', 'OWNED': '購入済み', 'ACTIVE ×3': '有効 ×3',
    'REMOVE ADS': '広告を消す',
    'gems are earned every run — plus a free bonus daily': 'ジェムは毎回のランで獲得。さらに毎日無料ボーナスも',
    'purchases support development': '購入は開発の支えになります',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass有効：獲得ジェムすべて×3',
    'store unavailable — try again later': 'ストアに接続できません。後でもう一度お試しください',
    'RESTORE PURCHASES': '購入を復元', 'restoring…': '復元中…',
    'restore failed — check your connection and try again': '復元に失敗しました。接続を確認して再試行してください',
    'purchases restored — thank you!': '購入を復元しました。ありがとうございます！',
    'nothing to restore on this account': 'このアカウントに復元できる購入はありません',
    'HOW TO PLAY': 'あそびかた', 'the run · gems · the Descent': 'ラン · ジェム · ディセント',
    'descent records · seed race': 'ディセント記録 · シードレース',
    'STATS': '統計', 'lifetime records': '通算記録',
    'LEADERBOARD': 'ランキング', 'compare with the world': '世界と競おう',
    'SETTINGS': '設定', 'sound · haptics · accessibility': 'サウンド · 振動 · アクセシビリティ',
    'Sound effects': '効果音', 'Music': '音楽', 'Reduce flashing': '点滅を減らす',
    'Haptics': '振動', 'Reduce motion': '動きを減らす', 'Ghost racer': 'ゴーストレーサー',
    'Ad privacy options': '広告プライバシー', 'Delete custom photo': 'カスタム写真を削除',
    'Reset all progress': '進行データを全消去', 'Tap again to ERASE everything': 'もう一度タップで完全消去',
    'Language': '言語', 'AUTO': '自動', 'ON': 'オン', 'OFF': 'オフ', 'FULL': '強', 'LIGHT': '弱',
    'DAILY REWARD': 'デイリー報酬', 'DAY {n}': '{n}日目', 'CLAIM': '受け取る',
    '▶︎  KEEP STREAK': '▶︎  連続記録を守る', 'watch ad': '広告を見る',
    'CUSTOM SKIN': 'カスタムスキン', 'turn any photo into your ball': '好きな写真をボールにしよう',
    'UNLOCK {gem}600': '{gem}600で解放', '▶︎  WATCH AD': '▶︎  広告を見る',
    'free unlock': '無料で解放', 'CANCEL': 'キャンセル', 'CLOSE': '閉じる',
    'SCORE': 'スコア', 'NEW BEST!': '自己ベスト更新！',
    'NEAR MISSES': 'ニアミス', 'BEST COMBO': '最高コンボ',
    'DESCENT · SPHERE': 'ディセント · スフィア', 'souls earned': 'ソウル獲得',
    'PLAY AGAIN': 'もう一回', 'MENU': 'メニュー', '▶︎ REVIVE': '▶︎ 復活', '×2 GEMS': 'ジェム×2',
    'NEXT: {name} {gem} {x}/{y}': '次: {name} {gem} {x}/{y}',
    'PAUSED': '一時停止', 'tap to resume': 'タップで再開', 'LEVEL UP!': 'レベルアップ！',
    'BEST SCORE': 'ベストスコア', 'BEST SURVIVAL': '最長サバイバル', 'PLAYER LEVEL': 'プレイヤーレベル',
    'RUNS': 'ラン数', 'TIME PLAYED': 'プレイ時間', 'GEMS COLLECTED': '獲得ジェム',
    'STORMS WEATHERED': 'ストーム克服', 'MISSIONS DONE': 'ミッション達成',
    'DEEPEST SPHERE': '最深スフィア', 'SOULS EARNED': 'ソウル獲得',
    'RELICS FOUND': 'レリック発見', 'WARDENS FELLED': 'ウォーデン撃破',
    'DEEPEST · SPHERE': '最深 · スフィア', 'BEST DAILY': 'デイリー最高',
    "TODAY'S SEED": '今日のシード',
    "race a friend's run — enter their seed code": '友だちのランと競争：シードコードを入力',
    'RACE THIS SEED': 'このシードで走る',
    'TAP TO SWITCH LANES': 'タップでレーン切替',
    'NEAR MISS': 'ニアミス', 'NEAR MISS ×{n}': 'ニアミス ×{n}', 'STORM': 'ストーム',
    'POT': 'ポット', 'RIDING': '賭け中', 'BEST!': 'ベスト！', 'PASSED YOUR GHOST': 'ゴーストを抜いた！',
    'SPHERE {r}': 'スフィア {r}', '✔ WARDEN FELLED': '✔ ウォーデン撃破', '× EXIT': '× 終了',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': 'ヒント：◆はギアで使おう。コースが獲得量を倍増させる',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ ソウル獲得！ギア › レリックで同調しよう',
    'Daily challenge beaten': 'デイリーチャレンジ達成',
    'Survive {n}s in one run': '1回のランで{n}秒生き残る',
    'Collect {n} ◆ in one run': '1回のランで◆を{n}個集める',
    'Collect {n} ◆ in total': '合計で◆を{n}個集める',
    'Finish {n} runs': 'ランを{n}回完了する',
    'Finish a run on {track}': '{track}でランを完了する',
    'Switch lanes {n}× in one run': '1回のランでレーンを{n}回切り替える',
    'Near-miss {n} spikes in one run': '1回のランでトゲを{n}回ニアミスする',
    'Reach player level {n}': 'プレイヤーレベル{n}に到達する',
    'THE RUN': 'ラン', 'GEMS': 'ジェム', 'THE DESCENT': 'ディセント',
    'RELICS & THE FORGE': 'レリックと鍛冶場', 'MISSIONS & LEVEL': 'ミッションとレベル',
    'g.run': 'どこでもタップでレーン切替。トゲに当たったらランは終了。トゲすれすれを通ると<b>ニアミス</b>となり、連続で決めるとスコアが倍増。画面に<b class="g-red">ストーム</b>が出たら生き延びろ。ジェムが2倍になる。',
    'g.gems': 'ランのたびにジェムを獲得。コースの倍率がかかる（Loop ×1〜Prism ×20）。ジェムは<b>ギア</b>でコース・スキン・軌跡に使おう。<b class="g-gem">無料で50</b>の表示があれば毎日ボーナスがもらえる。',
    'g.descent': '長く生き延びるとランはより深いスフィアへ<b>降下</b>していく。深層ほど豊か：ラン中に<b>レリック</b>（強力なパクト、呪われたものも）を選び、<b class="g-red">ウォーデン</b>と戦い、深度に応じて<span class="soul">◇</span><b>ソウル</b>を獲得。',
    'g.forge': '獲得したレリックは<b>ギア › レリック</b>に記録される。ソウルで<b>同調</b>してシードにセットすれば、毎回のランで最初から有効になる。',
    'g.daily': '1日1回のランク戦。全プレイヤーが完全に同じランに挑む。30秒突破で100 <span class="gem">◆</span>獲得。毎日報酬を受け取れば連続ボーナスは1日150 <span class="gem">◆</span>まで成長。',
    'g.missions': 'ミッションはジェムを支払い、達成した瞬間に新しいものと入れ替わる。ランでプレイヤーレベルも上がり、レベルごとにジェムボーナスがもらえる。',
    'g.shop': '早く解放したいならジェムパック。そして<b class="g-gold">ULTRA PASS</b>：毎回のランのジェムが永久に×3、さらに毎日500ジェムのプレゼント付き。'
  };

  D.ko = {
    'HOME': '홈', 'GEAR': '장비', 'SHOP': '상점', 'MORE': '더보기',
    'TRACKS': '트랙', 'THEMES': '테마', 'SKINS': '스킨', 'TRAILS': '트레일', 'RELICS': '유물',
    'PLAY': '플레이', 'DAILY RUN': '데일리 런',
    'ZEN DRIFT': 'ZEN DRIFT', 'endless · no fail': '무한 · 실패 없음',
    'beat {n}s · win 100 {gem}': '{n}초 돌파 시 100 {gem} 획득',
    'BEST': '최고 기록', 'LV': 'LV', 'MISSIONS': '미션', 'WIN {gem}{n}': '보상 {gem}{n}',
    '▶︎  FREE 50 {gem}': '▶︎  무료 50 {gem}',
    'watch ad · once a day': '광고 시청 · 하루 1회',
    'tap to switch lanes · dodge the spikes': '탭해서 차선 변경 · 가시를 피하세요',
    'higher multiplier · more {gem} every run': '배율이 높을수록 매 런마다 {gem}이 늘어남',
    'world colors · free to switch': '월드 색상 · 무료로 변경',
    'unlock with {gem} · sets your glow': '{gem}으로 해금 · 글로우 색상 결정',
    'unlock with {gem} gems': '{gem} 젬으로 해금',
    'found in the Descent · attune with {soul}': '디센트에서 발견 · {soul}로 조율',
    '{n} worlds': '월드 {n}개', '{x}/{y} found': '발견 {x}/{y}',
    'TRACKS multiply the {gem} you earn. THEMES, SKINS & TRAILS are pure style. RELICS come from deep runs — the Descent.':
      '트랙은 획득하는 {gem}을 배로 늘립니다. 테마·스킨·트레일은 순수한 스타일. 유물은 깊은 런, 디센트에서 얻습니다.',
    'GOT IT': '확인', 'SOULS': '소울', 'SEED': '시드',
    'Relics drop in the DESCENT — survive deep into a run and draft them mid-run. Depth also pays the Souls that attune them.':
      '유물은 디센트에서 드롭됩니다. 깊이 생존해 런 도중에 선택하세요. 깊이에 따라 조율에 쓰는 소울도 얻습니다.',
    'Tap a relic to read what it does — tap again to attune it into your opening Pact.':
      '유물을 탭해 효과를 확인하고, 한 번 더 탭해 시작 계약에 조율하세요.',
    'Undiscovered relic (tier {n}) — draft it during a run to unlock it.':
      '미발견 유물(티어 {n}) — 런 중에 선택하면 해금됩니다.',
    'Seeded into your opening Pact — tap again to remove.': '시작 계약에 장착됨. 한 번 더 탭하면 해제됩니다.',
    'Attuned — tap again to seed it into your Pact.': '조율 완료. 한 번 더 탭하면 계약에 장착됩니다.',
    'Tap again to attune for {n} Souls.': '한 번 더 탭하면 소울 {n}으로 조율합니다.',
    'Costs {n} Souls to attune (you have {x}).': '조율 비용은 소울 {n} (보유: {x}).',
    'SEEDED': '장착됨',
    'classic': '클래식', '+gems': '+젬', '+power-ups': '+파워업', 'magnets': '자석',
    'feasts': '축제', '+1 ◆/gem': '+1 ◆/개', '+2 ◆/gem': '+2 ◆/개', 'magnets+': '자석+', 'rich gems': '고급 젬',
    'YOU HAVE': '보유',
    '×3 gems from every run — forever': '모든 런에서 젬 ×3 — 영구 지속',
    '+500 {gem} gift every day': '매일 +500 {gem} 선물',
    'POPULAR': '인기', 'BEST VALUE': '최고 가성비', 'OWNED': '보유 중', 'ACTIVE ×3': '활성 ×3',
    'REMOVE ADS': '광고 제거',
    'gems are earned every run — plus a free bonus daily': '젬은 매 런마다 획득. 매일 무료 보너스까지',
    'purchases support development': '구매는 개발에 큰 힘이 됩니다',
    'Ultra Pass active — ×3 on all earned gems': 'Ultra Pass 활성: 획득 젬 전부 ×3',
    'store unavailable — try again later': '상점에 연결할 수 없습니다. 나중에 다시 시도하세요',
    'RESTORE PURCHASES': '구매 복원', 'restoring…': '복원 중…',
    'restore failed — check your connection and try again': '복원 실패: 연결을 확인하고 다시 시도하세요',
    'purchases restored — thank you!': '구매가 복원되었습니다. 감사합니다!',
    'nothing to restore on this account': '이 계정에는 복원할 구매가 없습니다',
    'HOW TO PLAY': '게임 방법', 'the run · gems · the Descent': '런 · 젬 · 디센트',
    'descent records · seed race': '디센트 기록 · 시드 레이스',
    'STATS': '통계', 'lifetime records': '통산 기록',
    'LEADERBOARD': '리더보드', 'compare with the world': '전 세계와 겨루세요',
    'SETTINGS': '설정', 'sound · haptics · accessibility': '사운드 · 진동 · 접근성',
    'Sound effects': '효과음', 'Music': '음악', 'Reduce flashing': '깜빡임 줄이기',
    'Haptics': '진동', 'Reduce motion': '모션 줄이기', 'Ghost racer': '고스트 레이서',
    'Ad privacy options': '광고 개인정보 설정', 'Delete custom photo': '커스텀 사진 삭제',
    'Reset all progress': '모든 진행 초기화', 'Tap again to ERASE everything': '한 번 더 탭하면 전부 삭제됩니다',
    'Language': '언어', 'AUTO': '자동', 'ON': '켬', 'OFF': '끔', 'FULL': '강하게', 'LIGHT': '약하게',
    'DAILY REWARD': '일일 보상', 'DAY {n}': '{n}일 차', 'CLAIM': '받기',
    '▶︎  KEEP STREAK': '▶︎  연속 기록 지키기', 'watch ad': '광고 시청',
    'CUSTOM SKIN': '커스텀 스킨', 'turn any photo into your ball': '어떤 사진이든 나만의 볼로',
    'UNLOCK {gem}600': '{gem}600으로 해금', '▶︎  WATCH AD': '▶︎  광고 보기',
    'free unlock': '무료 해금', 'CANCEL': '취소', 'CLOSE': '닫기',
    'SCORE': '점수', 'NEW BEST!': '신기록!',
    'NEAR MISSES': '아슬아슬', 'BEST COMBO': '최고 콤보',
    'DESCENT · SPHERE': '디센트 · 스피어', 'souls earned': '소울 획득',
    'PLAY AGAIN': '다시 하기', 'MENU': '메뉴', '▶︎ REVIVE': '▶︎ 부활', '×2 GEMS': '젬 ×2',
    'NEXT: {name} {gem} {x}/{y}': '다음: {name} {gem} {x}/{y}',
    'PAUSED': '일시정지', 'tap to resume': '탭해서 계속', 'LEVEL UP!': '레벨 업!',
    'BEST SCORE': '최고 점수', 'BEST SURVIVAL': '최장 생존', 'PLAYER LEVEL': '플레이어 레벨',
    'RUNS': '런 횟수', 'TIME PLAYED': '플레이 시간', 'GEMS COLLECTED': '획득한 젬',
    'STORMS WEATHERED': '폭풍 생존', 'MISSIONS DONE': '완료한 미션',
    'DEEPEST SPHERE': '최심 스피어', 'SOULS EARNED': '획득한 소울',
    'RELICS FOUND': '발견한 유물', 'WARDENS FELLED': '처치한 워든',
    'DEEPEST · SPHERE': '최심 기록 · 스피어', 'BEST DAILY': '데일리 최고',
    "TODAY'S SEED": '오늘의 시드',
    "race a friend's run — enter their seed code": '친구의 런과 경쟁하세요: 시드 코드를 입력',
    'RACE THIS SEED': '이 시드로 달리기',
    'TAP TO SWITCH LANES': '탭해서 차선 변경',
    'NEAR MISS': '아슬아슬', 'NEAR MISS ×{n}': '아슬아슬 ×{n}', 'STORM': '폭풍',
    'POT': '팟', 'RIDING': '베팅 중', 'BEST!': '신기록!', 'PASSED YOUR GHOST': '고스트 추월!',
    'SPHERE {r}': '스피어 {r}', '✔ WARDEN FELLED': '✔ 워든 처치', '× EXIT': '× 나가기',
    'TIP — spend your ◆ in GEAR: tracks multiply your earnings': '팁: ◆는 장비에서 쓰세요. 트랙이 수익을 배로 늘립니다',
    '◇ SOULS EARNED — attune Relics in GEAR › RELICS': '◇ 소울 획득! 장비 › 유물에서 조율하세요',
    'Daily challenge beaten': '데일리 챌린지 성공',
    'Survive {n}s in one run': '한 번의 런에서 {n}초 생존',
    'Collect {n} ◆ in one run': '한 번의 런에서 ◆ {n}개 수집',
    'Collect {n} ◆ in total': '총 ◆ {n}개 수집',
    'Finish {n} runs': '런 {n}회 완료',
    'Finish a run on {track}': '{track}에서 런 완료',
    'Switch lanes {n}× in one run': '한 번의 런에서 차선 {n}회 변경',
    'Near-miss {n} spikes in one run': '한 번의 런에서 가시 {n}개 아슬아슬 통과',
    'Reach player level {n}': '플레이어 레벨 {n} 달성',
    'THE RUN': '런', 'GEMS': '젬', 'THE DESCENT': '디센트',
    'RELICS & THE FORGE': '유물과 대장간', 'MISSIONS & LEVEL': '미션과 레벨',
    'g.run': '아무 곳이나 탭하면 차선이 바뀝니다. 가시를 피하세요. 한 번 부딪히면 런이 끝납니다. 가시를 아슬아슬하게 스치면 <b>아슬아슬</b>! 연속으로 이어가면 점수가 배가 됩니다. 화면에 <b class="g-red">폭풍</b>이 번쩍이면 살아남으세요. 젬이 2배가 됩니다.',
    'g.gems': '모든 런은 젬을 지급하며 트랙 배율이 곱해집니다(Loop ×1 ~ Prism ×20). 젬은 <b>장비</b>에서 트랙·스킨·트레일에 쓰세요. <b class="g-gem">무료 50</b>이 보이면 매일 무료 보너스를 받을 수 있습니다.',
    'g.descent': '충분히 오래 살아남으면 런이 더 깊은 스피어로 <b>하강</b>합니다. 깊을수록 풍성합니다: 런 도중 <b>유물</b>(강력한 계약, 일부는 저주받음)을 선택하고 <b class="g-red">워든</b>과 결투하며 깊이에 따라 <span class="soul">◇</span> <b>소울</b>을 얻습니다.',
    'g.forge': '선택한 유물은 모두 <b>장비 › 유물</b>에 기록됩니다. 소울로 하나를 <b>조율</b>해 시작 계약에 장착하면 모든 개인 런에서 처음부터 발동됩니다.',
    'g.daily': '하루 한 번의 랭크 도전 — 전 세계 모두가 완전히 같은 런에 도전합니다. 30초를 돌파하면 100 <span class="gem">◆</span> 획득. 매일 보상을 받으면 연속 보상이 하루 150 <span class="gem">◆</span>까지 커집니다.',
    'g.missions': '미션은 젬을 지급하고 완료하는 즉시 새 미션으로 바뀝니다. 런은 플레이어 레벨도 올려주며, 레벨마다 젬 보너스를 받습니다.',
    'g.shop': '더 빨리 해금하고 싶다면 젬 팩, 그리고 <b class="g-gold">ULTRA PASS</b>: 모든 런의 젬이 영구히 ×3, 매일 젬 500개 선물까지.'
  };

  /* ---------- resolution ---------- */

  var locale = 'en';

  function normalize(tag) {
    if (!tag) return '';
    var lower = String(tag).toLowerCase();
    var base = lower.split('-')[0];
    return SUPPORTED.indexOf(base) !== -1 ? base : '';
  }

  function detect() {
    try {
      var nav = (typeof navigator !== 'undefined') ? navigator : null;
      if (!nav) return 'en';
      var cands = [];
      if (nav.languages && nav.languages.length) cands = cands.concat(nav.languages);
      if (nav.language) cands.push(nav.language);
      for (var i = 0; i < cands.length; i++) {
        var hit = normalize(cands[i]);
        if (hit) return hit;
      }
    } catch (e) { /* detection is best-effort */ }
    return 'en';
  }

  function resolve() {
    var saved = (typeof Store !== 'undefined' && Store.getLang) ? Store.getLang() : '';
    locale = normalize(saved) || detect();
    if (typeof document !== 'undefined' && document.documentElement) {
      document.documentElement.lang = locale;
    }
  }

  /* ---------- lookup ---------- */

  var GLYPHS = {
    gem: '<span class="gem">◆</span>',
    soul: '<span class="soul">◇</span>'
  };

  function sub(str, params) {
    return str.replace(/\{(\w+)\}/g, function (m, k) {
      if (GLYPHS[k]) return GLYPHS[k];
      if (params && params[k] !== undefined) return String(params[k]);
      return m;
    });
  }

  /* t('KEY', {n: 3}) — English key in, localized (fallback: English) out.
   * {gem}/{soul} become glyph spans, so t() output is for innerHTML when
   * the key uses them (plain textContent otherwise). */
  function t(key, params) {
    var d = D[locale];
    var s = (d && d[key] !== undefined) ? d[key] : key;
    return (params || s.indexOf('{') !== -1) ? sub(s, params) : s;
  }

  /* ---------- static DOM ---------- */

  /* Translate every [data-i18n] element. Values with markup or glyph
   * tokens go through innerHTML; plain strings through textContent.
   *
   * The document's own markup is the English source, captured on the first
   * sweep and restored whenever the active locale has no entry for a key.
   * t() falls back to the KEY, which is right for the usual case (the key
   * IS its English string) but wrong for the HOW TO PLAY bodies: those
   * paragraphs contain markup, so they carry short pseudo-keys ('g.run')
   * and the sweep printed "g.run" on screen for every English player.
   * Capturing also fixes switching a language BACK to English, which would
   * otherwise strand the previous locale's text in any untranslated node. */
  function applyDom() {
    if (typeof document === 'undefined' || !document.querySelectorAll) return;
    var nodes = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var key = el.getAttribute('data-i18n');
      if (el.i18nSrc === undefined) {
        /* Markup elements keep their innerHTML; plain ones are captured as
         * TEXT, because innerHTML re-escapes entities — capturing the
         * authored "RELICS &amp; THE FORGE" and writing it back through
         * textContent would print the ampersand entity on screen. */
        el.i18nSrc = (el.innerHTML.indexOf('<') !== -1) ? el.innerHTML : el.textContent;
      }
      var d = D[locale];
      var val = sub((d && d[key] !== undefined) ? d[key] : el.i18nSrc);
      if (val.indexOf('<') !== -1) el.innerHTML = val;
      else el.textContent = val;
    }
  }

  /* ---------- language switching ---------- */

  function getLang() { // saved override ('' = auto)
    return (typeof Store !== 'undefined' && Store.getLang) ? Store.getLang() : '';
  }

  function setLang(code) { // '' = auto-detect
    if (typeof Store !== 'undefined' && Store.setLang) Store.setLang(code);
    resolve();
    applyDom();
  }

  resolve();

  return {
    t: t,
    applyDom: applyDom,
    setLang: setLang,
    getLang: getLang,
    getLocale: function () { return locale; },
    nativeName: function (code) { return NATIVE[code] || code; },
    SUPPORTED: SUPPORTED,
    /* exposed for tests */
    _detect: detect,
    _dict: D
  };
})();
