/* Google Play Games Services wrapper: leaderboard (best survival
 * time) + achievements.
 *
 * Fail-safe like ads.js: if the native plugin is missing, sign-in is
 * declined, or any call throws, every public method quietly no-ops
 * and the game is completely unaffected. The whole game already
 * calls into this module — lighting it up is configuration only.
 *
 * STATUS: as of mid-2026 there is no maintained Capacitor 8 plugin
 * for Play Games Services v2 (capacitor-game-connect stops at v5,
 * capacitor-google-game-services at v6), so this ships as a wired
 * stub written against the de-facto plugin API (signIn, submitScore,
 * unlockAchievement, showLeaderboard). When a compatible plugin
 * exists, follow PLAY_GAMES_SETUP.md: install it, set PLUGIN_NAME
 * below, and fill in the IDs from Play Console. */
var PlayGames = (function () {

  /* The key on window.Capacitor.Plugins where the plugin registers.
   * 'CapacitorGameConnect' matches @openforge/capacitor-game-connect;
   * change it if you adopt a different plugin. */
  var PLUGIN_NAME = 'CapacitorGameConnect';

  /* IDs from Play Console > Grow > Play Games Services > Setup.
   * Leave the placeholders: with no plugin they are never sent. */
  var IDS = {
    leaderboardBest: 'REPLACE_LEADERBOARD_ID',
    ach: {
      firstRun:   'REPLACE_ACH_FIRST_RUN',    // finish your first run
      survive30:  'REPLACE_ACH_SURVIVE_30',   // survive 30 seconds
      survive60:  'REPLACE_ACH_SURVIVE_60',   // survive 60 seconds
      survive120: 'REPLACE_ACH_SURVIVE_120',  // survive 120 seconds
      skins3:     'REPLACE_ACH_3_SKINS',      // own 3 ball skins
      allTracks:  'REPLACE_ACH_ALL_TRACKS',   // unlock every track
      nearMiss50: 'REPLACE_ACH_50_NEAR',      // 50 lifetime near misses
      missions20: 'REPLACE_ACH_20_MISSIONS'   // complete 20 missions
    }
  };

  var plugin = null;
  var signedIn = false;
  var unlocked = {}; // session cache so we don't re-send every game over

  function init() {
    try {
      if (!(window.Capacitor &&
            typeof window.Capacitor.isNativePlatform === 'function' &&
            window.Capacitor.isNativePlatform() &&
            window.Capacitor.Plugins &&
            window.Capacitor.Plugins[PLUGIN_NAME])) {
        return;
      }
      plugin = window.Capacitor.Plugins[PLUGIN_NAME];
      plugin.signIn()
        .then(function () { signedIn = true; })
        .catch(function () { /* declined/offline: stay silent */ });
    } catch (e) { /* never let Play Games break the game */ }
  }

  /* Best survival time in seconds. Play keeps the max, so submitting
   * every run is fine. */
  function submitScore(seconds) {
    if (!signedIn) return;
    try {
      plugin.submitScore({
        leaderboardID: IDS.leaderboardBest,
        totalScoreAmount: Math.floor(seconds)
      }).catch(function () {});
    } catch (e) { /* no-op */ }
  }

  function unlock(key) {
    if (!signedIn || unlocked[key]) return;
    var id = IDS.ach[key];
    if (!id) return;
    unlocked[key] = true; // optimistic: re-sent next session if it failed
    try {
      plugin.unlockAchievement({ achievementID: id }).catch(function () {});
    } catch (e) { /* no-op */ }
  }

  /* One game-over summary in, every achievement check out. Counters
   * come from Store so progress survives restarts and offline play. */
  function onRunEnd(d) {
    // The leaderboard is "best survival time", so submit pure survival
    // SECONDS (d.seconds) — NOT the hybrid score (which folds in near-miss
    // bonus points). Achievements below already gate on d.seconds, so the
    // leaderboard and achievements now report the same unit.
    submitScore(d.seconds);
    unlock('firstRun');
    if (d.seconds >= 30) unlock('survive30');
    if (d.seconds >= 60) unlock('survive60');
    if (d.seconds >= 120) unlock('survive120');
    if (Store.getOwned().length >= 3) unlock('skins3');
    var allOwned = true;
    for (var i = 0; i < Levels.LIST.length; i++) {
      if (!Levels.isOwned(Levels.LIST[i].id)) { allOwned = false; break; }
    }
    if (allOwned) unlock('allTracks');
    if (Store.getNearTotal() >= 50) unlock('nearMiss50');
    if (Store.getMissionsDone() >= 20) unlock('missions20');
  }

  function showLeaderboard() {
    if (!signedIn) return;
    try {
      plugin.showLeaderboard({ leaderboardID: IDS.leaderboardBest }).catch(function () {});
    } catch (e) { /* no-op */ }
  }

  return {
    init: init,
    onRunEnd: onRunEnd,
    showLeaderboard: showLeaderboard,
    isSignedIn: function () { return signedIn; }
  };
})();
