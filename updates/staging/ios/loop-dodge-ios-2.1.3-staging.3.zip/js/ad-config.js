/* ============================================================
 * AD CONFIGURATION — the ONLY web file you touch to go live.
 *
 * ✅ CURRENT STATE: TEST MODE. The IDs below are Google's official
 * TEST ad units and isTesting is TRUE, so any build serves safe
 * "Test Ad"-labeled fill. You can tap these freely on your own
 * phone — no risk to your AdMob account.
 *
 * 🔴 BEFORE A REAL PLAY RELEASE, flip back to LIVE:
 *   1. interstitialId / rewardedId -> your REAL units (saved in
 *      the comments right below each field).
 *   2. isTesting: false.
 *   3. testingDevices: [] (it already is).
 *   The real AdMob *App* ID (the "~" one) and the com.loopdodge.game
 *   app id are already set. See RELEASE_CHECKLIST.md.
 * ============================================================ */
var AD_CONFIG = {
  // Google TEST interstitial unit (your REAL unit, for release, is
  // ca-app-pub-7307963416790245/1726049163):
  interstitialId: 'ca-app-pub-3940256099942544/1033173712',

  // Google TEST rewarded unit (your REAL unit, for release, is
  // ca-app-pub-7307963416790245/6786804158):
  rewardedId: 'ca-app-pub-3940256099942544/5224354917',

  // iOS uses its OWN ad unit ids (AdMob ids are per-platform). These are
  // Google's official iOS TEST units; ads.js picks them when getPlatform() === 'ios'.
  // REAL iOS units (AdMob app "Loop Dodge iOS", ca-app-pub-7307963416790245~7078128363):
  //   interstitial ca-app-pub-7307963416790245/7673823499 (unused while rewardedOnly)
  //   rewarded     ca-app-pub-7307963416790245/1986382543
  // The Codemagic "Go LIVE with iOS ads" step swaps these in for cloud builds.
  iosInterstitialId: 'ca-app-pub-3940256099942544/4411468910',
  iosRewardedId:     'ca-app-pub-3940256099942544/1712485313',

  // REWARD-ONLY mode: when true, NO interstitials are ever loaded or shown —
  // the only ads are the opt-in rewarded ones the player explicitly chooses
  // (revive, double gems, free daily gems, streak repair). No ad ever appears
  // unprompted. This is the launch setting (best retention / lowest churn).
  // Set false to re-enable the interstitial cadence below.
  rewardedOnly: true,

  // Show an interstitial after every Nth finished game over (ignored while
  // rewardedOnly is true). Never shown mid-run.
  interstitialEvery: 3,

  // No interstitials at all for a new player's first runs (their
  // death count must exceed this). Early interstitials are the top
  // churn driver in hypercasual; these impressions are worth less
  // than the retained player.
  graceRuns: 6,

  // true  -> the plugin serves Google's TEST ads (safe to tap).  <-- TEST
  // false -> the ad units above are used as-is (set this for release,
  //          with your REAL units restored).
  isTesting: true,

  // IMPORTANT while developing with real IDs: put your phone's
  // hashed device ID here so Google serves you "Test Ad"-labeled
  // fill instead of live ads. Clicking your own LIVE ads violates
  // AdMob policy and can get your account suspended!
  // Find the ID in Android Studio's Logcat after the first ad
  // request - look for a line containing setTestDeviceIds(...).
  // Example: testingDevices: ['33BE2250B43518CCDA7DE426D04EE231']
  // Leave empty [] for the release build.
  testingDevices: []
};
