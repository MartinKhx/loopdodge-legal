/* Player XP level: skill-independent progression so every run — even
 * a bad one — visibly deposits something. Shown as a LV badge + bar
 * on the menu; leveling up pays gems with a small celebration.
 *
 * XP comes from SURVIVAL SECONDS ONLY, fed as secondsDelta from the
 * run summary (revive-safe: a revived run finalizes twice and must
 * not double-credit). Gems are deliberately excluded from XP — gem
 * value stacks with track multipliers, the Doubler and storm bursts,
 * so gem-based XP would let the richest players also level several
 * times faster (and double-dip every multiplier).
 *
 * Curve: level N needs 100 + 60*(N-1) XP, pays min(150, 50 + 10N)
 * gems. A casual player (~300-400s/day) reaches level 3-4 on day one
 * (~190 gems) and settles near 40-65 gems/day — inside the economy
 * guardrail, absorbed by the trail shop introduced alongside. */
var XP = (function () {

  function needFor(level) { return 100 + 60 * (level - 1); }

  function rewardFor(level) { return Math.min(150, 50 + 10 * level); }

  /* { level, xp into the current level, need to reach the next }. */
  function state() {
    var level = Store.getPlayerLevel();
    return { level: level, xp: Store.getXP(), need: needFor(level) };
  }

  /* Credit one run's survival seconds. Returns { ups: [{level,
   * reward}...] } — one entry per level gained (usually 0 or 1). */
  function addRun(seconds) {
    var ups = [];
    if (!seconds || seconds <= 0) return { ups: ups };
    var xp = Store.getXP() + seconds;
    var level = Store.getPlayerLevel();
    while (xp >= needFor(level)) {
      xp -= needFor(level);
      level++;
      var reward = rewardFor(level);
      Store.addGems(reward);
      ups.push({ level: level, reward: reward });
    }
    Store.setXP(xp);
    Store.setPlayerLevel(level);
    return { ups: ups };
  }

  return { state: state, addRun: addRun, needFor: needFor };
})();
