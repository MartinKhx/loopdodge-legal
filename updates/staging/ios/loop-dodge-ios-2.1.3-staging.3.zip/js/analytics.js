/* Optional first-party gameplay measurement. The official SDK is isolated in
 * a same-origin hidden frame: opting out destroys its timers/network context
 * and removes its bounded offline queue without touching game saves.
 * No SDK/network/identifier exists until the player chooses to share analytics. */
var Analytics = (function () {
  var CHOICE = 'ld_analytics_consent_v1', PENDING = 'ld_analytics_run_v1', WAITING = 'ld_analytics_pending_v1';
  var consent = null, sdk = null, frame = null, generation = 0, active = false;
  var queue = [], recent = [], run = null, backgroundAt = 0, sessionOpen = false;
  var status = 'not_configured', runSerial = 0;
  var EVENTS = ('app_open session_resume session_pause run_start run_death run_end run_interrupted run_revived ' +
    'tutorial_started tutorial_completed sphere_reached relic_chosen warden_started warden_ended ' +
    'revive_offered double_offered ad_requested ad_reward_earned ad_not_rewarded ad_error ' +
    'shop_open purchase_requested purchase_order_failed purchase_granted purchase_restored ' +
    'item_unlocked item_selected relic_attuned relic_seeded daily_claimed daily_challenge_completed ' +
    'screen_view update_downloaded update_queued update_failed update_booted runtime_error').split(' ');
  var FIELDS = ('mode track run_id config_revision outcome reason death_cause score seconds gems souls ' +
    'near_misses switches best_combo storms sphere revived relic_id item_id item_type currency amount ' +
    'placement product_id source screen success line file error_kind tutorial run_count').split(' ');
  function cfg() { return window.SERVICES_CONFIG || {}; }
  function acfg() { return cfg().analytics || {}; }
  function platform() { try { return window.Capacitor ? Capacitor.getPlatform() : 'web'; } catch (e) { return 'web'; } }
  function read(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }
  function save(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  consent = read(CHOICE);
  if (consent !== true && consent !== false) consent = null;
  function available() {
    var a = acfg(), p = platform(), keys = a.keys && a.keys[p];
    return a.enabled === true && (a.dryRun === true || !!(keys && /^[a-f0-9]{32}$/i.test(keys.gameKey) && /^[a-f0-9]{40}$/i.test(keys.secretKey)));
  }
  function safeFields(input) {
    var out = {};
    if (!input) return out;
    FIELDS.forEach(function (k) {
      var v = input[k];
      if (typeof v === 'number' && isFinite(v)) out[k] = Math.max(-100000000, Math.min(100000000, v));
      else if (typeof v === 'boolean') out[k] = v;
      else if (typeof v === 'string' && /^[a-zA-Z0-9_.:-]{1,80}$/.test(v)) out[k] = v;
    });
    return out;
  }
  function record(name, input, value) {
    try {
      if (consent !== true || !active || EVENTS.indexOf(name) < 0) return;
      var fields = safeFields(input);
      fields.app_version = cfg().appVersion || 'unknown';
      fields.bundle_version = cfg().bundleVersion || fields.app_version;
      fields.platform = platform(); fields.environment = cfg().environment || 'staging';
      if (run) { fields.run_id = run.run_id; fields.mode = run.mode; fields.track = run.track; fields.config_revision = run.config_revision; }
      var entry = { name: name, fields: fields, value: typeof value === 'number' && isFinite(value) ? value : undefined };
      recent.push(entry); if (recent.length > 50) recent.shift();
      if (acfg().dryRun) return;
      if (!sdk || !sessionOpen) { if (queue.length < 100) queue.push(entry); save(WAITING, queue); return; }
      send(entry);
    } catch (e) { /* measurement never affects gameplay */ }
  }
  function send(entry) {
    try {
      if (!sdk || consent !== true || !active) return;
      var f = entry.fields, wireFields = {}, parts = ['game', entry.name];
      // SDK 5.0.0 treats numeric 0 as absent and rejects booleans in custom
      // fields. Keep them as explicit strings; numeric metric values stay numeric.
      Object.keys(f).forEach(function (key) {
        wireFields[key] = typeof f[key] === 'boolean' || f[key] === 0 ? String(f[key]) : f[key];
      });
      function part(v) { return String(v || 'unknown').replace(/[^a-zA-Z0-9_.-]/g, '_').slice(0, 48); }
      if (/^run_(start|end|death)$/.test(entry.name)) {
        parts.push(part(f.mode), part(f.track));
        if (entry.name === 'run_end') parts.push(part(f.outcome));
        if (entry.name === 'run_death') parts.push(part(f.death_cause));
      } else if (f.placement) parts.push(part(f.placement));
      else if (f.product_id) parts.push(part(f.product_id));
      else if (f.item_type && f.item_id) parts.push(part(f.item_type), part(f.item_id));
      else if (f.screen) parts.push(part(f.screen));
      else if (entry.name === 'sphere_reached') parts.push(part(f.sphere));
      sdk.addDesignEvent(parts.join(':'), entry.value, wireFields);
      // Separate numeric events make averages/distributions available through
      // ordinary design-event charts, without relying on paid raw-data exports.
      if (entry.name === 'run_end') {
        ['seconds', 'score', 'gems', 'souls', 'near_misses', 'switches', 'best_combo', 'sphere'].forEach(function (metric) {
          if (typeof f[metric] === 'number') sdk.addDesignEvent(['game', 'run_metric', metric, part(f.mode), part(f.track)].join(':'), f[metric], wireFields);
        });
      }
    } catch (e) {}
  }
  function persistRun() { if (consent === true && active) save(PENDING, run); }
  function endRun(outcome, data) {
    try {
      if (!run) return;
      var info = safeFields(data || run.last || {});
      info.outcome = outcome || 'abandoned';
      record('run_end', info, info.seconds);
      run = null; save(PENDING, null);
    } catch (e) {}
  }
  function beginRun(data) {
    endRun(run && run.last ? 'death' : 'restarted');
    if (consent !== true || !active) return;
    var d = safeFields(data);
    d.run_id = Date.now().toString(36) + '-' + (++runSerial);
    run = d; persistRun(); record('run_start', d);
    if (d.tutorial) record('tutorial_started', {});
  }
  function death(data) {
    if (!run) return;
    run.last = safeFields(data); persistRun(); record('run_death', data, data.seconds);
  }
  function purge() {
    try {
      var keys = [], a = acfg().keys || {};
      Object.keys(a).forEach(function (p) { if (a[p].gameKey) keys.push('GA::' + a[p].gameKey + '::'); });
      var remove = [];
      for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        if (keys.some(function (prefix) { return key.indexOf(prefix) === 0; })) remove.push(key);
      }
      remove.forEach(function (key) { localStorage.removeItem(key); });
    } catch (e) {}
    save(PENDING, null);
    save(WAITING, null);
  }
  function receiveConfig() {
    try {
      var raw = sdk && sdk.getRemoteConfigsValueAsString('loopdodge_config', '');
      if (raw && raw.length <= 8192 && window.RemoteConfig) RemoteConfig.accept(JSON.parse(raw));
    } catch (e) {}
  }
  function start() {
    if (active || consent !== true || !available()) { if (!available()) status = 'not_configured'; return; }
    active = true; status = acfg().dryRun ? 'local_preview' : 'starting';
    var waiting = read(WAITING);
    if (Array.isArray(waiting)) queue = waiting.slice(-100).filter(function (e) {
      return e && EVENTS.indexOf(e.name) >= 0 && e.fields && e.fields.environment === cfg().environment;
    }).map(function (e) {
      var fields = safeFields(e.fields);
      ['app_version', 'bundle_version', 'platform', 'environment'].forEach(function (k) {
        if (typeof e.fields[k] === 'string' && /^[a-zA-Z0-9_.:-]{1,80}$/.test(e.fields[k])) fields[k] = e.fields[k];
      });
      return { name: e.name, fields: fields, value: typeof e.value === 'number' && isFinite(e.value) ? e.value : undefined };
    });
    var interrupted = read(PENDING);
    if (interrupted && typeof interrupted === 'object') {
      record('run_interrupted', { mode: interrupted.mode, track: interrupted.track, reason: 'previous_process_ended' });
      save(PENDING, null);
    }
    record('app_open', {});
    if (acfg().dryRun) return;
    var epoch = ++generation;
    try {
      frame = document.createElement('iframe');
      frame.hidden = true; frame.title = 'Gameplay analytics'; frame.setAttribute('aria-hidden', 'true');
      frame.onload = function () {
        if (!active || consent !== true || generation !== epoch) return;
        try {
          var ga = frame.contentWindow.gameanalytics.GameAnalytics;
          var key = acfg().keys[platform()];
          ga.setEnabledInfoLog(false); ga.setEnabledVerboseLog(false); ga.enableHealthEvent(false);
          ga.configureBuild(cfg().appVersion + ':' + cfg().bundleVersion);
          ga.configureAvailableCustomDimensions01(['android', 'ios', 'web']);
          ga.configureAvailableCustomDimensions02(['staging', 'production']);
          ga.setCustomDimension01(platform()); ga.setCustomDimension02(cfg().environment);
          ga.setEnabledManualSessionHandling(true); ga.setEventProcessInterval(10);
          ga.addRemoteConfigsListener({ onRemoteConfigsUpdated: function () {
            if (!active || consent !== true || generation !== epoch) return;
            sdk = ga; sessionOpen = true; status = 'ready'; receiveConfig();
            // Offline initialization uses this callback too. The SDK finishes
            // starting the session before these queued API tasks execute.
            queue.splice(0).forEach(send); save(WAITING, null);
            if (backgroundAt) { sdk.endSession(); sessionOpen = false; }
          } });
          ga.initialize(key.gameKey, key.secretKey);
        } catch (e) { status = 'sdk_error'; }
      };
      frame.onerror = function () { status = 'sdk_error'; };
      frame.src = 'analytics-frame.html'; document.body.appendChild(frame);
    } catch (e) { status = 'sdk_error'; }
  }
  function choose(value) {
    consent = value === true; save(CHOICE, consent);
    if (consent) start();
    else {
      active = false; generation++; queue = []; recent = []; run = null; sdk = null; sessionOpen = false;
      if (frame) { frame.onload = null; frame.remove(); frame = null; }
      purge(); status = 'disabled';
    }
  }
  function foreground(isActive) {
    try {
      if (!active || consent !== true) return;
      if (!isActive) {
        if (backgroundAt) return;
        backgroundAt = Date.now(); persistRun(); record('session_pause', {});
        if (sdk && sessionOpen) { sdk.endSession(); sessionOpen = false; }
      } else if (backgroundAt) {
        backgroundAt = 0;
        if (sdk && !sessionOpen) sdk.startSession();
        record('session_resume', {});
      }
    } catch (e) {}
  }
  return {
    init: start, track: record, beginRun: beginRun, death: death, endRun: endRun,
    checkpoint: function (data) { if (run) { run.last = safeFields(data); persistRun(); } },
    revive: function () { if (run) { run.last = null; persistRun(); record('run_revived', {}); } },
    setConsent: choose, getConsent: function () { return consent; }, available: available, foreground: foreground,
    diagnostics: function () { return { status: status, consent: consent, queued: queue.length, events: JSON.parse(JSON.stringify(recent)) }; },
    runtimeError: function (p) { record('runtime_error', { file: p.filename, line: p.lineno, error_kind: 'javascript' }); }
  };
})();
