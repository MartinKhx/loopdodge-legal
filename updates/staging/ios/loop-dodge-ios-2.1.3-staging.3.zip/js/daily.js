/* Calendar-day features: the daily reward streak (and, in later
 * features, anything else keyed to the device-local date). All date
 * math uses local time on purpose — "a new day" should match the
 * player's wall clock, and everything works fully offline. */
var Daily = (function () {

  /* Gems for streak days 1..7; day 7's value repeats forever after. */
  var STREAK_GEMS = [30, 40, 50, 60, 80, 100, 150];

  function dateStr(d) {
    return d.getFullYear() + '-' +
      ('0' + (d.getMonth() + 1)).slice(-2) + '-' +
      ('0' + d.getDate()).slice(-2);
  }

  function todayStr() { return dateStr(new Date()); }

  /* Computed via setDate (not -86400000ms) so DST days don't skew it. */
  function yesterdayStr() {
    var d = new Date();
    d.setDate(d.getDate() - 1);
    return dateStr(d);
  }

  /* Two calendar days back — the single-day gap a streak repair bridges. */
  function dayBeforeYesterdayStr() {
    var d = new Date();
    d.setDate(d.getDate() - 2);
    return dateStr(d);
  }

  /* Parse a stored 'YYYY-MM-DD' to a local midnight Date (null if blank
   * or malformed). */
  function parseDate(s) {
    var p = (s || '').split('-');
    if (p.length !== 3) return null;
    return new Date(+p[0], +p[1] - 1, +p[2]);
  }

  /* Whole days from date-string a to date-string b (b minus a); Infinity
   * if either is missing, so a never-set marker reads as "long ago". */
  function daysBetween(a, b) {
    var da = parseDate(a), db = parseDate(b);
    if (!da || !db) return Infinity;
    return Math.round((db - da) / 86400000);
  }

  /* ---------- daily reward streak ---------- */

  /* What the claim panel should show. claimable is false if today's
   * reward was already taken; missing a full day resets to day 1. */
  function streakState() {
    var last = Store.getStreakLast();
    var day = Store.getStreakDay();
    if (last === todayStr()) {
      return { claimable: false, day: day, gems: STREAK_GEMS[Math.min(day, 7) - 1] || 0 };
    }
    var next = (last === yesterdayStr() && day > 0) ? Math.min(day + 1, 7) : 1;
    return { claimable: true, day: next, gems: STREAK_GEMS[next - 1] };
  }

  /* Grant today's reward. Returns the claimed {day, gems} or null. */
  function claimStreak() {
    var s = streakState();
    if (!s.claimable) return null;
    Store.setStreakDay(s.day);
    Store.setStreakLast(todayStr());
    Store.addGems(s.gems);
    return s;
  }

  /* ---------- streak repair (rewarded ad) ---------- */

  var REPAIR_MIN_DAY = 3;    // only a streak this long is worth saving...
  var REPAIR_COOLDOWN = 7;   // ...and a repair is allowed at most this often

  /* Can a lapsed streak be repaired right now? True only when the last
   * claim was exactly the day before yesterday (a single missed day),
   * the streak had reached REPAIR_MIN_DAY, and no repair has been used
   * within REPAIR_COOLDOWN days. `day` is the streak being protected. */
  function repairState() {
    var last = Store.getStreakLast();
    var day = Store.getStreakDay();
    if (last !== dayBeforeYesterdayStr() || day < REPAIR_MIN_DAY) {
      return { repairable: false, day: day };
    }
    var lastRep = Store.getStreakRepair();
    if (daysBetween(lastRep, todayStr()) < REPAIR_COOLDOWN) {
      return { repairable: false, day: day };
    }
    return { repairable: true, day: day };
  }

  /* Bridge the one missed day: move the last-claim marker to yesterday
   * so today's claim CONTINUES the streak (day+1) instead of resetting
   * to 1, and stamp the repair so the weekly cap holds. Returns true on
   * a real repair (the caller must have just shown a rewarded ad). */
  function repairStreak() {
    if (!repairState().repairable) return false;
    Store.setStreakLast(yesterdayStr());
    Store.setStreakRepair(todayStr());
    return true;
  }

  /* ---------- shop: free daily gems (rewarded ad) ---------- */

  var SHOP_GEMS = 50;

  function canClaimShopGems() { return Store.getShopGemsDay() !== todayStr(); }

  /* Called only after the rewarded ad actually paid out. */
  function claimShopGems() {
    if (!canClaimShopGems()) return false;
    Store.setShopGemsDay(todayStr());
    Store.addGems(SHOP_GEMS);
    return true;
  }

  /* ---------- daily challenge ---------- */

  var CHALLENGE_GOAL = 30;    // survive this many seconds...
  var CHALLENGE_GEMS = 100;   // ...to earn this, once per day

  /* Park–Miller PRNG: dead simple, exact in doubles (no Math.imul),
   * and the same sequence on every device for a given seed. */
  function seededRng(seed) {
    var s = seed % 2147483647;
    if (s <= 0) s += 2147483646;
    return function () {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };
  }

  /* The integer seed for today's challenge — same for every player; also the
   * basis for the Oracle's shareable 6-char seed code. */
  function challengeSeed() {
    var d = new Date();
    return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
  }

  /* The spawner RNG for today's challenge — same for every player. */
  function challengeRng() {
    return seededRng(challengeSeed());
  }

  /* A SEPARATE seeded stream for the relic Pact-Gate offers, so every player
   * faces the identical draft yet the 8-draw spawn() stream is never touched.
   * Offset the seed so it's an independent sequence from the spawner. */
  function challengeRelicRng() {
    var d = new Date();
    return seededRng(d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate() + 777013);
  }

  function challengeState() {
    var c = Store.getDailyRun();
    if (!c || c.date !== todayStr()) return { played: false, best: 0, claimed: false };
    return { played: true, best: c.best, claimed: c.claimed };
  }

  /* Mark the OFFICIAL daily attempt as used the moment it STARTS, not only
   * after death. This closes the force-close exploit: a player can no longer
   * background + hard-kill the app mid-run to dodge a bad seeded attempt and
   * retry it. Returns true if it actually started a fresh official attempt;
   * false if today's attempt was already used (caller should run practice). */
  function startChallenge() {
    if (challengeState().played) return false;
    Store.setDailyRun({ date: todayStr(), best: 0, claimed: false, started: true });
    return true;
  }

  /* After the official attempt is used, the seed may be replayed as many
   * times as the player likes — but UNRANKED (no reward, no best update). */
  function canPractice() { return challengeState().played; }

  /* Feed the finished daily run. Returns the gems awarded (0 if the
   * goal wasn't beaten or today's reward was already taken).
   * `best` stores pure survival SECONDS — the same number the 30s
   * goal is judged on — so the menu button can never show a "best"
   * above the goal while the reward went unearned (score includes
   * near-miss bonus points; seconds don't). */
  function recordChallenge(d) {
    // ad-revived runs never count: the revive offer is already hidden
    // in daily mode (main.js), but a cleared screen + invulnerability
    // must not be able to buy the 30s goal even if that ever changes
    if (d.revived) return 0;
    // unranked practice replays never touch the ranked best or reward
    if (d.practice) return 0;
    var c = Store.getDailyRun();
    if (!c || c.date !== todayStr()) c = { date: todayStr(), best: 0, claimed: false, started: true };
    if (d.seconds > c.best) c.best = d.seconds;
    var reward = 0;
    if (d.seconds >= CHALLENGE_GOAL && !c.claimed) {
      c.claimed = true;
      reward = CHALLENGE_GEMS;
      Store.addGems(reward);
    }
    Store.setDailyRun(c);
    return reward;
  }

  return {
    todayStr: todayStr,
    streakState: streakState,
    claimStreak: claimStreak,
    repairState: repairState,
    repairStreak: repairStreak,
    STREAK_GEMS: STREAK_GEMS,
    SHOP_GEMS: SHOP_GEMS,
    canClaimShopGems: canClaimShopGems,
    claimShopGems: claimShopGems,
    CHALLENGE_GOAL: CHALLENGE_GOAL,
    seededRng: seededRng,
    challengeSeed: challengeSeed,
    challengeRng: challengeRng,
    challengeRelicRng: challengeRelicRng,
    challengeState: challengeState,
    startChallenge: startChallenge,
    canPractice: canPractice,
    recordChallenge: recordChallenge
  };
})();
