/* Cosmetic ball trails: a steady drip of particles behind the ball,
 * drawn through the existing pooled particle system (no new render
 * machinery). Each trail is an emitter spec — colors, rate, motion —
 * and budgets stay tiny: rate × life ≈ at most ~18 particles alive,
 * inside the pool's reserved headroom (see Particles.emit).
 *
 * Same own/select UX as skins: gems unlock a trail forever, the
 * selected one shows in-run and in the menu's attract loop. 'none'
 * is the free default. Prices are the designated sink for the XP
 * level-up income introduced in the same release. */
var Trails = (function () {

  /* emit spec: rate (particles/s), speed (px/s scatter), size, life,
   * gravity (px/s², positive = sink), colors (picked at random). */
  var LIST = [
    { id: 'none',     name: 'None',     cost: 0,   emit: null },
    { id: 'embers',   name: 'Embers',   cost: 150,
      emit: { rate: 13, speed: 26, size: 3,   life: 0.55, gravity: -50,
              colors: ['#ff8c1a', '#ffd24a', '#ff5040'] } },
    { id: 'frost',    name: 'Frost',    cost: 200,
      emit: { rate: 12, speed: 20, size: 2.6, life: 0.7,  gravity: 35,
              colors: ['#9ad9ff', '#e8f6ff', '#57b6ff'] } },
    { id: 'sparks',   name: 'Sparks',   cost: 250,
      emit: { rate: 10, speed: 95, size: 2,   life: 0.3,  gravity: 0,
              colors: ['#fff35c', '#ffffff', '#ffd24a'] } },
    { id: 'smoke',    name: 'Smoke',    cost: 300,
      emit: { rate: 8,  speed: 12, size: 5,   life: 0.9,  gravity: -40,
              colors: ['#8fa3c8', '#5d6678', '#aebbd6'] } },
    { id: 'bubbles',  name: 'Bubbles',  cost: 350,
      emit: { rate: 9,  speed: 18, size: 3.4, life: 0.8,  gravity: -70,
              colors: ['#7fe3ff', '#c9f4ff', '#2bffc8'] } },
    { id: 'rainbow',  name: 'Rainbow',  cost: 450,
      emit: { rate: 15, speed: 30, size: 3,   life: 0.5,  gravity: 0,
              colors: ['#ff5040', '#ff8c1a', '#ffd24a', '#2bffc8', '#57b6ff', '#9c5bff'] } },
    { id: 'confetti', name: 'Confetti', cost: 500,
      emit: { rate: 11, speed: 40, size: 3.2, life: 0.65, gravity: 130,
              colors: ['#ffd24a', '#ff3df0', '#2bffc8', '#ffffff'] } },
    { id: 'void',     name: 'Void',     cost: 600,
      emit: { rate: 10, speed: 16, size: 4,   life: 0.6,  gravity: 0,
              colors: ['#9c5bff', '#1c2a4a', '#b86bff'] } },

    /* --- v10 collection --- */
    { id: 'stardust', name: 'Stardust', cost: 650,
      emit: { rate: 16, speed: 14, size: 2.2, life: 0.85, gravity: -30,
              colors: ['#ffffff', '#9ad9ff', '#c9b8ff', '#ffe89e'] } },
    { id: 'plasma',   name: 'Plasma',   cost: 700,
      emit: { rate: 14, speed: 90, size: 2.6, life: 0.35, gravity: 0,
              colors: ['#ff2d95', '#00e5ff', '#ffffff'] } },
    { id: 'inferno',  name: 'Inferno',  cost: 750,
      emit: { rate: 18, speed: 30, size: 4,   life: 0.5,  gravity: -90,
              colors: ['#ff3b00', '#ff7a18', '#ffb02e', '#ffe066'] } },
    { id: 'shadow',   name: 'Shadow',   cost: 800,
      emit: { rate: 12, speed: 10, size: 5,   life: 0.7,  gravity: 50,
              colors: ['#3a1a5a', '#160a26', '#6f43c9'] } },
    { id: 'aurora',   name: 'Aurora',   cost: 850,
      emit: { rate: 15, speed: 18, size: 3,   life: 0.8,  gravity: -45,
              colors: ['#2bffc8', '#57b6ff', '#9c5bff', '#eafffb'] } },
    { id: 'prismatic', name: 'Prismatic', cost: 900,
      emit: { rate: 20, speed: 36, size: 2.8, life: 0.55, gravity: 0,
              colors: ['#ff4d6d', '#ff9e2e', '#ffe14d', '#2bffc8', '#57b6ff', '#9c5bff'] } }
  ];

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) {
      if (LIST[i].id === id) return LIST[i];
    }
    return LIST[0]; // unknown id: the free 'none'
  }

  function isOwned(id) {
    var t = byId(id);
    return t.cost === 0 || Store.getOwnedTrails().indexOf(t.id) !== -1;
  }

  /* Spend gems to unlock. Returns true on success. */
  function buy(id) {
    var t = byId(id);
    if (isOwned(t.id)) return true;
    var gems = Store.getGems();
    if (gems < t.cost) return false;
    Store.setGems(gems - t.cost);
    var owned = Store.getOwnedTrails();
    owned.push(t.id);
    Store.setOwnedTrails(owned);
    return true;
  }

  function current() { return byId(Store.getTrail()); }

  return { LIST: LIST, byId: byId, isOwned: isOwned, buy: buy, current: current };
})();
