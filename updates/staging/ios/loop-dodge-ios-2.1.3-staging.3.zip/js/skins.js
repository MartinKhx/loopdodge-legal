/* Ball skins. Neon is the free default; everything else unlocks by
 * spending gems. Two kinds:
 *   - flat neon colors  { color, core }
 *   - drawn characters  { color, draw(ctx, r) }  — rendered procedurally
 *     (no image assets: crisp at any size, zero bytes, fully offline,
 *     and no copyright/likeness problems on Google Play).
 *
 * `color` is always required: it tints the glow, trail, particles and
 * the track ring. Drawn skins paint a full ball of radius r centered
 * at (0,0); they may overflow up to ~1.3r (ears, crowns, fuses).
 *
 * To add a skin: append an entry to LIST — the shop, unlock flow and
 * renderer pick it up automatically. */
var Skins = (function () {
  var TAU = Math.PI * 2;

  /* ---------- tiny drawing helpers (coords relative to radius r) ---------- */

  function disc(c, r, col) { c.fillStyle = col; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill(); }
  function dot(c, x, y, rad, col) { c.fillStyle = col; c.beginPath(); c.arc(x, y, rad, 0, TAU); c.fill(); }
  function strokeIt(c, w, col) { c.lineWidth = w; c.strokeStyle = col; c.lineCap = 'round'; c.stroke(); }
  function arc(c, x, y, rad, a0, a1, w, col) { c.beginPath(); c.arc(x, y, rad, a0, a1); strokeIt(c, w, col); }
  function seg(c, x1, y1, x2, y2, w, col) { c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); strokeIt(c, w, col); }
  function poly(c, pts, col) {
    c.fillStyle = col; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    c.closePath(); c.fill();
  }
  function label(c, str, size, col, y) {
    c.fillStyle = col; c.font = '900 ' + size + 'px system-ui, sans-serif';
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(str, 0, y || 0);
  }
  function shine(c, r) { dot(c, -r * 0.32, -r * 0.36, r * 0.16, 'rgba(255,255,255,0.45)'); }
  function eyes2(c, r) { dot(c, -r * 0.3, -r * 0.18, r * 0.1, '#222'); dot(c, r * 0.3, -r * 0.18, r * 0.1, '#222'); }
  function smile(c, r) { arc(c, 0, r * 0.06, r * 0.5, 0.2 * Math.PI, 0.8 * Math.PI, r * 0.12, '#222'); }

  /* ---------- the roster (sorted by price = shop progression) ---------- */

  var LIST = [
    /* Your own photo as a ball — kept first in the row so players see
     * the option exists. Unlocks with gems OR one rewarded ad (handled
     * in ui.js). The image lives only in localStorage on the player's
     * device — nothing is uploaded anywhere. */
    { id: 'custom', name: 'My Photo', cost: 600, color: '#9ad9ff', custom: true },

    /* --- flat neon classics --- */
    { id: 'neon',  name: 'Neon',  cost: 0,    color: '#22e5ff', core: '#eafdff' },
    { id: 'pulse', name: 'Pulse', cost: 50,   color: '#ff3df0', core: '#ffe6fc' },

    /* --- faces --- */
    { id: 'smile', name: 'Happy', cost: 75, color: '#ffd93b', draw: function (c, r) {
      disc(c, r, '#ffd93b'); eyes2(c, r); smile(c, r); shine(c, r);
    } },
    { id: 'toxin', name: 'Toxin', cost: 100,  color: '#a8ff1e', core: '#f4ffdf' },
    { id: 'cool', name: 'Chill', cost: 150, color: '#ffc93b', draw: function (c, r) {
      disc(c, r, '#ffc93b');
      c.fillStyle = '#1a1a1a';
      c.fillRect(-r * 0.62, -r * 0.34, r * 0.5, r * 0.3);   // left lens
      c.fillRect(r * 0.12, -r * 0.34, r * 0.5, r * 0.3);    // right lens
      c.fillRect(-r * 0.15, -r * 0.27, r * 0.3, r * 0.08);  // bridge
      smile(c, r);
    } },
    { id: 'ember', name: 'Ember', cost: 200,  color: '#ff8c1a', core: '#fff1de' },
    { id: 'wink', name: 'Flirt', cost: 250, color: '#ffd93b', draw: function (c, r) {
      disc(c, r, '#ffd93b');
      dot(c, -r * 0.3, -r * 0.18, r * 0.1, '#222');
      seg(c, r * 0.18, -r * 0.18, r * 0.45, -r * 0.18, r * 0.09, '#222'); // winking eye
      smile(c, r);
      dot(c, r * 0.22, r * 0.42, r * 0.13, '#ff7a9c'); // tongue
    } },
    { id: 'lol', name: 'LMAO', cost: 300, color: '#ffd93b', draw: function (c, r) {
      disc(c, r, '#ffd93b');
      seg(c, -r * 0.42, -r * 0.26, -r * 0.16, -r * 0.12, r * 0.09, '#222'); // squint >
      seg(c, -r * 0.42, -r * 0.0, -r * 0.16, -r * 0.14, r * 0.09, '#222');
      seg(c, r * 0.42, -r * 0.26, r * 0.16, -r * 0.12, r * 0.09, '#222');  // squint <
      seg(c, r * 0.42, -r * 0.0, r * 0.16, -r * 0.14, r * 0.09, '#222');
      c.beginPath(); c.arc(0, r * 0.18, r * 0.42, 0, Math.PI); c.closePath(); c.fillStyle = '#222'; c.fill();
      dot(c, -r * 0.62, r * 0.05, r * 0.14, '#57b6ff'); // tears
      dot(c, r * 0.62, r * 0.05, r * 0.14, '#57b6ff');
    } },
    { id: 'rage', name: 'Tilted', cost: 350, color: '#ff5040', draw: function (c, r) {
      disc(c, r, '#ff5040');
      seg(c, -r * 0.48, -r * 0.42, -r * 0.14, -r * 0.26, r * 0.1, '#3a0a0a'); // angry brows
      seg(c, r * 0.48, -r * 0.42, r * 0.14, -r * 0.26, r * 0.1, '#3a0a0a');
      dot(c, -r * 0.28, -r * 0.1, r * 0.09, '#3a0a0a');
      dot(c, r * 0.28, -r * 0.1, r * 0.09, '#3a0a0a');
      arc(c, 0, r * 0.62, r * 0.32, 1.2 * Math.PI, 1.8 * Math.PI, r * 0.11, '#3a0a0a'); // frown
    } },

    /* --- flat classic --- */
    { id: 'ghost', name: 'Ghost', cost: 400,  color: '#cfe9ff', core: '#ffffff' },

    /* --- creatures & things --- */
    { id: 'boo', name: 'Boo', cost: 450, color: '#f4f8ff', draw: function (c, r) {
      disc(c, r, '#f4f8ff');
      c.save(); c.scale(1, 1.5);
      dot(c, -r * 0.28, -r * 0.1, r * 0.11, '#1d2430');
      dot(c, r * 0.28, -r * 0.1, r * 0.11, '#1d2430');
      dot(c, 0, r * 0.25, r * 0.12, '#1d2430'); // "oooo" mouth
      c.restore();
    } },
    { id: 'lady', name: 'Dotty', cost: 475, color: '#ff4757', draw: function (c, r) {
      dot(c, 0, -r * 0.78, r * 0.42, '#1d2430');            // head
      dot(c, -r * 0.16, -r * 0.92, r * 0.09, '#ffffff');    // eyes
      dot(c, r * 0.16, -r * 0.92, r * 0.09, '#ffffff');
      disc(c, r * 0.92, '#ff4757');
      seg(c, 0, -r * 0.45, 0, r * 0.9, r * 0.07, '#1d2430'); // wing split
      dot(c, -r * 0.42, -r * 0.05, r * 0.13, '#1d2430');    // spots
      dot(c, r * 0.45, 0, r * 0.12, '#1d2430');
      dot(c, -r * 0.3, r * 0.5, r * 0.11, '#1d2430');
      dot(c, r * 0.28, r * 0.55, r * 0.10, '#1d2430');
      dot(c, -r * 0.15, r * 0.2, r * 0.09, '#1d2430');
    } },
    { id: 'tennis', name: 'Ace', cost: 500, color: '#d6e83c', draw: function (c, r) {
      disc(c, r, '#d6e83c');
      arc(c, -r * 1.45, 0, r * 1.62, -0.42, 0.42, r * 0.12, '#fafff0');
      arc(c, r * 1.45, 0, r * 1.62, Math.PI - 0.42, Math.PI + 0.42, r * 0.12, '#fafff0');
      shine(c, r);
    } },
    { id: 'alien', name: 'Greys', cost: 550, color: '#7ddf64', draw: function (c, r) {
      disc(c, r, '#7ddf64');
      c.save(); c.translate(-r * 0.3, -r * 0.1); c.rotate(0.5); c.scale(1, 1.7);
      dot(c, 0, 0, r * 0.14, '#10231a'); c.restore();
      c.save(); c.translate(r * 0.3, -r * 0.1); c.rotate(-0.5); c.scale(1, 1.7);
      dot(c, 0, 0, r * 0.14, '#10231a'); c.restore();
      seg(c, -r * 0.1, r * 0.5, r * 0.1, r * 0.5, r * 0.07, '#10231a');
    } },
    { id: 'robot', name: 'Beep', cost: 600, color: '#b9c2d0', draw: function (c, r) {
      disc(c, r, '#b9c2d0');
      seg(c, 0, -r, 0, -r * 1.18, r * 0.08, '#7d8898');
      dot(c, 0, -r * 1.22, r * 0.09, '#ff5757'); // antenna
      c.fillStyle = '#22e5ff';
      c.fillRect(-r * 0.42, -r * 0.3, r * 0.26, r * 0.26);
      c.fillRect(r * 0.16, -r * 0.3, r * 0.26, r * 0.26);
      c.fillStyle = '#5d6678';
      c.fillRect(-r * 0.3, r * 0.3, r * 0.6, r * 0.18); // mouth grill
    } },
    { id: 'eight', name: '8-Ball', cost: 650, color: '#e8e8e8', draw: function (c, r) {
      disc(c, r, '#15151a');
      dot(c, 0, -r * 0.08, r * 0.42, '#f2f2f2');
      label(c, '8', r * 0.62, '#15151a', -r * 0.08);
      shine(c, r);
    } },
    { id: 'soccer', name: 'GOAL', cost: 700, color: '#f4f4f4', draw: function (c, r) {
      disc(c, r, '#f4f4f4');
      var p = [];
      for (var i = 0; i < 5; i++) {
        var a = -Math.PI / 2 + i * TAU / 5;
        p.push([Math.cos(a) * r * 0.32, Math.sin(a) * r * 0.32]);
        seg(c, Math.cos(a) * r * 0.32, Math.sin(a) * r * 0.32,
               Math.cos(a) * r * 0.95, Math.sin(a) * r * 0.95, r * 0.08, '#23262e');
      }
      poly(c, p, '#23262e');
    } },
    { id: 'basket', name: 'Dunk', cost: 750, color: '#f08a24', draw: function (c, r) {
      disc(c, r, '#f08a24');
      seg(c, 0, -r, 0, r, r * 0.08, '#5b2c08');
      seg(c, -r, 0, r, 0, r * 0.08, '#5b2c08');
      arc(c, -r * 1.25, 0, r * 1.05, -0.55, 0.55, r * 0.08, '#5b2c08');
      arc(c, r * 1.25, 0, r * 1.05, Math.PI - 0.55, Math.PI + 0.55, r * 0.08, '#5b2c08');
      shine(c, r);
    } },

    /* --- flat classic --- */
    { id: 'volt',  name: 'Volt',  cost: 800,  color: '#9c5bff', core: '#f0e4ff' },

    { id: 'skull', name: 'GG', cost: 850, color: '#f2f2f2', draw: function (c, r) {
      disc(c, r, '#f2f2f2');
      dot(c, -r * 0.3, -r * 0.12, r * 0.17, '#1d2430');
      dot(c, r * 0.3, -r * 0.12, r * 0.17, '#1d2430');
      poly(c, [[0, r * 0.12], [-r * 0.1, r * 0.32], [r * 0.1, r * 0.32]], '#1d2430');
      seg(c, -r * 0.18, r * 0.55, -r * 0.18, r * 0.78, r * 0.07, '#1d2430');
      seg(c, 0, r * 0.58, 0, r * 0.82, r * 0.07, '#1d2430');
      seg(c, r * 0.18, r * 0.55, r * 0.18, r * 0.78, r * 0.07, '#1d2430');
    } },
    { id: 'panda', name: 'Bamboo', cost: 875, color: '#f4f6fa', draw: function (c, r) {
      dot(c, -r * 0.62, -r * 0.62, r * 0.34, '#1d2430');    // ears
      dot(c, r * 0.62, -r * 0.62, r * 0.34, '#1d2430');
      disc(c, r, '#f4f6fa');
      c.save(); c.translate(-r * 0.32, -r * 0.1); c.rotate(0.5); c.scale(1, 1.4);
      dot(c, 0, 0, r * 0.2, '#1d2430'); c.restore();        // eye patches
      c.save(); c.translate(r * 0.32, -r * 0.1); c.rotate(-0.5); c.scale(1, 1.4);
      dot(c, 0, 0, r * 0.2, '#1d2430'); c.restore();
      dot(c, -r * 0.3, -r * 0.12, r * 0.07, '#ffffff');     // pupils
      dot(c, r * 0.3, -r * 0.12, r * 0.07, '#ffffff');
      dot(c, 0, r * 0.22, r * 0.1, '#1d2430');              // nose
      arc(c, 0, r * 0.36, r * 0.2, 0.2 * Math.PI, 0.8 * Math.PI, r * 0.07, '#1d2430');
    } },
    { id: 'melon', name: 'Juicy', cost: 900, color: '#ff5b6a', draw: function (c, r) {
      disc(c, r, '#2e9e44');
      disc(c, r * 0.84, '#bff09c');
      disc(c, r * 0.7, '#ff5b6a');
      dot(c, -r * 0.3, -r * 0.15, r * 0.07, '#26221c');
      dot(c, r * 0.22, -r * 0.3, r * 0.07, '#26221c');
      dot(c, r * 0.05, r * 0.18, r * 0.07, '#26221c');
      dot(c, -r * 0.18, r * 0.32, r * 0.07, '#26221c');
      dot(c, r * 0.35, r * 0.25, r * 0.07, '#26221c');
    } },
    { id: 'donut', name: 'Glaze', cost: 950, color: '#ff7fb1', draw: function (c, r) {
      disc(c, r, '#e8b06b');
      disc(c, r * 0.82, '#ff7fb1');
      dot(c, 0, 0, r * 0.26, '#9c6b32'); // hole
      var spr = [['#fff35c', -0.5, -0.45, 0.5], ['#57b6ff', 0.35, -0.5, -0.4],
                 ['#7dff8e', 0.55, 0.25, 0.9], ['#fff', -0.35, 0.45, 0.2], ['#ffd93b', 0.0, 0.55, -0.7]];
      for (var i = 0; i < spr.length; i++) {
        var s = spr[i];
        c.save(); c.translate(s[1] * r, s[2] * r); c.rotate(s[3]);
        seg(c, -r * 0.1, 0, r * 0.1, 0, r * 0.07, s[0]); c.restore();
      }
    } },
    { id: 'cookie', name: 'Snack', cost: 1000, color: '#d9a55a', draw: function (c, r) {
      disc(c, r, '#d9a55a');
      dot(c, -r * 0.35, -r * 0.25, r * 0.13, '#5b3a1a');
      dot(c, r * 0.3, -r * 0.35, r * 0.11, '#5b3a1a');
      dot(c, r * 0.45, r * 0.2, r * 0.12, '#5b3a1a');
      dot(c, -r * 0.1, r * 0.15, r * 0.14, '#5b3a1a');
      dot(c, -r * 0.5, r * 0.35, r * 0.1, '#5b3a1a');
      dot(c, r * 0.05, r * 0.5, r * 0.09, '#5b3a1a');
    } },
    { id: 'sushi', name: 'Umami', cost: 1050, color: '#ff8e6e', draw: function (c, r) {
      disc(c, r, '#f6f1e7');                                // rice
      c.save(); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
      c.fillStyle = '#ff8e6e';                              // salmon
      c.fillRect(-r, -r * 0.45, r * 2, r * 0.9);
      seg(c, -r, -r * 0.18, r, -r * 0.18, r * 0.07, '#ffb59d');
      seg(c, -r, r * 0.12, r, r * 0.12, r * 0.07, '#ffb59d');
      c.fillStyle = 'rgba(20, 48, 32, 0.88)';               // nori strap
      c.fillRect(-r * 0.16, -r, r * 0.32, r * 2);
      c.restore();
      shine(c, r);
    } },
    { id: 'devil', name: 'Imp', cost: 1100, color: '#ff3030', draw: function (c, r) {
      poly(c, [[-r * 0.75, -r * 0.5], [-r * 0.95, -r * 1.1], [-r * 0.35, -r * 0.85]], '#b71a1a');
      poly(c, [[r * 0.75, -r * 0.5], [r * 0.95, -r * 1.1], [r * 0.35, -r * 0.85]], '#b71a1a');
      disc(c, r, '#ff3030');
      seg(c, -r * 0.45, -r * 0.35, -r * 0.12, -r * 0.22, r * 0.09, '#3a0a0a');
      seg(c, r * 0.45, -r * 0.35, r * 0.12, -r * 0.22, r * 0.09, '#3a0a0a');
      dot(c, -r * 0.26, -r * 0.06, r * 0.09, '#3a0a0a');
      dot(c, r * 0.26, -r * 0.06, r * 0.09, '#3a0a0a');
      arc(c, 0, r * 0.18, r * 0.45, 0.25 * Math.PI, 0.75 * Math.PI, r * 0.1, '#3a0a0a');
    } },
    { id: 'earth', name: 'Home', cost: 1200, color: '#2f7fe0', draw: function (c, r) {
      disc(c, r, '#2f7fe0');
      c.save(); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
      dot(c, -r * 0.4, -r * 0.3, r * 0.34, '#3fae5a');
      dot(c, r * 0.45, -r * 0.05, r * 0.28, '#3fae5a');
      dot(c, -r * 0.1, r * 0.5, r * 0.3, '#3fae5a');
      dot(c, r * 0.15, -r * 0.6, r * 0.18, '#3fae5a');
      c.restore();
      shine(c, r);
    } },
    { id: 'pump', name: 'Spooky', cost: 1250, color: '#ff8c1a', draw: function (c, r) {
      seg(c, 0, -r * 0.9, 0, -r * 1.18, r * 0.16, '#3f7a2e'); // stem
      disc(c, r, '#ff8c1a');
      c.save(); c.scale(0.55, 1);                            // ridge
      arc(c, 0, 0, r * 0.92, 0, TAU, r * 0.07, 'rgba(140, 60, 0, 0.4)');
      c.restore();
      poly(c, [[-r * 0.48, -r * 0.1], [-r * 0.14, -r * 0.1], [-r * 0.31, -r * 0.4]], '#2a1500'); // eyes
      poly(c, [[r * 0.48, -r * 0.1], [r * 0.14, -r * 0.1], [r * 0.31, -r * 0.4]], '#2a1500');
      poly(c, [[-r * 0.5, r * 0.28], [-r * 0.22, r * 0.45], [0, r * 0.28], [r * 0.22, r * 0.45],
               [r * 0.5, r * 0.28], [r * 0.28, r * 0.6], [-r * 0.28, r * 0.6]], '#2a1500'); // grin
    } },
    { id: 'moon', name: 'To Moon', cost: 1300, color: '#cfd3dc', draw: function (c, r) {
      disc(c, r, '#cfd3dc');
      dot(c, -r * 0.3, -r * 0.25, r * 0.18, '#9aa1b0');
      dot(c, r * 0.35, r * 0.1, r * 0.14, '#9aa1b0');
      dot(c, -r * 0.1, r * 0.45, r * 0.11, '#9aa1b0');
      dot(c, r * 0.2, -r * 0.5, r * 0.09, '#9aa1b0');
      shine(c, r);
    } },
    { id: 'saturn', name: 'Ringed', cost: 1400, color: '#e8c97a', draw: function (c, r) {
      disc(c, r, '#e8c97a');
      arc(c, 0, -r * 0.25, r * 0.78, 0.3, Math.PI - 0.3, r * 0.1, '#d4a94f');
      arc(c, 0, r * 0.2, r * 0.85, 0.25, Math.PI - 0.25, r * 0.1, '#d4a94f');
      c.save(); c.rotate(-0.35); c.scale(1, 0.32);
      arc(c, 0, 0, r * 1.5, 0, TAU, r * 0.45, 'rgba(214,178,108,0.85)');
      c.restore();
    } },

    /* --- flat classic --- */
    { id: 'aurum', name: 'Aurum', cost: 1500, color: '#ffd24a', core: '#fff7da' },

    { id: 'disco', name: 'Party', cost: 1600, color: '#cdd6e2', draw: function (c, r) {
      disc(c, r, '#cdd6e2');
      c.save(); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
      for (var i = -2; i <= 2; i++) {
        seg(c, i * r * 0.42, -r, i * r * 0.42, r, r * 0.06, 'rgba(80,95,120,0.7)');
        seg(c, -r, i * r * 0.42, r, i * r * 0.42, r * 0.06, 'rgba(80,95,120,0.7)');
      }
      c.restore();
      dot(c, -r * 0.2, -r * 0.2, r * 0.1, '#ffffff');
      dot(c, r * 0.35, r * 0.3, r * 0.08, '#ffffff');
    } },
    { id: 'cat', name: 'Meow', cost: 1700, color: '#b8a9d9', draw: function (c, r) {
      poly(c, [[-r * 0.85, -r * 0.4], [-r * 0.72, -r * 1.15], [-r * 0.18, -r * 0.85]], '#9d8cc4'); // ears
      poly(c, [[r * 0.85, -r * 0.4], [r * 0.72, -r * 1.15], [r * 0.18, -r * 0.85]], '#9d8cc4');
      disc(c, r, '#b8a9d9');
      c.save(); c.translate(-r * 0.3, -r * 0.12); c.scale(1, 1.5);
      dot(c, 0, 0, r * 0.11, '#2d3b22'); c.restore();       // slit eyes
      c.save(); c.translate(r * 0.3, -r * 0.12); c.scale(1, 1.5);
      dot(c, 0, 0, r * 0.11, '#2d3b22'); c.restore();
      poly(c, [[-r * 0.1, r * 0.18], [r * 0.1, r * 0.18], [0, r * 0.32]], '#e98aa4'); // nose
      seg(c, -r * 0.2, r * 0.38, -r * 0.78, r * 0.26, r * 0.05, '#6f5f96'); // whiskers
      seg(c, -r * 0.2, r * 0.48, -r * 0.75, r * 0.52, r * 0.05, '#6f5f96');
      seg(c, r * 0.2, r * 0.38, r * 0.78, r * 0.26, r * 0.05, '#6f5f96');
      seg(c, r * 0.2, r * 0.48, r * 0.75, r * 0.52, r * 0.05, '#6f5f96');
    } },
    { id: 'bomb', name: 'Boom', cost: 1800, color: '#ffa030', draw: function (c, r) {
      seg(c, 0, -r * 0.9, r * 0.22, -r * 1.12, r * 0.09, '#8a6a4a'); // fuse
      var sx = r * 0.28, sy = -r * 1.18;
      seg(c, sx - r * 0.1, sy, sx + r * 0.1, sy, r * 0.06, '#ffa030'); // spark
      seg(c, sx, sy - r * 0.1, sx, sy + r * 0.1, r * 0.06, '#ffa030');
      disc(c, r, '#23262e');
      shine(c, r);
    } },
    { id: 'eye', name: 'Seer', cost: 2000, color: '#3aa0ff', draw: function (c, r) {
      disc(c, r, '#f6f6f6');
      seg(c, -r * 0.85, -r * 0.3, -r * 0.5, -r * 0.15, r * 0.05, '#e06a6a'); // veins
      seg(c, -r * 0.8, r * 0.35, -r * 0.48, r * 0.2, r * 0.05, '#e06a6a');
      seg(c, r * 0.85, r * 0.25, r * 0.5, r * 0.12, r * 0.05, '#e06a6a');
      dot(c, 0, 0, r * 0.46, '#3aa0ff');
      dot(c, 0, 0, r * 0.22, '#10131c');
      dot(c, -r * 0.1, -r * 0.12, r * 0.08, '#ffffff');
    } },

    /* --- meme-inspired originals (drawn by hand, no real likenesses) --- */
    { id: 'doge', name: 'Wow', cost: 2200, color: '#e3c167', draw: function (c, r) {
      poly(c, [[-r * 0.85, -r * 0.35], [-r * 0.6, -r * 1.15], [-r * 0.15, -r * 0.8]], '#c9a44d'); // ears
      poly(c, [[r * 0.85, -r * 0.35], [r * 0.6, -r * 1.15], [r * 0.15, -r * 0.8]], '#c9a44d');
      disc(c, r, '#e3c167');
      dot(c, 0, r * 0.32, r * 0.45, '#f4e3b8'); // muzzle
      dot(c, -r * 0.32, -r * 0.18, r * 0.1, '#26221c');
      dot(c, r * 0.32, -r * 0.18, r * 0.1, '#26221c');
      dot(c, 0, r * 0.18, r * 0.11, '#26221c'); // nose
      arc(c, 0, r * 0.38, r * 0.18, 0.2 * Math.PI, 0.8 * Math.PI, r * 0.07, '#26221c');
    } },
    { id: 'stonks', name: 'Stonks', cost: 2500, color: '#35d07f', draw: function (c, r) {
      disc(c, r, '#eef3f8');
      c.beginPath();
      c.moveTo(-r * 0.6, r * 0.45);
      c.lineTo(-r * 0.15, -r * 0.02);
      c.lineTo(r * 0.08, r * 0.18);
      c.lineTo(r * 0.5, -r * 0.28);
      strokeIt(c, r * 0.14, '#35d07f');
      poly(c, [[r * 0.25, -r * 0.48], [r * 0.62, -r * 0.42], [r * 0.5, -r * 0.05]], '#35d07f'); // arrowhead
    } },
    { id: 'galaxy', name: 'Cosmos', cost: 2800, color: '#8a6cff', draw: function (c, r) {
      disc(c, r, '#241a4d');
      c.save(); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
      arc(c, -r * 0.18, -r * 0.12, r * 0.5, 0.2, Math.PI * 1.05, r * 0.17, 'rgba(138, 108, 255, 0.75)'); // arms
      arc(c, r * 0.18, r * 0.12, r * 0.5, Math.PI + 0.2, Math.PI * 2.05, r * 0.17, 'rgba(94, 210, 255, 0.6)');
      c.restore();
      dot(c, 0, 0, r * 0.18, '#fff6d9');                    // core
      dot(c, -r * 0.55, r * 0.4, r * 0.05, '#ffffff');      // stars
      dot(c, r * 0.5, -r * 0.52, r * 0.06, '#ffffff');
      dot(c, r * 0.62, r * 0.3, r * 0.04, '#ffffff');
      dot(c, -r * 0.45, -r * 0.6, r * 0.04, '#ffffff');
    } },
    { id: 'prez', name: 'El Prez', cost: 3000, color: '#1c2a4a', draw: function (c, r) {
      disc(c, r, '#f2c79b');
      c.beginPath(); c.arc(0, 0, r, Math.PI * 1.12, Math.PI * 1.88); c.closePath();
      c.fillStyle = '#4a3826'; c.fill(); // impressive hair
      eyes2(c, r);
      c.beginPath(); c.arc(0, 0, r, Math.PI * 0.18, Math.PI * 0.82); c.closePath();
      c.fillStyle = '#1c2a4a'; c.fill(); // suit
      poly(c, [[-r * 0.16, r * 0.55], [r * 0.16, r * 0.55], [0, r * 0.88]], '#ffffff'); // shirt
      seg(c, 0, r * 0.6, 0, r * 0.85, r * 0.11, '#d22f2f'); // tie
    } },
    { id: 'king', name: 'King', cost: 4000, color: '#ffd24a', draw: function (c, r) {
      poly(c, [[-r * 0.55, -r * 0.78], [-r * 0.55, -r * 1.15], [-r * 0.22, -r * 0.92],
               [0, -r * 1.22], [r * 0.22, -r * 0.92], [r * 0.55, -r * 1.15], [r * 0.55, -r * 0.78]], '#ffe066');
      dot(c, 0, -r * 0.95, r * 0.08, '#ff4d6a');
      disc(c, r, '#ffd24a');
      eyes2(c, r); smile(c, r); shine(c, r);
    } },
    { id: 'trophy', name: 'Champ', cost: 5000, color: '#ffcf3d', draw: function (c, r) {
      disc(c, r, '#ffcf3d');
      disc(c, r * 0.78, '#ffe066');
      label(c, '#1', r * 0.72, '#7a4d00', r * 0.02);
      dot(c, -r * 0.55, -r * 0.55, r * 0.08, '#ffffff');
      dot(c, r * 0.6, -r * 0.4, r * 0.06, '#ffffff');
    } },

    /* --- v10 elite collection (top-tier aspirational, all procedural) --- */
    { id: 'yinyang', name: 'Balance', cost: 5500, color: '#e8e8ee', draw: function (c, r) {
      disc(c, r, '#f4f4f7');
      c.fillStyle = '#16161e';
      c.beginPath(); c.arc(0, 0, r, -Math.PI / 2, Math.PI / 2); c.fill(); // right half dark
      dot(c, 0, -r * 0.5, r * 0.5, '#16161e');
      dot(c, 0, r * 0.5, r * 0.5, '#f4f4f7');
      dot(c, 0, -r * 0.5, r * 0.13, '#f4f4f7');
      dot(c, 0, r * 0.5, r * 0.13, '#16161e');
    } },
    { id: 'vortex', name: 'Singularity', cost: 6000, color: '#9a6bff', draw: function (c, r) {
      disc(c, r, '#140a26');
      for (var i = 0; i < 5; i++) {
        var rr = r * (0.92 - i * 0.15), a = i * 1.1;
        arc(c, 0, 0, rr, a, a + 4.2, r * 0.11, i % 2 ? '#9a6bff' : '#d7b8ff');
      }
      dot(c, 0, 0, r * 0.26, '#000000');
      dot(c, 0, 0, r * 0.12, '#e9d8ff');
    } },
    { id: 'phoenix', name: 'Phoenix', cost: 6500, color: '#ff7a18', draw: function (c, r) {
      poly(c, [[-r * 1.25, -r * 0.05], [-r * 0.25, -r * 0.55], [-r * 0.35, r * 0.25]], '#ff3b00');
      poly(c, [[r * 1.25, -r * 0.05], [r * 0.25, -r * 0.55], [r * 0.35, r * 0.25]], '#ff3b00');
      disc(c, r, '#ff7a18');
      disc(c, r * 0.66, '#ffc24a');
      poly(c, [[0, -r * 0.05], [r * 0.12, r * 0.26], [-r * 0.12, r * 0.26]], '#ffe89e');
      dot(c, -r * 0.26, -r * 0.16, r * 0.08, '#3a0a0a');
      dot(c, r * 0.26, -r * 0.16, r * 0.08, '#3a0a0a');
    } },
    { id: 'glitch', name: 'Glitch', cost: 6500, color: '#00ffd0', draw: function (c, r) {
      c.save();
      c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
      disc(c, r, '#0a0f1e');
      c.globalAlpha = 0.9;
      c.fillStyle = '#ff0044'; c.fillRect(-r * 1.1, -r * 0.5, r * 2.2, r * 0.28);
      c.fillStyle = '#00ffd0'; c.fillRect(-r * 1.1, -r * 0.12, r * 2.2, r * 0.28);
      c.fillStyle = '#3a6bff'; c.fillRect(-r * 1.1, r * 0.26, r * 2.2, r * 0.28);
      c.globalAlpha = 1;
      c.restore();
    } },
    { id: 'magma', name: 'Magma', cost: 7000, color: '#ff5126', draw: function (c, r) {
      disc(c, r, '#2a0a06');
      seg(c, -r * 0.6, -r * 0.5, -r * 0.1, r * 0.1, r * 0.12, '#ff7a18');
      seg(c, -r * 0.1, r * 0.1, r * 0.5, r * 0.55, r * 0.1, '#ff7a18');
      seg(c, r * 0.2, -r * 0.6, r * 0.3, -r * 0.05, r * 0.1, '#ffb02e');
      seg(c, -r * 0.55, r * 0.4, -r * 0.05, r * 0.5, r * 0.09, '#ffb02e');
      dot(c, -r * 0.1, r * 0.1, r * 0.14, '#ffe066');
    } },
    { id: 'atom', name: 'Reactor', cost: 7500, color: '#39e6ff', draw: function (c, r) {
      disc(c, r, '#0c1830');
      c.save();
      for (var i = 0; i < 3; i++) {
        c.rotate(Math.PI / 3);
        c.beginPath(); c.ellipse(0, 0, r * 0.95, r * 0.4, 0, 0, TAU);
        c.lineWidth = r * 0.07; c.strokeStyle = '#39e6ff'; c.stroke();
      }
      c.restore();
      dot(c, 0, 0, r * 0.28, '#eaffff');
      dot(c, 0, 0, r * 0.18, '#39e6ff');
    } },
    { id: 'frost', name: 'Frostbite', cost: 7500, color: '#8fe6ff', draw: function (c, r) {
      disc(c, r, '#bfeeff');
      poly(c, [[0, -r], [r * 0.55, -r * 0.2], [0, r * 0.1]], '#e8faff');
      poly(c, [[0, -r], [-r * 0.55, -r * 0.2], [0, r * 0.1]], '#9fd6ee');
      poly(c, [[0, r], [r * 0.55, r * 0.2], [0, -r * 0.1]], '#a7e3f7');
      poly(c, [[0, r], [-r * 0.55, r * 0.2], [0, -r * 0.1]], '#cdf2ff');
      dot(c, -r * 0.28, -r * 0.3, r * 0.12, 'rgba(255,255,255,0.7)');
    } },
    { id: 'prism', name: 'Prism', cost: 8000, color: '#ffffff', draw: function (c, r) {
      var cols = ['#ff4d6d', '#ff9e2e', '#ffe14d', '#2bffc8', '#57b6ff', '#9c5bff'];
      for (var i = 0; i < 6; i++) {
        c.fillStyle = cols[i];
        c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, r, i / 6 * TAU, (i + 1) / 6 * TAU); c.closePath(); c.fill();
      }
      dot(c, 0, 0, r * 0.3, 'rgba(255,255,255,0.85)');
    } },
    { id: 'borealis', name: 'Aurora', cost: 8500, color: '#5ff0c0', draw: function (c, r) {
      var g = c.createLinearGradient(0, -r, 0, r);
      g.addColorStop(0, '#2bffc8'); g.addColorStop(0.5, '#57b6ff'); g.addColorStop(1, '#9c5bff');
      c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
      c.globalAlpha = 0.5; arc(c, 0, r * 0.2, r * 0.7, Math.PI * 1.1, Math.PI * 1.9, r * 0.12, '#eafffb'); c.globalAlpha = 1;
      shine(c, r);
    } },
    { id: 'eldritch', name: 'The Many', cost: 10000, color: '#6f43c9', draw: function (c, r) {
      disc(c, r, '#1a0e2e');
      disc(c, r * 0.9, '#2a1a47');
      var pts = [[-r * 0.35, -r * 0.3], [r * 0.32, -r * 0.36], [0, -r * 0.02], [-r * 0.3, r * 0.32], [r * 0.36, r * 0.3]];
      for (var i = 0; i < pts.length; i++) {
        dot(c, pts[i][0], pts[i][1], r * 0.16, '#c9a0ff');
        dot(c, pts[i][0], pts[i][1] + r * 0.02, r * 0.07, '#1a0033');
      }
    } },

    /* --- v10 Descent-themed (gem-priced) --- */
    { id: 'wardenmaw', name: 'Maw', cost: 3200, color: '#ff5a6e', draw: function (c, r) {
      disc(c, r, '#1a0608');
      for (var i = 0; i < 12; i++) {
        var a = i / 12 * TAU;
        poly(c, [[Math.cos(a) * r, Math.sin(a) * r],
                 [Math.cos(a + 0.17) * r * 0.7, Math.sin(a + 0.17) * r * 0.7],
                 [Math.cos(a - 0.17) * r * 0.7, Math.sin(a - 0.17) * r * 0.7]], '#f0e6e6');
      }
      dot(c, 0, 0, r * 0.42, '#ff5a6e');
      dot(c, 0, 0, r * 0.2, '#1a0608');
      dot(c, r * 0.07, -r * 0.07, r * 0.06, '#ffd0d0');
    } },
    { id: 'descent', name: 'Descent', cost: 4200, color: '#b58cff', draw: function (c, r) {
      disc(c, r, '#0a0518');
      var cols = ['#7a4dd6', '#b58cff', '#57b6ff', '#2bffc8'];
      c.globalAlpha = 0.92;
      for (var i = 0; i < 4; i++) {
        c.lineWidth = r * 0.1; c.strokeStyle = cols[i];
        c.beginPath(); c.arc(0, 0, r * (0.85 - i * 0.2), 0, TAU); c.stroke();
      }
      c.globalAlpha = 1;
      dot(c, 0, 0, r * 0.12, '#f0e6ff');
    } },

    /* --- Soul skins (v10 P2.2): bought ONLY with Souls (the Forge currency),
       never gems — so the gem economy + IAP are untouched. A Souls sink. --- */
    { id: 'wisp', name: 'Soul Wisp', soul: 20, color: '#c9a8ff', draw: function (c, r) {
      disc(c, r, '#2a1a47');
      dot(c, 0, 0, r * 0.72, '#6f43c9');
      dot(c, 0, -r * 0.1, r * 0.4, '#c9a8ff');
      dot(c, 0, -r * 0.16, r * 0.18, '#f0e6ff');
      dot(c, -r * 0.4, r * 0.45, r * 0.06, 'rgba(201,168,255,0.7)');
      dot(c, r * 0.46, r * 0.36, r * 0.05, 'rgba(201,168,255,0.6)');
    } },
    { id: 'soulfire', name: 'Soulfire', soul: 55, color: '#c9a8ff', draw: function (c, r) {
      disc(c, r, '#1a0e2e');
      poly(c, [[0, -r], [r * 0.5, r * 0.2], [0, r * 0.5], [-r * 0.5, r * 0.2]], '#7a4dd6');
      poly(c, [[0, -r * 0.7], [r * 0.32, r * 0.15], [0, r * 0.4], [-r * 0.32, r * 0.15]], '#c9a8ff');
      dot(c, 0, r * 0.05, r * 0.18, '#f0e6ff');
    } },
    { id: 'oracle', name: 'The Oracle', soul: 35, color: '#b58cff', draw: function (c, r) {
      disc(c, r, '#160b2e');
      for (var i = 0; i < 8; i++) {
        var a = i / 8 * TAU;
        seg(c, Math.cos(a) * r * 0.72, Math.sin(a) * r * 0.72,
               Math.cos(a) * r * 0.96, Math.sin(a) * r * 0.96, r * 0.05, '#7a4dd6');
      }
      dot(c, 0, 0, r * 0.6, '#7a4dd6');
      dot(c, 0, 0, r * 0.4, '#b58cff');
      dot(c, 0, 0, r * 0.2, '#0a0418');
      dot(c, -r * 0.07, -r * 0.07, r * 0.06, '#f0e6ff');
    } },
    { id: 'abyssal', name: 'Abyssal', soul: 50, color: '#5ad0ff', draw: function (c, r) {
      var g = c.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
      g.addColorStop(0, '#1a3a66'); g.addColorStop(1, '#05101f');
      c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
      dot(c, -r * 0.3, -r * 0.2, r * 0.08, '#5ad0ff');
      dot(c, r * 0.35, r * 0.1, r * 0.06, '#7af0c0');
      dot(c, r * 0.05, r * 0.45, r * 0.05, '#5ad0ff');
      dot(c, -r * 0.45, r * 0.35, r * 0.04, '#7af0c0');
      dot(c, r * 0.45, -r * 0.4, r * 0.05, '#a8e6ff');
    } },
    { id: 'ascendant', name: 'Ascendant', soul: 75, color: '#e8c9ff', draw: function (c, r) {
      for (var i = 0; i < 12; i++) {
        var a = i / 12 * TAU;
        seg(c, 0, 0, Math.cos(a) * r * 1.15, Math.sin(a) * r * 1.15, r * 0.06,
            i % 2 ? '#ffd24a' : '#c9a8ff');
      }
      var g = c.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
      g.addColorStop(0, '#fff7da'); g.addColorStop(0.6, '#c9a8ff'); g.addColorStop(1, '#7a4dd6');
      c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
      dot(c, 0, 0, r * 0.22, '#fff7da');
      shine(c, r);
    } }
  ];

  /* ---------- custom photo skin ---------- */

  var customImg = null;

  /* Returns the player's photo as a loaded <img>, or null while it
   * loads / when none is set. Triggers a skin rebuild once ready. */
  function customImage() {
    var data = Store.getCustomSkin();
    if (!data || !data.img) return null;
    if (!customImg || customImg._src !== data.img) {
      customImg = new Image();
      customImg._src = data.img;
      customImg.onload = function () {
        if (typeof Game !== 'undefined') Game.refreshSkin();
      };
      customImg.src = data.img;
    }
    return customImg.complete && customImg.naturalWidth > 0 ? customImg : null;
  }

  /* Unlock without paying gems (rewarded-ad path). */
  function grant(id) {
    var owned = Store.getOwned();
    if (owned.indexOf(id) === -1) {
      owned.push(id);
      Store.setOwned(owned);
    }
  }

  /* ---------- API ---------- */

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) {
      if (LIST[i].id === id) {
        var s = LIST[i];
        // the custom skin's theme color comes from the imported photo
        if (s.custom) {
          var data = Store.getCustomSkin();
          if (data && data.color) {
            return { id: s.id, name: s.name, cost: s.cost,
                     color: data.color, custom: true };
          }
        }
        return s;
      }
    }
    // unknown id: fall back to the free starter, not whatever sits first
    for (var j = 0; j < LIST.length; j++) {
      if (LIST[j].cost === 0) return LIST[j];
    }
    return LIST[0];
  }

  function isOwned(id) {
    var s = byId(id);
    // a Soul skin is never "free" (it has a Souls price, not cost 0)
    return (!s.soul && s.cost === 0) || Store.getOwned().indexOf(s.id) !== -1;
  }

  /* Unlock a skin. Soul skins are paid with Souls (the Forge currency); every
   * other skin is paid with gems. Returns true on success. The gem economy is
   * never touched by a Soul purchase and vice-versa. */
  function buy(id) {
    var s = byId(id);
    if (isOwned(s.id)) return true;
    if (s.soul) {
      var souls = Store.getSouls();
      if (souls < s.soul) return false;
      Store.addSouls(-s.soul);
    } else {
      var gems = Store.getGems();
      if (gems < s.cost) return false;
      Store.setGems(gems - s.cost);
    }
    var owned = Store.getOwned();
    owned.push(s.id);
    Store.setOwned(owned);
    return true;
  }

  function current() { return byId(Store.getSkin()); }

  /* Draw any skin (flat, character, or photo) at radius r, centered
   * at (0,0). Used by the in-game ball renderer and the shop tiles. */
  function renderIcon(c, r, skin) {
    if (skin.custom) {
      var img = customImage();
      if (img) {
        c.save();
        c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip();
        c.drawImage(img, -r, -r, r * 2, r * 2);
        c.restore();
        c.lineWidth = Math.max(1.5, r * 0.12);
        c.strokeStyle = skin.color;
        c.beginPath(); c.arc(0, 0, r - c.lineWidth / 2 + 0.5, 0, TAU); c.stroke();
      } else {
        // no photo yet: little camera glyph
        disc(c, r, '#27314a');
        c.fillStyle = '#9ad9ff';
        c.fillRect(-r * 0.55, -r * 0.3, r * 1.1, r * 0.75);
        dot(c, 0, r * 0.07, r * 0.26, '#27314a');
        dot(c, 0, r * 0.07, r * 0.14, '#9ad9ff');
        c.fillRect(-r * 0.15, -r * 0.45, r * 0.35, r * 0.18);
      }
      return;
    }
    if (skin.draw) {
      skin.draw(c, r);
    } else {
      disc(c, r, skin.color);
      dot(c, -r * 0.25, -r * 0.25, r * 0.42, skin.core || '#ffffff');
    }
  }

  return { LIST: LIST, byId: byId, isOwned: isOwned, buy: buy, grant: grant,
           current: current, renderIcon: renderIcon, customImage: customImage };
})();
