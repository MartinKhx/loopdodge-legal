/* Verify the publisher's signed manifest before any native download. The
 * private RSA key stays on the build machine; only its SPKI public key ships. */
var UpdateManifest = (function () {
  function bytes(base64) {
    var raw = atob(base64), result = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) result[i] = raw.charCodeAt(i);
    return result;
  }
  function validate(m, target) {
    if (!m || m.schemaVersion !== 1 || m.appId !== 'com.loopdodge.game' ||
        m.platform !== target.platform || m.environment !== target.environment ||
        m.nativeVersion !== target.nativeVersion || String(m.nativeBuild) !== String(target.nativeBuild) ||
        m.runtimeFingerprint !== target.runtimeFingerprint ||
        !/^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.-]+)?$/.test(m.version) ||
        !Number.isSafeInteger(m.sequence) || m.sequence < 1 ||
        !/^[a-f0-9]{64}$/.test(m.sha256) || typeof m.url !== 'string' ||
        !Number.isSafeInteger(m.bytes) || m.bytes < 1 || m.bytes > 52428800) return false;
    var url = new URL(m.url), manifestUrl = new URL(target.manifestUrl);
    if (url.protocol !== 'https:' || url.origin !== manifestUrl.origin || url.username || url.password || url.hash) return false;
    var now = Date.now(), expires = Date.parse(m.expiresAt), issued = Date.parse(m.issuedAt);
    return isFinite(expires) && isFinite(issued) && issued <= now + 300000 && expires > now && expires > issued;
  }
  function verify(envelope, key, target) {
    try {
      if (!envelope || typeof envelope.payload !== 'string' || envelope.payload.length > 8192 ||
          typeof envelope.signature !== 'string' || envelope.signature.length > 1024 ||
          !key) return Promise.resolve(null);
      var cap = window.Capacitor;
      if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
        var verifier = cap.Plugins && cap.Plugins.UpdateVerifier;
        if (!verifier && cap.registerPlugin) verifier = cap.registerPlugin('UpdateVerifier');
        if (!verifier) return Promise.resolve(null);
        return verifier.verify({ payload: envelope.payload, signature: envelope.signature }).then(function (result) {
          if (!result || result.valid !== true) return null;
          var manifest = JSON.parse(envelope.payload);
          return validate(manifest, target) ? manifest : null;
        }).catch(function () { return null; });
      }
      if (!window.crypto || !crypto.subtle) return Promise.resolve(null);
      var der = bytes(key.replace(/-----[^-]+-----/g, '').replace(/\s/g, ''));
      var algorithm = { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' };
      return crypto.subtle.importKey('spki', der, algorithm, false, ['verify']).then(function (publicKey) {
        return crypto.subtle.verify(algorithm, publicKey, bytes(envelope.signature), new TextEncoder().encode(envelope.payload));
      }).then(function (ok) {
        if (!ok) return null;
        var manifest = JSON.parse(envelope.payload);
        return validate(manifest, target) ? manifest : null;
      }).catch(function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }
  return { verify: verify };
})();
