/* Persistent state via localStorage, behind a versioned, self-healing
 * schema.
 *
 * Design:
 *  - Every value is validated and clamped on BOTH read and write, keyed
 *    by its storage key (SCHEMA below). A corrupted/out-of-range value
 *    can never reach gameplay — the worst case is a clean default.
 *  - A one-time migrate() runs at load: it snapshots a last-known-good
 *    backup, normalizes every known key in place, and stamps a schema
 *    version. It is wrapped so a failure can never brick startup.
 *  - Writes return a boolean success (false when storage is unavailable
 *    — private mode, full disk). write()/writeOrThrow() expose this for
 *    callers that must confirm durability before acting (the IAP ledger).
 *  - Unknown keys are passed through untouched, so a value written by a
 *    newer build survives a downgrade.
 *
 * The game still runs fully if storage is unavailable; it just won't
 * persist. */
var Store = (function () {
  var SCHEMA_VERSION = 2;

  var K = {
    best:   'ld_best',         // best run SCORE (survival seconds + near-miss points), float
    bestSec:'ld_best_seconds', // best pure SURVIVAL SECONDS (time-based unlocks/leaderboard)
    bestPts:'ld_best_points',  // best near-miss POINTS in a single run (stats only)
    gems:   'ld_gems',         // total gem currency
    owned:  'ld_skins_owned',  // array of owned skin ids
    skin:   'ld_skin',         // selected skin id
    levels: 'ld_levels_owned', // array of owned level ids
    level:  'ld_level',        // selected level id
    mute:   'ld_muted',        // sound effects off?
    music:  'ld_music_off',    // background music off?
    deaths: 'ld_death_count',  // finished runs, for interstitial cadence
    noAds:  'ld_ads_removed',  // bought the Remove Ads IAP
    custom: 'ld_custom_skin',  // { img: dataURL, color: '#rrggbb' }
    stDay:  'ld_streak_day',   // daily reward: last claimed day (1..7, 0 = never)
    stLast: 'ld_streak_last',  // daily reward: date of last claim ('YYYY-MM-DD')
    mis:    'ld_missions',     // active mission set [{tid, n, p, reward, track?}]
    misDone:'ld_missions_done',// lifetime completed missions (stats/achievements)
    shopDay:'ld_shop_gems_day',// date the shop's free daily gems were claimed
    dRun:   'ld_daily_run',    // daily challenge { date, best, claimed, started? }
    tut:    'ld_tutorial_done',// a run has been completed (skip the tutorial)
    nmTotal:'ld_near_total',   // lifetime near misses (Play Games achievement)
    timeTot:'ld_time_total',   // lifetime seconds survived (stats panel)
    gemsTot:'ld_gems_total',   // lifetime gems collected in runs (stats panel)
    comboBest:'ld_combo_best', // best near-miss combo ever (stats panel)
    storms: 'ld_storms_total', // lifetime storm bursts weathered (stats panel)
    plvl:   'ld_player_level', // player XP level (1+)
    pxp:    'ld_player_xp',    // XP banked into the current level
    trails: 'ld_trails_owned', // array of owned trail ids
    trail:  'ld_trail',        // selected trail id ('none' = off)
    redMo:  'ld_reduce_motion',// accessibility: no shake / hit-stop / zoom
    redFlash:'ld_reduce_flash',// accessibility: damp full-screen flashes
    hapt:   'ld_haptics',      // haptic intensity: 'off' | 'light' | 'full'
    rvAsk:  'ld_review_asked', // in-app review prompted once?
    nfAsk:  'ld_notif_asked',  // notification permission requested once?
    stRep:  'ld_streak_repair',// date of the last streak repair (weekly cap)
    theme:  'ld_theme',        // selected visual theme / world id
    ledger: 'ld_iap_ledger',   // processed in-app purchase transaction ids
    ultraPass:'ld_ultra_pass', // bought the Ultra Pass IAP (permanent x3 on EARNED gems + daily gift)
    ultraGift:'ld_ultra_gift_day',// date the Ultra Pass daily gem gift was last granted ('YYYY-MM-DD')
    souls:  'ld_souls',        // Souls: the Forge currency (NEVER gems/IAP — descent depth only)
    soulsTot:'ld_souls_total', // lifetime Souls earned (stats)
    codex:  'ld_relic_codex',  // relic ids discovered (drafted at least once) — Forge Codex
    attuned:'ld_relic_attuned',// relic ids permanently attuned (paid Souls) — seedable for free
    seed:   'ld_relic_seed',   // currently selected Seed relic id ('' = none) for the opening Pact
    deepest:'ld_deepest_sphere',// deepest Sphere ever reached (1..7; stats / Forge)
    wardens:'ld_wardens_felled',// lifetime Wardens defeated (stats)
    ghostDay:'ld_ghost_daily', // best ghost tape for today's daily { date, start, sw, end, score }
    ghostSeed:'ld_ghost_seed', // best ghost tape for the last raced seed code { seed, start, sw, end, score }
    ghostOff:'ld_ghost_off',   // ghost racer disabled? (preference)
    telem:  'ld_telemetry',    // last-N PII-free crash payloads (bounded, sanitized on read+write)
    tips:   'ld_tips_seen',    // one-time onboarding tip ids already shown/acknowledged
    lang:   'ld_lang',         // language override ('' = follow the device language)
    saveVer:'ld_save_version', // schema version of the persisted data
    saveBak:'ld_save_backup'   // last-known-good snapshot taken before a migration
  };

  /* ---------- value validators (clamp/normalize, NaN/Inf-safe) ---------- */

  var BIG = 1e12; // ceiling that catches corruption (Infinity, 1e308) but not real values

  /* Epoch-millis ceiling for timestamps. BIG (1e12) is BELOW the current
     Date.now() (~1.78e12), so reusing it as a ts ceiling would clamp every
     real crash timestamp down to 2001. TS_MAX = 2100-01-01 still catches
     corruption (Infinity / 1e308) while letting real timestamps through. */
  var TS_MAX = 4102444800000; // 2100-01-01T00:00:00Z in epoch ms

  function isNum(v) { return typeof v === 'number' && isFinite(v); }

  function num(v, def, min, max, int) {
    if (!isNum(v)) return def;
    if (v < min) v = min;
    if (max != null && v > max) v = max;
    return int ? Math.floor(v) : v;
  }
  function cleanArr(v) {
    if (!Array.isArray(v)) return [];
    var out = [], seen = {};
    for (var i = 0; i < v.length; i++) {
      var x = v[i];
      if (typeof x === 'string' && x && !seen[x]) { seen[x] = true; out.push(x); }
    }
    return out;
  }
  function cleanStr(v, def) { return (typeof v === 'string' && v) ? v : def; }
  function cleanBool(v, def) { return typeof v === 'boolean' ? v : def; }
  function cleanDate(v) { return (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) ? v : ''; }

  function cleanDailyRun(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
    if (typeof v.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v.date)) return null;
    return {
      date: v.date,
      best: num(v.best, 0, 0, BIG, false),
      claimed: v.claimed === true,
      started: v.started === true
    };
  }
  function cleanCustom(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
    if (typeof v.img !== 'string' || v.img.slice(0, 5) !== 'data:') return null;
    var color = (typeof v.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(v.color)) ? v.color : '#ffffff';
    return { img: v.img, color: color };
  }
  function cleanMissions(v) {
    if (!Array.isArray(v)) return null; // null -> Missions regenerates a fresh set
    var out = [];
    for (var i = 0; i < v.length; i++) {
      var m = v[i];
      if (m && typeof m === 'object' && typeof m.tid === 'string') {
        m.n = num(m.n, 1, 0, BIG, false);
        m.p = num(m.p, 0, 0, BIG, false);
        m.reward = num(m.reward, 0, 0, BIG, false);
        out.push(m);
      }
    }
    return out;
  }
  function cleanHaptics(v) { return (v === 'off' || v === 'light' || v === 'full') ? v : 'full'; }

  /* A ghost tape for the daily: a starting lane + bounded, finite switch
   * timestamps + the run's end angle/score. Self-contained (no dependency on
   * the Ghost module's load order). Returns a safe object or null. */
  function cleanGhostDaily(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
    if (typeof v.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v.date)) return null;
    var sw = [];
    if (Array.isArray(v.sw)) {
      for (var i = 0; i < v.sw.length && sw.length < 400; i++) {
        var x = v.sw[i];
        if (typeof x === 'number' && isFinite(x) && x >= 0) sw.push(x);
      }
    }
    return {
      date: v.date,
      start: v.start === 1 ? 1 : 0,
      sw: sw,
      end: num(v.end, 0, 0, BIG, false),
      score: num(v.score, 0, 0, BIG, true)
    };
  }

  /* A ghost tape for a SEED code (the same shape, keyed by a numeric seed). */
  function cleanGhostSeed(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
    if (!isNum(v.seed)) return null;
    var sw = [];
    if (Array.isArray(v.sw)) {
      for (var i = 0; i < v.sw.length && sw.length < 400; i++) {
        var x = v.sw[i];
        if (typeof x === 'number' && isFinite(x) && x >= 0) sw.push(x);
      }
    }
    return {
      seed: num(v.seed, 0, 0, BIG, true),
      start: v.start === 1 ? 1 : 0,
      sw: sw,
      end: num(v.end, 0, 0, BIG, false),
      score: num(v.score, 0, 0, BIG, true)
    };
  }

  /* A bounded list of PII-free crash payloads. Tampered/corrupt input
   * self-heals to []; we keep only the last 25 well-formed object rows and
   * normalize every field, so a hand-edited or downgrade-artifact value can
   * never reach a reader as anything but a clean array of clean objects. */
  function cleanTelemetry(v) {
    if (!Array.isArray(v)) return [];
    var out = [];
    for (var i = 0; i < v.length; i++) {
      var e = v[i];
      if (!e || typeof e !== 'object' || Array.isArray(e)) continue;
      out.push({
        message: cleanStr(e.message, ''),
        filename: cleanStr(e.filename, ''),
        lineno: num(e.lineno, 0, 0, BIG, true),
        colno: num(e.colno, 0, 0, BIG, true),
        stack: cleanStr(e.stack, ''),
        appVersion: cleanStr(e.appVersion, ''),
        platform: cleanStr(e.platform, ''),
        ts: num(e.ts, 0, 0, TS_MAX, true)
      });
    }
    /* Keep only the LAST (newest) 25 well-formed rows — mirrors the in-memory
       ring in telemetry.js. On an oversized read (downgrade artifact, tampered
       save, or a future raised cap) this drops the STALEST rows, never the
       newest crashes. */
    if (out.length > 25) out = out.slice(out.length - 25);
    return out;
  }

  /* key -> { def, val(parsed, def) }. Drives get/set validation AND migrate(). */
  var SCHEMA = {};
  SCHEMA[K.best]    = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, false); } };
  SCHEMA[K.bestSec] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.bestPts] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.gems]    = { def: 0,    val: function (v, d) { return num(v, d, 0, 1e9, true); } };
  SCHEMA[K.owned]   = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.skin]    = { def: 'neon', val: function (v, d) { return cleanStr(v, d); } };
  SCHEMA[K.levels]  = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.level]   = { def: 'loop', val: function (v, d) { return cleanStr(v, d); } };
  SCHEMA[K.mute]    = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.music]   = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.deaths]  = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.noAds]   = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.custom]  = { def: null, val: function (v) { return cleanCustom(v); } };
  SCHEMA[K.stDay]   = { def: 0,    val: function (v, d) { return num(v, d, 0, 7, true); } };
  SCHEMA[K.stLast]  = { def: '',   val: function (v) { return cleanDate(v); } };
  SCHEMA[K.mis]     = { def: null, val: function (v) { return cleanMissions(v); } };
  SCHEMA[K.misDone] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.shopDay] = { def: '',   val: function (v) { return cleanDate(v); } };
  SCHEMA[K.dRun]    = { def: null, val: function (v) { return cleanDailyRun(v); } };
  SCHEMA[K.tut]     = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.nmTotal] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.timeTot] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, false); } };
  SCHEMA[K.gemsTot] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.comboBest] = { def: 0,  val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.storms]  = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.plvl]    = { def: 1,    val: function (v, d) { return num(v, d, 1, BIG, true); } };
  SCHEMA[K.pxp]     = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, false); } };
  SCHEMA[K.trails]  = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.trail]   = { def: 'none', val: function (v, d) { return cleanStr(v, d); } };
  SCHEMA[K.redMo]   = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.redFlash]= { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.hapt]    = { def: 'full', val: function (v) { return cleanHaptics(v); } };
  SCHEMA[K.rvAsk]   = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.nfAsk]   = { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.stRep]   = { def: '',   val: function (v) { return cleanDate(v); } };
  SCHEMA[K.theme]   = { def: 'classic', val: function (v, d) { return cleanStr(v, d); } };
  SCHEMA[K.ledger]  = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.souls]   = { def: 0,    val: function (v, d) { return num(v, d, 0, 1e9, true); } };
  SCHEMA[K.soulsTot]= { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.codex]   = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.attuned] = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.seed]    = { def: '',   val: function (v, d) { return cleanStr(v, d); } };
  SCHEMA[K.deepest] = { def: 1,    val: function (v, d) { return num(v, d, 1, 7, true); } };
  SCHEMA[K.wardens] = { def: 0,    val: function (v, d) { return num(v, d, 0, BIG, true); } };
  SCHEMA[K.ghostDay]= { def: null, val: function (v) { return cleanGhostDaily(v); } };
  SCHEMA[K.ghostSeed]={ def: null, val: function (v) { return cleanGhostSeed(v); } };
  SCHEMA[K.ghostOff]= { def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.telem]   = { def: [],   val: function (v) { return cleanTelemetry(v); } };
  SCHEMA[K.ultraPass]={ def: false, val: function (v, d) { return cleanBool(v, d); } };
  SCHEMA[K.ultraGift]={ def: '',   val: function (v) { return cleanDate(v); } };
  SCHEMA[K.tips]    = { def: [],   val: function (v) { return cleanArr(v); } };
  SCHEMA[K.lang]    = { def: '',   val: function (v, d) { return cleanStr(v, d); } };

  /* ---------- low-level storage (no validation) ---------- */

  function rawGet(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }
  function rawSet(key, str) {
    try { localStorage.setItem(key, str); return true; } catch (e) { return false; }
  }
  function rawRemove(key) {
    try { localStorage.removeItem(key); return true; } catch (e) { return false; }
  }

  /* ---------- validated get/set ---------- */

  function get(key, fallback) {
    var parsed;
    var raw = rawGet(key);
    if (raw === null) { parsed = undefined; }
    else { try { parsed = JSON.parse(raw); } catch (e) { parsed = undefined; } }
    var s = SCHEMA[key];
    if (s) {
      var def = (fallback !== undefined) ? fallback : s.def;
      return s.val(parsed, def);
    }
    return parsed === undefined ? fallback : parsed;
  }

  /* Returns true if the value was durably written, false if storage
   * rejected it (private mode / quota). Validates/clamps on the way in. */
  function set(key, value) {
    var s = SCHEMA[key];
    var clean = s ? s.val(value, s.def) : value;
    return rawSet(key, JSON.stringify(clean));
  }

  /* Like set() but throws on failure — for callers that must NOT proceed
   * unless the write is durable (the purchase ledger). */
  function setOrThrow(key, value) {
    if (!set(key, value)) {
      throw new Error('Store: persistent write failed for ' + key);
    }
    return true;
  }

  /* ---------- one-time migration / self-heal ---------- */

  function migrate() {
    try {
      var verRaw = rawGet(K.saveVer);
      var ver = 1;
      if (verRaw !== null) { try { ver = JSON.parse(verRaw); } catch (e) { ver = 1; } }
      if (!isNum(ver)) ver = 1;
      if (ver >= SCHEMA_VERSION) { selfHeal(); return; }

      // Snapshot a last-known-good backup BEFORE touching anything.
      var backup = { v: ver, keys: {} };
      for (var name in K) {
        if (!K.hasOwnProperty(name)) continue;
        if (name === 'saveVer' || name === 'saveBak') continue;
        var rv = rawGet(K[name]);
        if (rv !== null) backup.keys[K[name]] = rv;
      }
      rawSet(K.saveBak, JSON.stringify(backup));

      selfHeal();

      // v2: best_seconds is derived CONSERVATIVELY from the legacy hybrid
      // best (survival seconds + near-miss points) so a returning player's
      // pure-survival best is never lost. Over-credits slightly; never reduces.
      if (rawGet(K.bestSec) === null) {
        var legacyBest = get(K.best, 0);
        if (legacyBest > 0) rawSet(K.bestSec, JSON.stringify(Math.floor(legacyBest)));
      }

      rawSet(K.saveVer, JSON.stringify(SCHEMA_VERSION));
    } catch (e) { /* never let migration brick startup */ }
  }

  /* Normalize every known key in place: re-write only when the cleaned
   * value differs from what's stored, so it's cheap on a healthy save. */
  function selfHeal() {
    var devGems = (typeof DEV_MODE !== 'undefined' && DEV_MODE);
    for (var key in SCHEMA) {
      if (!SCHEMA.hasOwnProperty(key)) continue;
      if (devGems && key === K.gems) continue; // never clobber a real wallet in DEV
      var raw = rawGet(key);
      if (raw === null) continue; // absent -> leave the default
      var parsed;
      try { parsed = JSON.parse(raw); } catch (e) { parsed = undefined; }
      var clean = SCHEMA[key].val(parsed, SCHEMA[key].def);
      var encoded = JSON.stringify(clean);
      if (encoded !== raw) rawSet(key, encoded);
    }
  }

  migrate();

  /* ---------- public API ---------- */

  return {
    // schema / maintenance
    SAVE_VERSION: SCHEMA_VERSION,
    getSaveVersion: function () { return get(K.saveVer, 1); },
    write: set,            // set(key,value) -> bool (used by IAP ledger)
    writeOrThrow: setOrThrow,
    keyFor: function (name) { return K[name]; },

    getBest:   function ()  { return get(K.best, 0); },
    setBest:   function (v) { return set(K.best, v); },
    getBestSeconds: function () { return get(K.bestSec, 0); },
    setBestSeconds: function (v) { return set(K.bestSec, v); },
    getBestPoints: function () { return get(K.bestPts, 0); },
    setBestPoints: function (v) { return set(K.bestPts, v); },
    // DEV builds pin the balance: reads always come back full AND writes
    // are dropped, so a dev session can never clobber a real ld_gems value.
    getGems:   function ()  {
      if (typeof DEV_MODE !== 'undefined' && DEV_MODE) return 999999;
      return get(K.gems, 0);
    },
    setGems:   function (v) {
      if (typeof DEV_MODE !== 'undefined' && DEV_MODE) return true;
      return set(K.gems, Math.max(0, Math.floor(v)));
    },
    // EARNED gems honor the Ultra Pass x3 multiplier (gameplay/missions/daily/
    // rewarded all funnel through here). PURCHASED gems and the flat daily gift
    // must bypass the multiplier — they use addGemsRaw.
    /* The Ultra Pass multiplier on EARNED gems. Single source of truth: the
     * HUD badge and the game-over payout read this too, so what the player
     * is shown can never drift from what the wallet actually receives. */
    gemMult:   function ()  { return Store.getUltraPass() ? 3 : 1; },
    addGems:   function (n) {
      return Store.setGems(Store.getGems() + n * Store.gemMult());
    },
    addGemsRaw: function (n) { return Store.setGems(Store.getGems() + n); },
    getOwned:  function ()  { return get(K.owned, []); },
    setOwned:  function (a) { return set(K.owned, a); },
    getSkin:   function ()  { return get(K.skin, 'neon'); },
    setSkin:   function (v) { return set(K.skin, v); },
    getOwnedLevels: function ()  { return get(K.levels, []); },
    setOwnedLevels: function (a) { return set(K.levels, a); },
    getLevel:  function ()  { return get(K.level, 'loop'); },
    setLevel:  function (v) { return set(K.level, v); },
    getMuted:  function ()  { return get(K.mute, false); },
    setMuted:  function (v) { return set(K.mute, v); },
    getMusicOff: function ()  { return get(K.music, false); },
    setMusicOff: function (v) { return set(K.music, v); },
    getAdsRemoved: function ()  { return get(K.noAds, false); },
    setAdsRemoved: function (v) { return set(K.noAds, v); },
    getUltraPass:  function ()  { return get(K.ultraPass, false); },
    setUltraPass:  function (v) { return set(K.ultraPass, v); },
    getUltraGiftDay: function ()  { return get(K.ultraGift, ''); },
    setUltraGiftDay: function (v) { return set(K.ultraGift, v); },
    getCustomSkin: function ()  { return get(K.custom, null); },
    setCustomSkin: function (v) { return set(K.custom, v); },
    clearCustomSkin: function () { return rawRemove(K.custom); },
    getDeaths: function ()  { return get(K.deaths, 0); },
    setDeaths: function (v) { return set(K.deaths, v); },
    getStreakDay:  function ()  { return get(K.stDay, 0); },
    setStreakDay:  function (v) { return set(K.stDay, v); },
    getStreakLast: function ()  { return get(K.stLast, ''); },
    setStreakLast: function (v) { return set(K.stLast, v); },
    getMissions:     function ()  { return get(K.mis, null); },
    setMissions:     function (a) { return set(K.mis, a); },
    getMissionsDone: function ()  { return get(K.misDone, 0); },
    setMissionsDone: function (v) { return set(K.misDone, v); },
    getShopGemsDay:  function ()  { return get(K.shopDay, ''); },
    setShopGemsDay:  function (v) { return set(K.shopDay, v); },
    getDailyRun:     function ()  { return get(K.dRun, null); },
    setDailyRun:     function (v) { return set(K.dRun, v); },
    getTutorialDone: function ()  { return get(K.tut, false); },
    setTutorialDone: function (v) { return set(K.tut, v); },
    getNearTotal:    function ()  { return get(K.nmTotal, 0); },
    setNearTotal:    function (v) { return set(K.nmTotal, v); },
    getTimeTotal:    function ()  { return get(K.timeTot, 0); },
    setTimeTotal:    function (v) { return set(K.timeTot, v); },
    getGemsTotal:    function ()  { return get(K.gemsTot, 0); },
    setGemsTotal:    function (v) { return set(K.gemsTot, v); },
    getComboBest:    function ()  { return get(K.comboBest, 0); },
    setComboBest:    function (v) { return set(K.comboBest, v); },
    getStormsSurvived: function ()  { return get(K.storms, 0); },
    setStormsSurvived: function (v) { return set(K.storms, v); },
    getPlayerLevel:  function ()  { return get(K.plvl, 1); },
    setPlayerLevel:  function (v) { return set(K.plvl, v); },
    getXP:           function ()  { return get(K.pxp, 0); },
    setXP:           function (v) { return set(K.pxp, v); },
    getOwnedTrails:  function ()  { return get(K.trails, []); },
    setOwnedTrails:  function (a) { return set(K.trails, a); },
    getTrail:        function ()  { return get(K.trail, 'none'); },
    setTrail:        function (v) { return set(K.trail, v); },
    getReduceMotion: function ()  { return get(K.redMo, false); },
    setReduceMotion: function (v) { return set(K.redMo, v); },
    getReduceFlash:  function ()  { return get(K.redFlash, false); },
    setReduceFlash:  function (v) { return set(K.redFlash, v); },
    getHaptics:      function ()  { return get(K.hapt, 'full'); },
    setHaptics:      function (v) { return set(K.hapt, v); },
    getReviewAsked:  function ()  { return get(K.rvAsk, false); },
    setReviewAsked:  function (v) { return set(K.rvAsk, v); },
    getNotifAsked:   function ()  { return get(K.nfAsk, false); },
    setNotifAsked:   function (v) { return set(K.nfAsk, v); },
    /* language override; '' means follow the device language (I18n decides) */
    getLang:         function ()  { return get(K.lang, ''); },
    setLang:         function (v) { return set(K.lang, v); },
    /* one-time onboarding tips: seen-ids array, self-healing like every list */
    isTipSeen:       function (id) { return get(K.tips, []).indexOf(String(id)) !== -1; },
    markTipSeen:     function (id) {
      var a = get(K.tips, []);
      if (a.indexOf(String(id)) !== -1) return true;
      a.push(String(id));
      return set(K.tips, a);
    },
    getStreakRepair: function ()  { return get(K.stRep, ''); },
    setStreakRepair: function (v) { return set(K.stRep, v); },
    getTheme:        function ()  { return get(K.theme, 'classic'); },
    setTheme:        function (v) { return set(K.theme, v); },

    /* ---- Souls + Forge (v10 P1.2) ----
     * Souls are a SEPARATE currency earned from Descent depth. They fund the
     * Forge ONLY and can never buy gems, skins, ads or anything in the IAP
     * shop — the gem economy stays exactly as it was. DEV builds pin Souls
     * (like gems) so the Forge can be exercised without grinding. */
    getSouls: function ()  {
      if (typeof DEV_MODE !== 'undefined' && DEV_MODE) return 999999;
      return get(K.souls, 0);
    },
    setSouls: function (v) {
      if (typeof DEV_MODE !== 'undefined' && DEV_MODE) return true;
      return set(K.souls, Math.max(0, Math.floor(v)));
    },
    addSouls: function (n) { return Store.setSouls(Store.getSouls() + n); },
    getSoulsTotal: function ()  { return get(K.soulsTot, 0); },
    setSoulsTotal: function (v) { return set(K.soulsTot, v); },
    getDeepestSphere: function ()  { return get(K.deepest, 1); },
    setDeepestSphere: function (v) { return set(K.deepest, v); },
    getWardensFelled: function ()  { return get(K.wardens, 0); },
    setWardensFelled: function (v) { return set(K.wardens, v); },

    /* Relic Codex: the set of relics ever drafted. Discovery is a union
     * (idempotent), so a revive's double-finalize can never corrupt it. */
    getRelicCodex: function ()  { return get(K.codex, []); },
    setRelicCodex: function (a) { return set(K.codex, a); },
    addRelicSeen: function (id) {
      if (typeof id !== 'string' || !id) return false;
      var c = get(K.codex, []);
      if (c.indexOf(id) === -1) { c.push(id); return set(K.codex, c); }
      return true;
    },
    /* Attuned relics: paid with Souls, seedable into the opening Pact for free. */
    getRelicAttuned: function ()  { return get(K.attuned, []); },
    addRelicAttuned: function (id) {
      if (typeof id !== 'string' || !id) return false;
      var a = get(K.attuned, []);
      if (a.indexOf(id) === -1) { a.push(id); return set(K.attuned, a); }
      return true;
    },
    isRelicAttuned: function (id) { return get(K.attuned, []).indexOf(id) !== -1; },
    getRelicSeed: function ()  { return get(K.seed, ''); },
    setRelicSeed: function (v) { return set(K.seed, v); },

    /* Ghost racing (P0.2): the best tape for today's daily + the toggle. */
    getGhostDaily: function ()  { return get(K.ghostDay, null); },
    setGhostDaily: function (v) { return set(K.ghostDay, v); },
    getGhostSeed:  function ()  { return get(K.ghostSeed, null); },
    setGhostSeed:  function (v) { return set(K.ghostSeed, v); },
    getGhostOff:   function ()  { return get(K.ghostOff, false); },
    setGhostOff:   function (v) { return set(K.ghostOff, v); },

    /* Telemetry (Phase 1): a bounded, sanitized list of PII-free crash
     * payloads, validated/clamped to the last 25 object rows on read+write. */
    getTelemetry:  function ()  { return get(K.telem, []); },
    setTelemetry:  function (v) { return set(K.telem, v); },

    /* Processed-purchase ledger (Phase 2): idempotent, keyed by stable
     * transaction id. */
    getLedger:      function ()  { return get(K.ledger, []); },
    hasProcessedTxn: function (id) { return get(K.ledger, []).indexOf(id) !== -1; },
    /* Durably append a transaction id; throws if it can't persist, so the
     * caller knows NOT to finish the transaction yet. */
    addProcessedTxn: function (id) {
      var l = get(K.ledger, []);
      if (l.indexOf(id) === -1) {
        l.push(id);
        if (l.length > 200) l = l.slice(l.length - 200); // bound the ledger
        setOrThrow(K.ledger, l);
      }
      return true;
    },

    /* Wipe ALL Loop Dodge progress (in-app "reset progress"). Removes every
     * ld_ key, including the custom photo and the purchase ledger, then
     * re-stamps the current schema version. */
    resetAll: function () {
      var ok = true;
      for (var name in K) {
        if (!K.hasOwnProperty(name)) continue;
        if (!rawRemove(K[name])) ok = false;
      }
      rawSet(K.saveVer, JSON.stringify(SCHEMA_VERSION));
      return ok;
    }
  };
})();
