/* ============================================================
 * PRODUCTION AD CONFIG — TEMPLATE.
 *
 * The tracked www/js/ad-config.js is the safe TEST default (Google test
 * units, isTesting:true), so the dev tree and debug APK can never serve
 * live ads. To build a PRODUCTION release that serves real ads:
 *
 *   1. Copy this file to  www/js/ad-config.prod.js  (which is GITIGNORED,
 *      so your real ad ids never enter version control).
 *   2. Fill in all FOUR real unit ids below (Android + iOS).
 *   3. Keep rewardedOnly:true, isTesting:false and testingDevices:[] for
 *      the uploaded build.
 *
 * This template must carry the SAME KEYS as the real prod config — a copy
 * that silently loses `rewardedOnly` re-enables interstitials, and a copy
 * that loses the iOS ids serves the Android unit to iPhones. `npm run
 * preflight` blocks a release for both, but the template is the place to
 * not get it wrong in the first place.
 *
 * `npm run aab` detects ad-config.prod.js, swaps it in for the build, runs
 * the release preflight, then restores the test config — so the working
 * tree is always left test-safe.
 *
 * The AdMob *App* id (the "~" one) lives in AndroidManifest.xml (Android)
 * and ios/App/App/Info.plist (iOS) and must belong to the SAME AdMob
 * account as the unit ids below.
 * ============================================================ */
var AD_CONFIG = {
  // Android — REAL units.
  interstitialId: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // your REAL Android interstitial
  rewardedId:     'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // your REAL Android rewarded

  // iOS — REAL units. AdMob ids are PER-PLATFORM, and these are not optional:
  // ads.js falls back to the ANDROID unit on iPhone when they are absent, and
  // serving an Android unit to iOS is invalid traffic to AdMob.
  iosInterstitialId: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // your REAL iOS interstitial
  iosRewardedId:     'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // your REAL iOS rewarded

  // REWARD-ONLY: no interstitial is ever loaded or shown. This is the shipped
  // setting and it is what the store listing and the privacy policy claim.
  // Leaving it out (undefined) silently re-enables the interstitial cadence.
  rewardedOnly: true,

  interstitialEvery: 3, // ignored while rewardedOnly is true
  graceRuns: 6,         // ignored while rewardedOnly is true

  isTesting: false,     // LIVE ads
  testingDevices: []    // empty for the uploaded build
};
