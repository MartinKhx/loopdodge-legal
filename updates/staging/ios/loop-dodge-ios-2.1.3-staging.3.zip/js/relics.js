/* Relics (v10 "Oracle's Descent" P1.1 + P1.2): drafted in-run via the
 * Pact-Gate (whatever lane the ball is in when the gate sweeps past picks
 * the relic).
 *
 * HARD CONTRACT: every relic is a FAIRNESS-NEUTRAL run-state scalar/flag read
 * in update()/collectGem()/nearMiss() — exactly like slowT/doubleT/feastT.
 * A relic NEVER:
 *   - calls rng() inside spawn() (the 8-draw determinism contract is sacred),
 *   - touches the world clock (wScale/speed) or the angle-fairness floor
 *     (gapMin/gapMinSwitch),
 *   - lets the magnet reach across to the safe lane.
 * So relics change what your GEMS/COMBO/SHIELD/MAGNET/POWER-UPS do — never the
 * spawn stream, the difficulty, or whether a lane is passable.
 *
 * Relic OFFERS are drawn from a SEPARATE rng with a FIXED draw count per gate,
 * so the seeded daily stays byte-identical (the spawn rng is untouched). The
 * OFFER POOL widens with the gate ORDINAL (pactCount), NOT the clock — gate
 * ordinal is identical across devices/refresh-rates, so the daily is safe. */
var Relics = (function () {
  var TAU = Math.PI * 2;

  /* archetypes (for Codex grouping / flavor only — no mechanical effect) */
  var ARCH = { gem: 'Avarice', guard: 'Aegis', flow: 'Tempo', power: 'Surge' };

  /* Each `apply(s)` mutates the per-run relic accumulator. `tier` (1..4) gates
   * which gate ordinal can offer it; deeper gates draft rarer relics. Gem
   * MULTIPLIERS take the MAX (never multiply) so they obey the same x2-wins,
   * non-stacking economy guardrail the Doubler does. */
  var LIST = [
    /* ---- Tier 1 · commons (the opening Pact + early gates) ---- */
    { id: 'prospector', name: 'Prospector', color: '#7af0a0', glyph: '◆', tier: 1, arch: 'gem',
      desc: '+1 gem per pickup', apply: function (s) { s.gemAdd += 1; } },
    { id: 'shrapnel', name: 'Gem Shrapnel', color: '#9cff5a', glyph: '✸', tier: 1, arch: 'gem',
      desc: '+1 gem per near-miss', apply: function (s) { s.nearGem += 1; } },
    { id: 'stormcaller', name: 'Stormcaller', color: '#9ad9ff', glyph: '⚡', tier: 1, arch: 'gem',
      desc: '+15 gems each storm survived', apply: function (s) { s.stormGems += 15; } },
    { id: 'thickskin', name: 'Thick Skin', color: '#57b6ff', glyph: '◉', tier: 1, arch: 'guard',
      desc: 'Begin the Descent with a Shield', apply: function (s) { s.startShield = true; } },
    { id: 'phalanx', name: 'Phalanx', color: '#57b6ff', glyph: '❖', tier: 1, arch: 'guard',
      desc: 'A Shield reforms every 8 near-misses', apply: function (s) { s.phalanx += 1; } },
    { id: 'lodestone', name: 'Lodestone', color: '#c9a0ff', glyph: '⧉', tier: 1, arch: 'power',
      desc: 'Magnet power-ups last +2s', apply: function (s) { s.magnetDur += 2; } },
    { id: 'momentum', name: 'Momentum', color: '#ffd24a', glyph: '➜', tier: 1, arch: 'flow',
      desc: 'Your combo holds +1.5s longer', apply: function (s) { s.comboHold += 1.5; } },
    { id: 'overcharge', name: 'Overcharge', color: '#ffe066', glyph: '×2', tier: 1, arch: 'power',
      desc: 'The Doubler lasts +3s', apply: function (s) { s.doubleDur += 3; } },

    /* ---- Tier 2 · uncommons ---- */
    { id: 'quartz', name: 'Quartzheart', color: '#8fe0ff', glyph: '◈', tier: 2, arch: 'gem',
      desc: '+2 gems per pickup', apply: function (s) { s.gemAdd += 2; } },
    { id: 'richveins', name: 'Rich Veins', color: '#9ad9ff', glyph: '✦', tier: 2, arch: 'gem',
      desc: '+30 gems each storm survived', apply: function (s) { s.stormGems += 30; } },
    { id: 'glacier', name: 'Glacier', color: '#bfe9ff', glyph: '❄', tier: 2, arch: 'power',
      desc: 'Slow-mo power-ups last +3s', apply: function (s) { s.slowDur += 3; } },
    { id: 'gourmand', name: 'Gourmand', color: '#ffb84a', glyph: '◐', tier: 2, arch: 'power',
      desc: 'Feast power-ups last +3s', apply: function (s) { s.feastDur += 3; } },
    { id: 'cascade', name: 'Cascade', color: '#ffd24a', glyph: '➤', tier: 2, arch: 'flow',
      desc: 'Your combo holds +3s longer', apply: function (s) { s.comboHold += 3; } },
    { id: 'bulwark', name: 'Bulwark', color: '#57b6ff', glyph: '⬡', tier: 2, arch: 'guard',
      desc: 'Start shielded; it reforms on near-misses',
      apply: function (s) { s.startShield = true; s.phalanx += 1; } },
    { id: 'gemveil', name: 'Gemveil', color: '#7af0a0', glyph: '✚', tier: 2, arch: 'gem',
      desc: '+1 gem per pickup AND per near-miss',
      apply: function (s) { s.gemAdd += 1; s.nearGem += 1; } },
    { id: 'cryocell', name: 'Cryocell', color: '#bfe9ff', glyph: '✻', tier: 2, arch: 'power',
      desc: 'Slow-mo lasts +3s, Magnet +2s',
      apply: function (s) { s.slowDur += 3; s.magnetDur += 2; } },

    /* ---- Tier 3 · rares ---- */
    { id: 'midas', name: 'Midas Touch', color: '#ffd24a', glyph: '✷', tier: 3, arch: 'gem',
      desc: 'Gems are worth ×1.5 (does not stack with ×2)',
      apply: function (s) { s.gemMult = Math.max(s.gemMult, 1.5); } },
    { id: 'hoard', name: 'Hoard', color: '#7af0a0', glyph: '◇', tier: 3, arch: 'gem',
      desc: '+3 gems per pickup, +1 per near-miss',
      apply: function (s) { s.gemAdd += 3; s.nearGem += 1; } },
    { id: 'avalanche', name: 'Avalanche', color: '#cfefff', glyph: '❅', tier: 3, arch: 'power',
      desc: 'Slow-mo power-ups last +5s', apply: function (s) { s.slowDur += 5; } },
    { id: 'juggernaut', name: 'Juggernaut', color: '#ffd24a', glyph: '»', tier: 3, arch: 'flow',
      desc: 'Combo holds +4s; +1 gem per near-miss',
      apply: function (s) { s.comboHold += 4; s.nearGem += 1; } },
    { id: 'aegis', name: 'Aegis', color: '#57b6ff', glyph: '⬢', tier: 3, arch: 'guard',
      desc: 'Start shielded; combo holds +2s',
      apply: function (s) { s.startShield = true; s.comboHold += 2; } },
    { id: 'goldrush', name: 'Gold Rush', color: '#ffd24a', glyph: '✜', tier: 3, arch: 'gem',
      desc: '+2 gems per pickup, +20 each storm',
      apply: function (s) { s.gemAdd += 2; s.stormGems += 20; } },
    { id: 'sentinel', name: 'Sentinel', color: '#57b6ff', glyph: '⊕', tier: 3, arch: 'guard',
      desc: 'Start shielded; it reforms; Magnet +2s',
      apply: function (s) { s.startShield = true; s.phalanx += 1; s.magnetDur += 2; } },
    { id: 'crescendo', name: 'Crescendo', color: '#ffd24a', glyph: '≫', tier: 3, arch: 'flow',
      desc: 'Combo holds +3s; the Doubler lasts +2s',
      apply: function (s) { s.comboHold += 3; s.doubleDur += 2; } },

    /* ---- Tier 4 · legendary + cursed pacts (deep gates only) ---- */
    { id: 'philosopher', name: "Philosopher's Stone", color: '#ffe066', glyph: '✪', tier: 4, arch: 'gem',
      desc: 'Gems are worth ×2 (does not stack with ×2)',
      apply: function (s) { s.gemMult = Math.max(s.gemMult, 2.0); } },
    { id: 'titan', name: 'Titan', color: '#9cc4ff', glyph: '★', tier: 4, arch: 'guard',
      desc: 'Start shielded; it reforms; combo holds +2s',
      apply: function (s) { s.startShield = true; s.phalanx += 1; s.comboHold += 2; } },
    { id: 'pact_avarice', name: 'Pact of Avarice', color: '#ff6688', glyph: '✖', tier: 4, arch: 'gem', cursed: true,
      desc: '+5 gems per pickup, but combos fade fast',
      apply: function (s) { s.gemAdd += 5; s.comboHold -= 3; } },
    { id: 'pact_hunger', name: 'Pact of Hunger', color: '#c46bff', glyph: '▼', tier: 4, arch: 'power', cursed: true,
      desc: 'Gems ×2.5, but power-ups wither',
      apply: function (s) { s.gemMult = Math.max(s.gemMult, 2.5); s.magnetDur -= 3; s.slowDur -= 3; } },
    { id: 'overlord', name: 'Overlord', color: '#9c5bff', glyph: '❉', tier: 4, arch: 'power',
      desc: 'Every power-up lasts +4s',
      apply: function (s) { s.magnetDur += 4; s.slowDur += 4; s.feastDur += 4; s.doubleDur += 4; } },
    { id: 'pact_glass', name: 'Pact of Glass', color: '#ff6688', glyph: '◊', tier: 4, arch: 'gem', cursed: true,
      desc: 'Gems ×2 and +3 each, but combos are brittle',
      apply: function (s) { s.gemMult = Math.max(s.gemMult, 2.0); s.gemAdd += 3; s.comboHold -= 2; } }
  ];

  /* Souls cost to permanently ATTUNE a relic (Forge): once attuned, it can be
   * SEEDED into your opening Pact for free. Indexed by tier (1..4). */
  var SEED_COST = [0, 8, 16, 28, 44];

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) if (LIST[i].id === id) return LIST[i];
    return null;
  }
  function seedCost(id) { var r = byId(id); return r ? (SEED_COST[r.tier] || 0) : 0; }

  /* A fresh per-run accumulator. game.js reads these in its hot paths.
   * gemMult starts at 1 (no multiplier); everything else additive from 0. */
  function freshState() {
    return {
      gemAdd: 0,          // +N gem value per pickup (Prospector/Quartz/Hoard…)
      gemMult: 1,         // x gem value, MAX-wins vs the Doubler (Midas/Philosopher/Hunger)
      nearGem: 0,         // +N gems per near-miss (Gem Shrapnel)
      stormGems: 0,       // +N gems each storm weathered (Stormcaller/Rich Veins)
      startShield: false, // a drafted shield-relic grants a Shield on draft (Thick Skin…)
      phalanx: 0,         // a Shield reforms every 8 near-misses (Phalanx/Bulwark/Titan)
      magnetDur: 0,       // +s magnet duration (Lodestone)
      slowDur: 0,         // +s slow-mo duration (Glacier/Avalanche)
      feastDur: 0,        // +s feast duration (Gourmand)
      comboHold: 0,       // +s combo timer (Momentum/Cascade/Juggernaut; cursed pacts subtract)
      doubleDur: 0,       // +s doubler duration (Overcharge)
      held: []            // relic ids drafted this run (for the HUD rail + Codex)
    };
  }

  /* The widening tier cap for a gate ORDINAL (0 = opening Pact). Framerate-
   * independent (gate count, never the clock), so the seeded daily is safe. */
  function tierForGate(n) {
    if (n <= 0) return 1;   // opening Pact: commons only
    if (n <= 2) return 2;
    if (n <= 4) return 3;
    return 4;               // deep gates: legendaries + cursed pacts in the mix
  }

  /* The relics offerable at a given gate ordinal (tier <= cap). */
  function poolForGate(n) {
    var cap = tierForGate(n), out = [];
    for (var i = 0; i < LIST.length; i++) if (LIST[i].tier <= cap) out.push(LIST[i]);
    return out;
  }

  /* Draw `count` distinct relic offers from `pool` (default: all relics),
   * consuming EXACTLY `count` rng() calls regardless of collisions, so a
   * seeded run is byte-identical at any frame rate. */
  function drawOffers(rng, count, pool) {
    pool = pool || LIST;
    if (pool.length === 0) return [];
    var out = [], used = {};
    for (var i = 0; i < count; i++) {
      var idx = Math.floor(rng() * pool.length);    // exactly 1 rng() per offer
      if (idx >= pool.length) idx = pool.length - 1; // guard rng()===1
      var tries = 0;
      while (used[idx] && tries < pool.length) { idx = (idx + 1) % pool.length; tries++; }
      used[idx] = true;
      out.push(pool[idx]);
    }
    return out;
  }

  /* Forge Seed: guarantee an attuned relic appears among the offers WITHOUT
   * drawing rng (so it can never perturb a seeded stream). If the seed is
   * already offered, the offers are returned unchanged; otherwise it replaces
   * the first offer. Returns a new array; never mutates the input. Callers
   * only pass a seed on PERSONAL runs — the daily passes none, so it stays
   * byte-identical. */
  function applySeed(offers, seedId) {
    if (!seedId || !offers || !offers.length) return offers;
    for (var i = 0; i < offers.length; i++) if (offers[i].id === seedId) return offers;
    var sr = byId(seedId);
    if (!sr) return offers;
    var out = offers.slice();
    out[0] = sr;
    return out;
  }

  /* Small procedural icon (colored disc + glyph), used by the gate, rail and
   * Forge Codex. */
  function drawIcon(c, x, y, r, relic) {
    c.save();
    c.globalAlpha = 1;
    c.fillStyle = relic.color;
    c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    c.fillStyle = 'rgba(0,0,0,0.55)';
    c.beginPath(); c.arc(x, y, r * 0.66, 0, TAU); c.fill();
    c.fillStyle = relic.color;
    c.font = '700 ' + (r * 0.9).toFixed(1) + 'px system-ui, sans-serif';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(relic.glyph, x, y + r * 0.05);
    c.restore();
  }

  return {
    LIST: LIST, ARCH: ARCH, byId: byId, seedCost: seedCost,
    freshState: freshState, tierForGate: tierForGate, poolForGate: poolForGate,
    drawOffers: drawOffers, applySeed: applySeed, drawIcon: drawIcon
  };
})();
