/* Wardens (v10 "Oracle's Descent" P2.1): scripted boss duels at Sphere IV / VI.
 *
 * A Warden is a TIME-BOXED encounter, triggered ONLY on personal runs (never
 * the seeded daily, never Zen), so it can morph geometry and script attacks
 * without any cross-device determinism concern.
 *
 * HARD CONTRACT (fairness, by construction):
 *  - The track MORPH is a smooth radial deformation added to trackR(theta). It
 *    shifts the ball AND every spike together (both read trackR at their angle),
 *    and the cross-lane gap is 2*laneOff regardless of trackR — so the morph
 *    NEVER changes whether a lane is passable. It is, in effect, pure feel.
 *  - Attacks are SCRIPTED, single-lane, telegraphed a full spawnLead ahead (the
 *    same reaction window as a normal spike), and consume ZERO rng. One lane is
 *    always clear, so a Warden can never create an unavoidable death. (Normal
 *    spawns + storms are suppressed during the duel, so attacks are the only
 *    threat — verified by a headless-autoplayer survival test.) */
var Wardens = (function () {
  /* Two Wardens, cycled by trigger order. `lobes` shapes the morph; `dur` is
   * the duel length; `attackEvery` the cadence of scripted bites. */
  var LIST = [
    { id: 'maw',       name: 'THE MAW',  color: '#ff5a6e', lobes: 3, dur: 11, attackEvery: 1.5 },
    { id: 'leviathan', name: 'LEVIATHAN', color: '#b56bff', lobes: 5, dur: 13, attackEvery: 1.3 }
  ];

  function byIndex(i) { return LIST[((i % LIST.length) + LIST.length) % LIST.length]; }

  /* Smooth radial deformation factor, in [-amp, amp], 0 when env (0..1) is 0.
   * Low spatial frequency keeps the numerical track-frame (tangent/normal)
   * essentially unchanged, so spike orientation stays sane. */
  function deform(theta, phase, lobes, amp, env) {
    return env * amp * Math.sin(lobes * theta + phase);
  }

  /* The lane a scripted attack occupies. A fixed, learnable rhythm — ALWAYS a
   * single lane (the other is the guaranteed escape), and deterministic (no
   * rng), so the autoplayer can prove every attack is survivable. */
  var PATTERN = [0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1];
  function attackLane(n) {
    return PATTERN[((n % PATTERN.length) + PATTERN.length) % PATTERN.length];
  }

  return { LIST: LIST, byIndex: byIndex, deform: deform, attackLane: attackLane };
})();
