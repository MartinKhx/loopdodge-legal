/* All sound effects are synthesized with WebAudio at runtime —
 * zero audio assets, tiny footprint, works offline.
 * The AudioContext is created lazily on the first user gesture
 * (mobile browsers/WebViews require this). */
var Sound = (function () {
  var ctx = null;
  var master = null;
  var muted = Store.getMuted();

  /* Create/resume the context. Must be called from a user gesture
   * at least once (main.js calls it on every pointerdown). */
  function unlock() {
    // A closed context can never be revived — drop it so we build a fresh
    // one instead of silently running every sound into a dead graph.
    if (ctx && ctx.state === 'closed') { ctx = null; master = null; musicGain = null; }
    if (!ctx) {
      try {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = muted ? 0 : 1;
        master.connect(ctx.destination);
        // iOS can suspend or interrupt the audio session without ever firing
        // visibilitychange (phone call, Siri, another app taking audio). React
        // to the context's own state instead of trusting page lifecycle alone.
        if (ctx.addEventListener) {
          ctx.addEventListener('statechange', function () {
            if (ctx && ctx.state === 'running') anchor();
          });
        }
      } catch (e) {
        ctx = null;
        return;
      }
    }
    ensureRunning();
  }

  /* Bring a suspended/interrupted context back. Re-anchors on success: the
   * context clock does NOT advance while suspended, so whatever the scheduler
   * last computed is stale the moment it resumes. */
  function ensureRunning() {
    if (!ctx) return false;
    if (ctx.state === 'running') return true;
    try {
      var p = ctx.resume();
      if (p && p.then) p.then(anchor, function () {});
    } catch (e) { /* resume may need a gesture; the next tap retries */ }
    return ctx.state === 'running';
  }

  /* One enveloped oscillator: type, start/end frequency, duration,
   * volume, optional start delay (seconds). */
  function blip(type, f0, f1, dur, vol, delay) {
    if (!ctx || muted) return;
    var t0 = ctx.currentTime + (delay || 0);
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t0);
    if (f1 && f1 !== f0) osc.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    gain.gain.setValueAtTime(vol, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.03);
  }

  /* Filtered white-noise burst (used for the death crunch). */
  function noise(dur, vol, delay) {
    if (!ctx || muted) return;
    var t0 = ctx.currentTime + (delay || 0);
    var len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var data = buf.getChannelData(0);
    for (var i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    var src = ctx.createBufferSource();
    src.buffer = buf;
    var filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = 900;
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(vol, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filt);
    filt.connect(gain);
    gain.connect(master);
    src.start(t0);
  }

  /* ============ background music ============
   * A quiet generative loop (pad chords + bass + sparse plucks),
   * synthesized live — no audio files. Runs through its own gain so
   * the music toggle is independent of the SFX mute (the SFX mute
   * silences everything, including music, via the master gain). */
  var musicOff = Store.getMusicOff();
  var musicGain = null;
  var musicTimer = null;
  var nextBar = 0;
  var barIndex = 0;
  var BAR = 1.9; // seconds per bar (~126bpm half-time feel)
  var musicIntensity = 0; // 0..6 = Sphere depth; deeper = more layers + brighter

  // Am - F - C - G in a mellow voicing
  var CHORDS = [
    [110.00, 164.81, 220.00, 261.63],
    [87.31, 174.61, 220.00, 261.63],
    [130.81, 196.00, 261.63, 329.63],
    [98.00, 196.00, 246.94, 293.66]
  ];
  var PENTA = [220.00, 261.63, 329.63, 392.00, 440.00, 523.25];

  function musicNote(freq, t0, dur, vol, type, filterHz) {
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    var filt = ctx.createBiquadFilter();
    osc.type = type;
    osc.frequency.value = freq;
    filt.type = 'lowpass';
    filt.frequency.value = filterHz;
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + Math.min(0.4, dur * 0.3));
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(filt); filt.connect(gain); gain.connect(musicGain);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  function scheduleBar(t0) {
    var chord = CHORDS[barIndex % CHORDS.length];
    var inten = musicIntensity;          // 0..6: deepens the mix as you descend
    var bright = 800 + inten * 220;      // open the pad lowpass tier by tier
    // pad: the chord, soft triangles
    for (var i = 1; i < chord.length; i++) {
      musicNote(chord[i], t0, BAR * 1.05, 0.035, 'triangle', bright);
    }
    // bass: root, two pushes per bar
    musicNote(chord[0], t0, BAR * 0.45, 0.07, 'sine', 400);
    musicNote(chord[0], t0 + BAR * 0.5, BAR * 0.45, 0.05, 'sine', 400);
    // sparse plucks on random eighths (skip some bars entirely)
    if (barIndex % 4 !== 3) {
      for (var s = 0; s < 8; s++) {
        if (Math.random() < 0.22) {
          var f = PENTA[Math.floor(Math.random() * PENTA.length)];
          musicNote(f, t0 + (s / 8) * BAR, 0.5, 0.045, 'sine', 2200);
        }
      }
    }
    // ADAPTIVE LAYERS — added on bar boundaries so swaps never click.
    // Sphere 2+ adds an octave arp; Sphere 4+ adds a driving eighth sub-bass.
    if (inten >= 2) {
      var steps = inten >= 4 ? 8 : 4;
      for (var a = 0; a < steps; a++) {
        var nf = PENTA[(a + barIndex) % PENTA.length] * 2;
        musicNote(nf, t0 + (a / steps) * BAR, (BAR / steps) * 0.9, 0.018 + inten * 0.003, 'triangle', 1600 + inten * 300);
      }
    }
    if (inten >= 4) {
      for (var b = 0; b < 8; b++) {
        musicNote(chord[0] * 0.5, t0 + (b / 8) * BAR, (BAR / 8) * 0.8, 0.03, 'sine', 260);
      }
    }
    barIndex++;
  }

  /* Point the scheduler at "now" — but ONLY if it is actually stale.
   * A stale schedule (nextBar in the past) happens when the context clock
   * jumps: a resume after backgrounding, an interruption ending, a device
   * waking. A HEALTHY schedule already has bars queued up to ~2 bars ahead;
   * re-anchoring it would lay a second copy of the bar over the ones still
   * sounding. That is exactly what broke after 4f4569a: unlock() runs on
   * every tap and reached an unconditional anchor(), so each tap restarted
   * the music on top of itself. The context clock is monotonic, so
   * "nextBar in the future" always means the queue is intact — never touch it. */
  function anchor() {
    if (ctx && nextBar <= ctx.currentTime) nextBar = ctx.currentTime + 0.1;
  }

  /* One scheduling tick. Also the recovery watchdog: while the context is
   * not running it schedules nothing and keeps trying to resume, so an
   * interruption that never fires visibilitychange still self-heals. */
  function musicTick() {
    if (!ctx || musicOff) return;
    if (ctx.state !== 'running') { ensureRunning(); return; }
    /* Never schedule into the past. The context clock is frozen while
     * suspended, so after a long background nextBar can be minutes behind —
     * catching up would spawn a bar of oscillators per 1.9s elapsed, all at
     * once, which is what killed the music. Re-anchor instead. */
    if (nextBar < ctx.currentTime) anchor();
    var guard = 0;
    while (nextBar < ctx.currentTime + 0.8 && guard++ < 4) {
      scheduleBar(nextBar);
      nextBar += BAR;
    }
  }

  function startMusic() {
    if (!ctx || musicOff) return;
    if (!musicGain) {
      musicGain = ctx.createGain();
      musicGain.gain.value = 1;
      musicGain.connect(master);
    }
    // restore volume instantly (a prior stop ramps it to 0 to cut the tail)
    musicGain.gain.cancelScheduledValues(ctx.currentTime);
    musicGain.gain.setTargetAtTime(1, ctx.currentTime, 0.02);
    ensureRunning();
    /* Already playing? Then volume is restored and there is nothing to do.
     * unlock() funnels EVERY tap through here, so past this line must be
     * strictly start-from-silence work — touching the schedule while bars
     * are queued overlays a restarted copy on the audible music. */
    if (musicTimer) return;
    anchor();
    musicTimer = setInterval(musicTick, 200);
  }

  function stopMusic() {
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
    // Silence the bus immediately. Notes are scheduled up to a bar ahead, so
    // without this the music kept playing for a second or two after toggling
    // off — now the button takes effect right away (tiny ramp avoids a click).
    if (musicGain && ctx) {
      musicGain.gain.cancelScheduledValues(ctx.currentTime);
      musicGain.gain.setTargetAtTime(0, ctx.currentTime, 0.015);
    }
  }

  /* Page lifecycle. This module does its own resume rather than relying on
   * main.js: audio.js loads first, so its listener runs first, and it used to
   * re-anchor the scheduler against a still-suspended (frozen) clock before
   * anything resumed the context. */
  function onHide() { stopMusic(); }
  function onShow() {
    if (!ctx) return;
    ensureRunning();
    anchor();
    startMusic();   // no-ops when the player has music switched off
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) onHide(); else onShow();
  });
  // iOS WebView does not always deliver visibilitychange on app switch;
  // pagehide/pageshow cover the cases it misses.
  window.addEventListener('pagehide', onHide);
  window.addEventListener('pageshow', onShow);

  return {
    unlock: function () { unlock(); startMusic(); },

    /* Adaptive music depth (0..6 = Sphere). Read each bar, so a change takes
     * effect on the next bar boundary — no clicks. */
    setIntensity: function (n) { musicIntensity = Math.max(0, Math.min(6, n | 0)); },

    isMusicOff: function () { return musicOff; },
    setMusicOff: function (off) {
      musicOff = off;
      Store.setMusicOff(off);
      // Turning music back ON is a user gesture — the one moment iOS reliably
      // allows a resume. Build the context if it never existed (music toggled
      // on before any other sound) and revive it if it was suspended.
      if (off) stopMusic();
      else { unlock(); startMusic(); }
    },

    /* lane-switch tap */
    tap: function () { blip('square', 340, 190, 0.06, 0.10); },

    /* gem pickup: quick two-note sparkle */
    gem: function () {
      blip('sine', 880, 880, 0.07, 0.16);
      blip('sine', 1318, 1318, 0.10, 0.14, 0.05);
    },

    /* death: descending buzz + crunch */
    death: function () {
      blip('sawtooth', 240, 50, 0.4, 0.22);
      noise(0.25, 0.18);
    },

    /* near miss: short tick whose pitch climbs with the combo */
    nearMiss: function (n) {
      var f = 620 * Math.pow(1.09, Math.min(n || 1, 14));
      blip('triangle', f, f * 1.25, 0.07, 0.09);
    },

    /* power-up pickups: each kind gets its own signature */
    power: function (kind) {
      if (kind === 'shield') {
        // solid "armor on" swell
        blip('sine', 320, 640, 0.16, 0.16);
        blip('sine', 640, 640, 0.14, 0.10, 0.10);
      } else if (kind === 'magnet') {
        // zippy rising arpeggio
        blip('square', 440, 880, 0.10, 0.09);
        blip('square', 660, 1320, 0.12, 0.08, 0.07);
      } else if (kind === 'double') {
        // doubler: bright golden double-chime
        blip('sine', 784, 784, 0.09, 0.14);
        blip('sine', 1175, 1175, 0.14, 0.13, 0.08);
      } else if (kind === 'feast') {
        // feast: a bright bubbly gulp swelling up
        blip('triangle', 300, 760, 0.10, 0.13);
        blip('square', 520, 880, 0.12, 0.10, 0.06);
      } else {
        // slow-mo: long downward bend
        blip('sine', 900, 320, 0.35, 0.14);
      }
    },

    /* feast: a chompy gulp each time a spike is eaten */
    feastEat: function () {
      blip('square', 420, 170, 0.07, 0.10);
      blip('triangle', 880, 1120, 0.06, 0.08, 0.02);
    },

    /* aftershock vacuum: a rising sweep as the gems rush in */
    vacuum: function () {
      blip('sine', 240, 1200, 0.40, 0.10);
      blip('triangle', 480, 1600, 0.34, 0.07, 0.03);
    },

    /* storm bank — BANK: a solid, satisfying deposit chime */
    bank: function () {
      blip('sine', 660, 660, 0.09, 0.15);
      blip('sine', 880, 880, 0.10, 0.14, 0.07);
      blip('sine', 1320, 1320, 0.16, 0.12, 0.14);
    },

    /* storm bank — RIDE: a tense upward "let it ride" swell */
    ride: function () {
      blip('sawtooth', 300, 720, 0.18, 0.10);
      blip('square', 600, 900, 0.12, 0.07, 0.10);
    },

    /* shield absorbs a hit */
    shieldHit: function () {
      noise(0.16, 0.12);
      blip('sine', 520, 240, 0.22, 0.16);
    },

    /* generic UI click */
    click: function () { blip('sine', 620, 500, 0.05, 0.12); },

    /* storm incoming: a long rising tone under the warning flash */
    stormWarn: function () {
      blip('sawtooth', 160, 480, 2.6, 0.09);
      blip('sine', 80, 220, 2.6, 0.07);
    },

    /* storm hits: short thunderclap as the burst begins */
    stormHit: function () {
      noise(0.45, 0.20);
      blip('sawtooth', 140, 45, 0.55, 0.16);
    },

    /* a pulser arms close to the ball: dry warning tick */
    pulserArm: function () { blip('square', 210, 150, 0.05, 0.07); },

    /* level up: short proud fanfare (between unlockSkin and newBest) */
    levelUp: function () {
      blip('sine', 523, 523, 0.09, 0.14);
      blip('sine', 659, 659, 0.09, 0.14, 0.09);
      blip('sine', 784, 784, 0.10, 0.14, 0.18);
      blip('sine', 1047, 1047, 0.20, 0.13, 0.27);
    },

    /* mid-run "BEST!" flash: quick rising triad (the long newBest
     * fanfare stays reserved for the game-over panel) */
    bestFlash: function () {
      blip('sine', 784, 784, 0.08, 0.13);
      blip('sine', 988, 988, 0.08, 0.13, 0.07);
      blip('sine', 1319, 1319, 0.16, 0.12, 0.14);
    },

    /* resume countdown tick + final "go" */
    count: function (go) {
      if (go) blip('sine', 880, 880, 0.12, 0.13);
      else blip('sine', 520, 520, 0.07, 0.10);
    },

    /* can't afford that skin */
    deny: function () { blip('square', 120, 90, 0.13, 0.10); },

    /* skin unlocked: little fanfare */
    unlockSkin: function () {
      blip('sine', 523, 523, 0.09, 0.14);
      blip('sine', 659, 659, 0.09, 0.14, 0.08);
      blip('sine', 784, 784, 0.14, 0.14, 0.16);
    },

    /* new high score celebration: run up + held sparkle chord */
    newBest: function () {
      blip('sine', 659, 659, 0.09, 0.15);
      blip('sine', 784, 784, 0.09, 0.15, 0.09);
      blip('sine', 988, 988, 0.09, 0.15, 0.18);
      blip('sine', 1319, 1319, 0.18, 0.15, 0.27);
      blip('sine', 1568, 1568, 0.22, 0.13, 0.38);
      blip('triangle', 988, 988, 0.55, 0.06, 0.50);
      blip('triangle', 1319, 1319, 0.55, 0.06, 0.50);
      blip('triangle', 1976, 1976, 0.55, 0.05, 0.50);
    },

    isMuted: function () { return muted; },
    setMuted: function (m) {
      muted = m;
      Store.setMuted(m);
      if (master) master.gain.value = m ? 0 : 1;
    },

    /* debug aid for automated tests (harmless in production) */
    _debug: {
      state: function () { return ctx ? ctx.state : 'none'; },
      timerAlive: function () { return !!musicTimer; },
      barLag: function () { return ctx ? (ctx.currentTime - nextBar) : 0; },
      /* Pretend the context clock jumped forward by `sec` — exactly what a
       * suspend/resume cycle does — so a test can prove the scheduler
       * re-anchors instead of flooding bars into the past. */
      desync: function (sec) { nextBar = (ctx ? ctx.currentTime : 0) - sec; },
      barsScheduled: function () { return barIndex; },
      tick: function () { musicTick(); },
      /* Simulate an iOS audio interruption (call/Siri): the context suspends
       * with no page-lifecycle event at all. The watchdog must notice. */
      suspend: function () { if (ctx && ctx.suspend) ctx.suspend(); }
    }
  };
})();
