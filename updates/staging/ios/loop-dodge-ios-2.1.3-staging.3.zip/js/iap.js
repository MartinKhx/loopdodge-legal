/* Google Play Billing wrapper (via cordova-plugin-purchase v13).
 *
 * Fail-safe like ads.js: in a browser, offline, or before the products
 * exist in Play Console, every call quietly no-ops and the shop just says
 * the store is unavailable.
 *
 * Purchase correctness (the hard part):
 *  - A transaction is FINISHED only after its grant is DURABLY persisted.
 *    If the durable write fails, we do NOT finish — Google Play then
 *    redelivers the transaction on the next launch and we retry. This is
 *    the recovery path for "crash/kill after pay, before grant".
 *  - Every transaction is recorded in a processed-transaction LEDGER keyed
 *    by its stable transactionId (Store.addProcessedTxn). A redelivered or
 *    restored transaction whose id is already in the ledger is finished
 *    WITHOUT re-granting, so a consumable can't be granted twice.
 *  - Grants are ordered grant -> record-ledger -> finish; both the grant
 *    and the ledger entry must persist before we finish. The only residual
 *    double-grant window (grant write succeeds, ledger write fails in the
 *    same tick) costs virtual gems only and is the documented reason real
 *    fraud protection needs server-side verification (see SECURITY below).
 *
 * SECURITY — client-only validation is NOT secure. There is no server, so
 * a determined user with a rooted device / patched store can replay or
 * fake "approved" transactions. To harden, set store.validator to a
 * backend endpoint that verifies the Play receipt with Google's
 * Android Publisher API (purchases.products.get / .acknowledge) and only
 * grant after the server confirms. This wrapper keeps the local structure
 * (ledger, durable-before-finish) so a server check slots in at the
 * .approved/.verified seam without reworking the grant flow.
 *
 * Browser testing aid: ?fakeiap=1 simulates the store (instant grants,
 * fake prices). Product IDs live in iap-config.js. */
var Iap = (function () {
  var store = null;          // CdvPurchase.store (native only)
  var ready = false;
  var FAKE = /[?&]fakeiap=1/.test(location.search);
  var updateCb = null;       // shop UI re-render hook

  // notify() runs inside grant() BEFORE the ledger write, so it must never throw
  // into onApproved (a throw there would skip addProcessedTxn → redelivery re-grants).
  // The report is defensively wrapped so even a future throwing Telemetry can't
  // reopen a double-grant window.
  function notify() { if (updateCb) { try { updateCb(); } catch (e) { console.warn('[iap] shop refresh failed:', (e && e.message) || e); try { if (window.Telemetry) Telemetry.report(e); } catch (e2) {} } } }

  /* Log without leaking receipt/order data: a short, non-reversible tag. */
  function tag(id) {
    id = String(id || '');
    return id.length <= 8 ? id : (id.slice(0, 6) + '…' + id.length);
  }

  function cfg(id) {
    for (var i = 0; i < IAP_CONFIG.products.length; i++) {
      if (IAP_CONFIG.products[i].id === id) return IAP_CONFIG.products[i];
    }
    return null;
  }

  /* Deliver one product to the player. Throws if the durable write failed,
   * so the caller knows NOT to finish the transaction. Idempotent for
   * remove_ads (a re-grant just re-sets the same flag). */
  function grant(id) {
    var p = cfg(id);
    if (!p) return; // unknown product id: nothing to grant, safe to finish
    var ok;
    // Purchased gems use addGemsRaw so the Ultra Pass x3 NEVER inflates a paid
    // pack (you get exactly what the price advertised).
    if (p.gems) ok = Store.addGemsRaw(p.gems);
    else if (id === 'ultra_pass') ok = Store.setUltraPass(true);
    else if (id === 'remove_ads') ok = Store.setAdsRemoved(true);
    else ok = true;
    if (ok === false) throw new Error('grant write failed: ' + id);
    notify();
  }

  /* Stable id for a transaction across redeliveries. */
  function txnId(transaction) {
    if (transaction && transaction.transactionId) return transaction.transactionId;
    // Fallback for shapes without a transactionId: a composite of product
    // ids + purchase time, stable enough to dedupe a redelivery.
    var ids = (transaction && transaction.products ? transaction.products : [])
      .map(function (tp) { return tp.id; }).join(',');
    var when = (transaction && (transaction.purchaseDate || transaction.lastChanged)) || '';
    return 'legacy:' + ids + ':' + when;
  }

  /* The single approved-transaction handler. */
  function onApproved(transaction) {
    var id = txnId(transaction);
    try {
      if (Store.hasProcessedTxn(id)) {
        // Already granted in a prior session/delivery (redelivery, restore):
        // finish without re-granting so consumables never double up.
        finish(transaction);
        console.log('[iap] already processed, finishing ' + tag(id));
        return;
      }
      // Grant every product, then durably record the ledger entry. Both
      // writes throw on failure, so we only reach finish() once the player
      // actually, durably has what they paid for.
      (transaction.products || []).forEach(function (tp) { grant(tp.id); });
      Store.addProcessedTxn(id);
      // Count a durable grant exactly once. A restored transaction can be a
      // first local grant, so this is deliberately not reported as revenue.
      try {
        if (window.Analytics) (transaction.products || []).forEach(function (tp) {
          Analytics.track('purchase_granted', { product_id: tp.id, source: 'store_approved' });
        });
      } catch (analyticsError) {}
      finish(transaction);
      console.log('[iap] granted + finished ' + tag(id));
    } catch (e) {
      // Do NOT finish: Play redelivers the unfinished transaction next
      // launch and we retry when storage is healthy again.
      console.warn('[iap] deferred (will retry on redelivery): ' +
        (e && e.message ? e.message : e));
    }
  }

  function finish(transaction) {
    try { if (transaction && transaction.finish) transaction.finish(); } catch (e) { console.warn('[iap] finish() failed:', (e && e.message) || e); if (window.Telemetry) Telemetry.report(e); }
  }

  /* Which native store this device talks to. Defaults to 'android' (Google Play)
   * for unknown/legacy environments so existing behavior is unchanged. */
  function platformName() {
    return (window.Capacitor && typeof window.Capacitor.getPlatform === 'function')
      ? window.Capacitor.getPlatform() : 'android';
  }

  /* Products this platform offers (iap-config `platforms` tag; missing = all). */
  function platformProducts(os) {
    return IAP_CONFIG.products.filter(function (p) {
      return !p.platforms || p.platforms.indexOf(os) !== -1;
    });
  }

  var initialized = false;
  function init() {
    if (initialized) return;     // idempotent: main.js may call twice on Cordova
    if (FAKE) { initialized = true; ready = true; notify(); return; }
    if (!window.CdvPurchase) return; // browser / plugin missing: shop stays off
    initialized = true;

    var CP = window.CdvPurchase;
    store = CP.store;

    var os = platformName();
    var storePlatform = (os === 'ios') ? CP.Platform.APPLE_APPSTORE
                                       : CP.Platform.GOOGLE_PLAY;

    store.register(platformProducts(os).map(function (p) {
      return {
        id: p.id,
        type: p.type === 'consumable' ? CP.ProductType.CONSUMABLE
                                      : CP.ProductType.NON_CONSUMABLE,
        platform: storePlatform
      };
    }));

    store.when()
      .approved(onApproved)
      .productUpdated(function () { ready = true; notify(); });

    store.initialize([storePlatform])
      .then(function () { ready = true; notify(); })
      .catch(function (e) { console.warn('[iap] init failed:', e); });
  }

  /* Shop rows for the UI: title, localized price, whether buyable. */
  function getCatalog() {
    return platformProducts(platformName()).map(function (p) {
      var price = FAKE ? (p.gems ? '$0.99' : '$2.99') : null;
      var canBuy = FAKE;
      if (store) {
        var sp = store.get(p.id);
        if (sp && sp.pricing) {
          price = sp.pricing.price;
          /* Consumables (the gem packs) are re-buyable the moment their last
           * transaction is finished — but sp.canPurchase can stay false for
           * many seconds after that on StoreKit, which stranded the buy
           * button as disabled and made a second pack feel unpurchasable.
           * Loaded pricing is the reliable "orderable" signal for a
           * consumable; the UI holds its own in-flight lock so a pending
           * order still can't be double-tapped, and the store rejects a
           * genuinely invalid order anyway. Non-consumables keep the strict
           * check, since for those canPurchase also encodes ownership. */
          canBuy = (p.type === 'consumable') ? true : sp.canPurchase;
        }
      }
      var owned = (p.id === 'remove_ads' && Store.getAdsRemoved()) ||
                  (p.id === 'ultra_pass' && Store.getUltraPass());
      return { id: p.id, title: p.title, gems: p.gems || 0,
               price: price, canBuy: canBuy && !owned, owned: owned };
    });
  }

  function isAvailable() { return FAKE || (ready && !!store); }

  function buy(id) {
    if (FAKE) {
      return new Promise(function (resolve) {
        setTimeout(function () {
          try { grant(id); Store.addProcessedTxn('fake:' + id + ':' + Date.now()); } catch (e) {}
          resolve(true);
        }, 500);
      });
    }
    if (!store) return Promise.resolve(false);
    var sp = store.get(id);
    var offer = sp && sp.getOffer();
    if (!offer) return Promise.resolve(false);
    // grant happens in onApproved; this resolves on order placed
    return offer.order().then(function (err) { return !err; })
      .catch(function () { return false; });
  }

  /* Resolves to a result the UI can turn into feedback (IAP-02):
   *   { ok: true }                    — the store finished the restore sweep
   *   { ok: false, reason: '...' }    — unavailable, or the sweep threw
   * Whether anything was actually re-granted is decided by the caller comparing
   * entitlement state before/after (restored purchases arrive via onApproved). */
  function restore() {
    if (FAKE) {
      try { grant('remove_ads'); } catch (e) {}
      return Promise.resolve({ ok: true });
    }
    if (!store) return Promise.resolve({ ok: false, reason: 'unavailable' });
    return store.restorePurchases()
      .then(function () { return { ok: true }; })
      .catch(function (e) {
        console.warn('[iap] restore failed:', (e && e.message) || e);
        if (window.Telemetry) Telemetry.report(e);
        return { ok: false, reason: 'error' };
      });
  }

  return {
    init: init,
    isAvailable: isAvailable,
    getCatalog: getCatalog,
    buy: buy,
    restore: restore,
    onUpdate: function (cb) { updateCb = cb; },
    /* exposed for tests: drive the approved-transaction handler directly */
    _onApproved: onApproved
  };
})();
