/* Ghost racing (v10 "Oracle's Descent" P0.2).
 *
 * A "ghost" is a TAPE of one past run on a known seed: the starting lane plus
 * the master-clock (`totalAngle`) of every lane switch, and the angle at which
 * that run ended. On a later run with the SAME seed, the obstacle field is
 * byte-identical, so replaying the tape's lane choices reproduces that run's
 * trajectory exactly — a translucent ball riding the same ring beside you.
 *
 * HARD CONTRACT: the ghost is PURE RENDER. It records nothing but lane-switch
 * timestamps, replays a lane over a timeline, and never calls rng(), never
 * touches the ball/entities/economy/clock. So a daily run that races a ghost
 * stays byte-identical to one that doesn't. Lanes are binary, so a tape only
 * needs the switch angles (the lane TOGGLES at each) — tiny and shareable. */
var Ghost = (function () {
  var MAX_SWITCHES = 400;       // bound a tape (a long run is ~150 switches)
  var BASE36_MAX = 2176782336;  // 36^6 — a seed code is 6 base36 chars

  /* The ghost's lane at master-clock time T: start lane toggled once per
   * recorded switch STRICTLY before T (matching the engine cursor — a switch
   * recorded at angle a takes visible effect just after a, the frame the live
   * ball flipped). Pure function of (tape, T). */
  function laneAt(tape, T) {
    if (!tape || !tape.sw) return null;
    var sw = tape.sw, n = 0;
    for (var i = 0; i < sw.length; i++) {
      if (sw[i] < T) n++; else break;
    }
    return (tape.start ^ (n & 1)) ? 1 : 0;
  }

  /* Normalize / validate a tape from any source (storage, a share). Drops
   * non-finite switches, bounds the length, sorts ascending, clamps fields.
   * Returns a safe tape or null. */
  function clean(t) {
    if (!t || typeof t !== 'object') return null;
    var sw = [];
    if (Array.isArray(t.sw)) {
      for (var i = 0; i < t.sw.length && sw.length < MAX_SWITCHES; i++) {
        var v = t.sw[i];
        if (typeof v === 'number' && isFinite(v) && v >= 0) sw.push(v);
      }
      sw.sort(function (a, b) { return a - b; });
    }
    var end = (typeof t.end === 'number' && isFinite(t.end) && t.end >= 0) ? t.end : 0;
    var score = (typeof t.score === 'number' && isFinite(t.score) && t.score >= 0) ? Math.floor(t.score) : 0;
    return { start: t.start === 1 ? 1 : 0, sw: sw, end: end, score: score };
  }

  /* A tape is only worth racing if it has an end angle to bound the replay. */
  function isReplayable(tape) {
    return !!(tape && tape.sw && tape.end > 0);
  }

  /* 6-char base36 seed code (for shareable seed runs). encode is total;
   * decode returns a non-negative int seed or null for malformed input. */
  function encodeSeed(n) {
    n = Math.abs(Math.floor(n || 0)) % BASE36_MAX;
    var s = n.toString(36).toUpperCase();
    while (s.length < 6) s = '0' + s;
    return s;
  }
  function decodeSeed(code) {
    if (typeof code !== 'string') return null;
    code = code.trim().toUpperCase();
    if (!/^[0-9A-Z]{1,6}$/.test(code)) return null;
    var n = parseInt(code, 36);
    return (isFinite(n) && n >= 0) ? n : null;
  }

  return {
    MAX_SWITCHES: MAX_SWITCHES,
    laneAt: laneAt,
    clean: clean,
    isReplayable: isReplayable,
    encodeSeed: encodeSeed,
    decodeSeed: decodeSeed
  };
})();
