/* First-party, PII-free crash reporter (Phase 1).
 *
 * Design:
 *  - Installs window.onerror + window.onunhandledrejection SYNCHRONOUSLY at
 *    module evaluation (in the IIFE body, NOT a deferred init), so an error
 *    thrown by any later-loaded module's IIFE is still captured. This file is
 *    therefore registered FIRST in www/index.html / the test harness.
 *  - Captured errors land in a bounded in-memory ring buffer (cap 25). The
 *    last-N are persisted through Store.getTelemetry/setTelemetry, which itself
 *    clamps + sanitizes on read and write.
 *  - PII-FREE: every payload is built field-by-field from an explicit allowlist
 *    (message, filename, lineno, colno, stack, appVersion, platform, ts). No
 *    object is EVER serialized wholesale — no gem counts, order/transaction
 *    IDs, ledger, localStorage dump, full URLs, location.search, or custom-skin
 *    data URLs. `source` is reduced to a bare leaf basename (no scheme/host/
 *    query). This is the core ASVS V8 data-minimization control.
 *  - FAIL-SAFE: the entire capture path is wrapped in try/catch so a throwing
 *    getter on the error/reason object can never propagate into the frame loop
 *    or brick boot. A telemetry failure is silently swallowed.
 *  - DETERMINISM: a passive observer — it never reads the world clock for
 *    gameplay nor touches the engine spawn RNG, so seeded daily runs are
 *    unaffected.
 *
 * The 60x/s error-storm circuit-breaker is a Phase 2 seam — noted, not built. */
var Telemetry = (function () {
  /* Keep APP_VERSION in sync with package.json / android build.gradle;
   * the Phase 8 release guard will pin it. */
  var APP_VERSION = '2.0.8';
  var CAP = 25;
  var ring = [];

  /* Reduce an onerror `source` to its leaf basename: strip the query/hash,
   * then keep only the last path segment. 'http://h:8080/js/iap.js?t=1' -> 'iap.js'.
   * Returns '' for empty/missing input. */
  function safeFilename(source) {
    return String(source || '').split(/[?#]/)[0].split('/').pop() || '';
  }

  /* Guarded platform read (mirrors ads.js / iap.js getPlatform guard). Wrapped
   * in try/catch so a throwing bridge getter degrades the platform field to ''
   * rather than dropping the entire crash report through capture()'s catch. */
  function platform() {
    try {
      return (window.Capacitor && typeof window.Capacitor.getPlatform === 'function')
        ? window.Capacitor.getPlatform()
        : 'web';
    } catch (e) {
      return '';
    }
  }

  /* Build the captured object from the allowlist ONLY — never spread or
   * serialize an arbitrary error/event object. */
  function buildPayload(kind, raw) {
    var err = raw.error;
    return {
      message:    String(raw.message || (err && err.message) || '').slice(0, 500),
      filename:   safeFilename(raw.source),
      lineno:     (typeof raw.lineno === 'number') ? raw.lineno : 0,
      colno:      (typeof raw.colno === 'number') ? raw.colno : 0,
      stack:      (err && typeof err.stack === 'string') ? err.stack.slice(0, 2000) : '',
      appVersion: APP_VERSION,
      platform:   platform(),
      ts:         Date.now()
    };
  }

  /* Persist the bounded ring through the validated Store path. Store may be
   * undefined during the earliest boot captures (telemetry loads FIRST, before
   * storage.js) — the in-memory ring still holds them and a later flush
   * persists. Swallow-and-continue on any failure. */
  function flush() {
    try {
      if (typeof Store !== 'undefined' && Store && typeof Store.setTelemetry === 'function') {
        Store.setTelemetry(ring);
      }
    } catch (e) { /* never let persistence break the handler */ }
  }

  /* The single capture path. The ENTIRE body is wrapped so a throwing getter
   * on raw.error (e.g. a poisoned `.stack`) cannot propagate into game logic. */
  function capture(kind, raw) {
    try {
      var payload = buildPayload(kind, raw || {});
      ring.push(payload);
      if (window.Analytics) Analytics.runtimeError(payload);
      if (ring.length > CAP) ring = ring.slice(ring.length - CAP);
      flush();
    } catch (e) { /* fail-safe: telemetry must never throw into the frame loop */ }
  }

  /* Install handlers SYNCHRONOUSLY (not a deferred init). */
  window.onerror = function (message, source, lineno, colno, error) {
    capture('error', { message: message, source: source, lineno: lineno, colno: colno, error: error });
    return false; // keep the browser's default console logging
  };
  window.onunhandledrejection = function (ev) {
    var reason = ev && ev.reason;
    capture('unhandledrejection', { error: reason, message: (reason && reason.message) || String(reason) });
  };

  return {
    /* A COPY of the buffer — never the live array, so callers cannot mutate it. */
    recent: function () { return ring.slice(); },
    /* Manual hook for Phase 2 (IAP / render-loop logging). */
    report: function (err) {
      capture('report', { error: err, message: (err && err.message) || String(err) });
    },
    /* Test seam (mirrors the Iap._onApproved convention). */
    _capture: capture
  };
})();
